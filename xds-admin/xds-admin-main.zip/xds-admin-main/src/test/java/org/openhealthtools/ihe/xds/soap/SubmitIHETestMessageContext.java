package org.openhealthtools.ihe.xds.soap;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URI;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMDocument;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axiom.soap.SOAP12Constants;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axiom.soap.SOAPHeaderBlock;
import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.apache.axis2.context.MessageContext;
import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.soap.SOAPEnvelope;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.AddressingConstants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.OperationClient;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.engine.Phase;
import org.apache.axis2.handlers.AbstractHandler;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.wsdl.WSDLConstants;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.openhealthtools.ihe.common.ws.IHESOAPException;
import org.openhealthtools.ihe.common.ws.async.AsyncListenerManager;
import org.openhealthtools.ihe.common.ws.utils.SOAPUtils;

public class SubmitIHETestMessageContext {

	private String requestFileName = "src/test/resources/sample/newSubmit.xml";
	private String responseFileName = "src/test/resources/sampleresponse.xml";

	private HttpClient httpClient;
	/**
	 * Apache Axis2 options
	 */
	private Options mOptions;

	/**
	 * Apache Axis2 client sender mechanism
	 */
	private ServiceClient mSender;

	/**
	 * SOAP Factory for the respective types
	 */
	private SOAPFactory soapFactory;

	@Test
	public void testRegister() {
		try {
			mOptions = new Options();

			// Initialize the Apache Commons HTTP Client
			initializeHttpClient();

			// Initialize Axis2 Service Sender
			mSender = new ServiceClient();
			mSender.setOptions(mOptions);

			// initializeAddressingHandlers();

			// We will default to SOAP 1.2
			soapFactory = OMAbstractFactory.getSOAP12Factory();

			//create the soap
			//begin to send the message
			OMElement body = createMetadata();
			
			//prepare the context
			MessageContext requestMessageContext = prepareMessageContext(new URI(""),null,"urn:ihe:iti:2007:RegisterDocumentSet-b",null);
			this.executeSend(requestMessageContext);
			
			
		} catch (AxisFault af) {
			af.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		ServiceClient serviceClient = createServiceClient();
		OMElement body = null;
		FileOutputStream fot = null;
		long sendSOAPBeginTime = 0, sendEndSOAPBeginTime = 0;
		try {
			body = createMetadata();
			sendSOAPBeginTime = System.currentTimeMillis();
			System.out.println("start send the soap");
			OMElement result = serviceClient.sendReceive(body);
			sendEndSOAPBeginTime = System.currentTimeMillis();

			fot = new FileOutputStream(responseFileName);
			result.serialize(fot);
			System.out.println(result.toString());

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("Time cost:"
					+ (sendEndSOAPBeginTime - sendSOAPBeginTime));
		}
	}

	protected void initializeHttpClient() {
		HttpConnectionManager connManager = new MultiThreadedHttpConnectionManager();
		httpClient = new HttpClient(connManager);

		DefaultHttpMethodRetryHandler retryhandler = new DefaultHttpMethodRetryHandler(
				0, true);
		httpClient.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,
				retryhandler);

		// Set the HTTP Client instance to use in sending
		// FIXME issue 114
		// this line causing threading issues:
		// mOptions.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, Boolean.TRUE);
		mOptions.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, Boolean.FALSE);
		mOptions.setProperty(HTTPConstants.CACHED_HTTP_CLIENT, httpClient);
	}

	private MessageContext prepareMessageContext(URI endpoint,
			SOAPEnvelope envelope, String action,
			Map<String, javax.activation.DataHandler> attachments)
			throws IHESOAPException, AxisFault {
		if (null == endpoint || SOAPUtils.isNullOrEmpty(endpoint.toString())) {
			throw new IHESOAPException("No Service Endpoint Defined");
		}

		// Create MC
		MessageContext requestMessageContext = new MessageContext();
		requestMessageContext.setEnvelope(envelope);
		requestMessageContext.setOptions(getOptions());
		if (!SOAPUtils.isNullOrEmpty(action)) {
			requestMessageContext.getOptions().setAction(action);
			requestMessageContext.getOptions().setMessageId(
					UUID.randomUUID().toString());
		}

		// Cache attachments into MessageContext for SwA sending
		if (null != attachments && attachments.size() > 0) {
			Set<String> attachmentSet = attachments.keySet();
			for (String mapKey : attachmentSet) {
				if (mapKey instanceof String) {
					requestMessageContext.addAttachment((String) mapKey,
							(javax.activation.DataHandler) attachments
									.get(mapKey));
				}
			}

		} else {
			// FIXME SEK - we should have a beter way of setting these
			// properties at a higher level so we don't have to rely on string
			// matching at this point
			if (action != null && action.contains("RetrieveDocumentSet")) {
				requestMessageContext.setProperty(
						Constants.Configuration.ENABLE_MTOM,
						Constants.VALUE_TRUE);
			} else if (action != null
					&& !action.contains("ProvideAndRegisterDocumentSet-b")) {
				// If no attachments to send, and not P&R-b, reset MIME settings
				requestMessageContext.setProperty(
						Constants.Configuration.ENABLE_MTOM,
						Constants.VALUE_FALSE);
				requestMessageContext.setProperty(
						Constants.Configuration.ENABLE_SWA,
						Constants.VALUE_FALSE);
			}
		}

		// Check if we're to use the HTTP Chunking workaround
		// if (useHttpChunking()) {
		// requestMessageContext.setProperty(HTTPConstants.CHUNKED, "true");
		// } else {
		requestMessageContext.setProperty(HTTPConstants.CHUNKED, "false");
		// }

		// Set destination endpiont uri
		requestMessageContext.getOptions().setTo(
				new EndpointReference(endpoint.toString()));

		// Push service context into Message Context
		requestMessageContext.setServiceContext(mSender.getServiceContext());

		return requestMessageContext;
	}

	/**
	 * Gets the current Axis2 options
	 * 
	 * @return Axis2 sender options and settings
	 */
	protected Options getOptions() {
		return mOptions;
	}

	/**
	 * Finalizes construction of sockets and sends a SOAP Message over a given
	 * ATNA socket.
	 * 
	 * @throws IHESOAPException
	 */
	private MessageContext executeSend(MessageContext requestMessageContext)
			throws IHESOAPException {
		try {

			if (null == requestMessageContext) {
				throw new IHESOAPException(
						"A MessageContext must be set before send.");
			}

			OperationClient sendClient = mSender
					.createClient(ServiceClient.ANON_OUT_IN_OP);

			sendClient.addMessageContext(requestMessageContext);
			enableAddressingInPhaseFlow(requestMessageContext, sendClient);
			sendClient.execute(true);

			return sendClient
					.getMessageContext(WSDLConstants.MESSAGE_LABEL_IN_VALUE);
		} catch (AxisFault af) {
			af.printStackTrace();
			throw new IHESOAPException(
					"A SOAP Fault occurred during message transmission.", af);
		} catch (Exception e) {
			e.printStackTrace();
			throw new IHESOAPException("Error Sending SOAP Message", e);
		} finally {

		}
	}

	protected void enableAddressingInPhaseFlow(MessageContext ctx,
			OperationClient sendClient) {
		ctx.setProperty(AddressingConstants.REPLACE_ADDRESSING_HEADERS,
				Constants.VALUE_FALSE);
		ctx.setProperty(AddressingConstants.INCLUDE_OPTIONAL_HEADERS,
				Constants.VALUE_TRUE);

		if (SOAPUtils.isNullOrEmpty(ctx.getOptions().getAction())) {
			ctx.setProperty(
					AddressingConstants.DISABLE_ADDRESSING_FOR_OUT_MESSAGES,
					Constants.VALUE_TRUE);
		} else {
			ctx.setProperty(
					AddressingConstants.DISABLE_ADDRESSING_FOR_OUT_MESSAGES,
					Constants.VALUE_FALSE);
		}
	}

	public ServiceClient createServiceClient() {

		ServiceClient serviceClient = null;
		try {

			serviceClient = new ServiceClient();

			Options options = serviceClient.getOptions();

			options.setTo(new EndpointReference(
					"http://ihexds.nist.gov:12080/tf6/services/xdsregistryb"));
			// serviceClient.getOptions().setProperty(HTTPConstants.CHUNKED,
			// "false");
			// serviceClient.getOptions().setTransportInProtocol(Constants.TRANSPORT_HTTP);
			options.setProperty(Constants.Configuration.ENABLE_MTOM,
					Boolean.FALSE);

			// options.setProperty(HTTPConstants.CUSTOM_PROTOCOL_HANDLER,
			// protocol);

			options.setAction("urn:ihe:iti:2007:RegisterDocumentSet-b");

			options.setSoapVersionURI(SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI);
			serviceClient.engageModule("addressing");
			// options.setReplyTo(new EndpointReference(
			// "http://www.w3.org/2005/08/addressing/anonymous"));
			// options.setAction("urn:ihe:iti:2007:RegisterDocumentSet-b");
			// options.setMessageId("urn:uuid:12.12321313");
			// options.setTimeOutInMilliSeconds(100000);
			// options.setSoapVersionURI("http://www.w3.org/2003/05/soap-envelope");
			// serviceClient.addStringHeader(new
			// QName("http://www.w3.org/2005/08/addressing","Action","a"),
			// "urn:ihe:iti:2007:RegisterDocumentSet-b");
			// serviceClient.addStringHeader(new
			// QName("http://www.w3.org/2005/08/addressing","MessageID","a"),
			// "urn:uuid:"+(new UUIDFactory()).newUUID().toString());
			// serviceClient.addStringHeader(new
			// QName("http://www.w3.org/2005/08/addressing","To","a"),
			// "http://localhost:2647/XdsService/IHEXDSRegistry.svc");
			// SOAPFactory factory = OMAbstractFactory.getSOAP12Factory();
			// OMNamespace addressNamespace = factory.createOMNamespace(
			// "http://www.w3.org/2005/08/addressing", "a");
			// SOAPHeaderBlock actionSOAPHeader = factory.createSOAPHeaderBlock(
			// "Action", addressNamespace);
			// actionSOAPHeader.setMustUnderstand(true);
			// actionSOAPHeader.addChild(factory
			// .createOMText("urn:ihe:iti:2007:RegisterDocumentSet-b"));
			// serviceClient.addHeader(actionSOAPHeader);

			// SOAPHeaderBlock messageIDSOAPHeader = factory
			// .createSOAPHeaderBlock("MessageID", addressNamespace);
			// messageIDSOAPHeader.addChild(factory.createOMText("urn:uuid:"
			// + (new UUIDFactory()).newUUID().toString()));
			// serviceClient.addHeader(messageIDSOAPHeader);

			// SOAPHeaderBlock toSOAPHeader =
			// factory.createSOAPHeaderBlock("To",
			// addressNamespace);
			// toSOAPHeader.setMustUnderstand(true);
			// toSOAPHeader.addChild(factory.createOMText("http://ihexds.nist.gov:12080/tf6/services/xdsregistryb"));
			// serviceClient.addHeader(toSOAPHeader);

			// SOAPHeaderBlock replyToSOAPHeader =
			// factory.createSOAPHeaderBlock("ReplyTo",
			// addressNamespace);
			// OMElement addressOMElement = factory.createOMElement("Address",
			// addressNamespace);
			// addressOMElement
			// .setText("http://192.168.0.165:8888/simed-repository/services/xdsrepositoryb");
			// replyToSOAPHeader.addChild(addressOMElement);
			// serviceClient.addHeader(replyToSOAPHeader);
		} catch (AxisFault e) {
			e.printStackTrace();
			// logger.error("When create the service client, receive the exception:"
			// + e);
			// throw new RegistryException("XDSRegistryNotAvailable",
			// "Unable to connect to the Registry to register document",
			// "RegisterDocumentSetbClient");
		}

		return serviceClient;
	}

	private OMElement createMetadata() {
		OMElement requestOMElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		XMLStreamReader parser = null;
		try {
			parser = XMLInputFactory.newInstance().createXMLStreamReader(
					new FileInputStream(requestFileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (XMLStreamException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (FactoryConfigurationError e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		StAXOMBuilder builder = new StAXOMBuilder(parser);
		// get the root element
		// OMElement documentElement = builder.getDocumentElement();
		OMDocument mataDataDocument = builder.getDocument();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);
		requestOMElement = mataDataDocument.getOMDocumentElement();

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return requestOMElement;
	}
}
