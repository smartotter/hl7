package org.openhealthtools.ihe.xds.soap;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMDocument;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axiom.soap.SOAP12Constants;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axiom.soap.SOAPHeaderBlock;
import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class SubmitIHETest {

	private String requestFileName = "src/test/resources/sample/newSubmit.xml";
	private String responseFileName = "src/test/resources/sampleresponse.xml";

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testRegister(){

		ServiceClient serviceClient = createServiceClient();
		OMElement body = null;
		FileOutputStream fot = null;
		long sendSOAPBeginTime = 0, sendEndSOAPBeginTime = 0;
		try {
			body = createMetadata();
			sendSOAPBeginTime = System.currentTimeMillis();
			System.out.println("start send the soap");
			OMElement result = serviceClient.sendReceive(body);
			sendEndSOAPBeginTime = System.currentTimeMillis();

			fot = new FileOutputStream(responseFileName);
			result.serialize(fot);
			System.out.println(result.toString());

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("Time cost:"
					+ (sendEndSOAPBeginTime - sendSOAPBeginTime));
		}
	}
	
	public ServiceClient createServiceClient() {

		ServiceClient serviceClient = null;
		try {

			serviceClient = new ServiceClient();
			
			Options options = serviceClient.getOptions();
			
			options.setTo(new EndpointReference("http://192.168.1.94:1029/xdsservice/xdsregistry"));
			// serviceClient.getOptions().setProperty(HTTPConstants.CHUNKED,
			// "false");
			// serviceClient.getOptions().setTransportInProtocol(Constants.TRANSPORT_HTTP);
			options.setProperty(Constants.Configuration.ENABLE_MTOM, Boolean.FALSE);
			
//			options.setProperty(HTTPConstants.CUSTOM_PROTOCOL_HANDLER, protocol);

			options.setAction("urn:ihe:iti:2007:RegisterDocumentSet-b");
			
			options.setSoapVersionURI(SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI);
			serviceClient.engageModule("addressing");
//			options.setReplyTo(new EndpointReference(
//					"http://www.w3.org/2005/08/addressing/anonymous"));
//			options.setAction("urn:ihe:iti:2007:RegisterDocumentSet-b");
//			options.setMessageId("urn:uuid:12.12321313");
//			options.setTimeOutInMilliSeconds(100000);
//			options.setSoapVersionURI("http://www.w3.org/2003/05/soap-envelope");
			// serviceClient.addStringHeader(new
			// QName("http://www.w3.org/2005/08/addressing","Action","a"),
			// "urn:ihe:iti:2007:RegisterDocumentSet-b");
			// serviceClient.addStringHeader(new
			// QName("http://www.w3.org/2005/08/addressing","MessageID","a"),
			// "urn:uuid:"+(new UUIDFactory()).newUUID().toString());
			// serviceClient.addStringHeader(new
			// QName("http://www.w3.org/2005/08/addressing","To","a"),
			// "http://localhost:2647/XdsService/IHEXDSRegistry.svc");
//			SOAPFactory factory = OMAbstractFactory.getSOAP12Factory();
//			OMNamespace addressNamespace = factory.createOMNamespace(
//					"http://www.w3.org/2005/08/addressing", "a");
//			SOAPHeaderBlock actionSOAPHeader = factory.createSOAPHeaderBlock(
//					"Action", addressNamespace);
//			actionSOAPHeader.setMustUnderstand(true);
//			actionSOAPHeader.addChild(factory
//					.createOMText("urn:ihe:iti:2007:RegisterDocumentSet-b"));
//			serviceClient.addHeader(actionSOAPHeader);

//			SOAPHeaderBlock messageIDSOAPHeader = factory
//					.createSOAPHeaderBlock("MessageID", addressNamespace);
//			messageIDSOAPHeader.addChild(factory.createOMText("urn:uuid:"
//					+ (new UUIDFactory()).newUUID().toString()));
//			serviceClient.addHeader(messageIDSOAPHeader);

//			SOAPHeaderBlock toSOAPHeader = factory.createSOAPHeaderBlock("To",
//					addressNamespace);
//			toSOAPHeader.setMustUnderstand(true);
//			toSOAPHeader.addChild(factory.createOMText("http://ihexds.nist.gov:12080/tf6/services/xdsregistryb"));
//			serviceClient.addHeader(toSOAPHeader);

			// SOAPHeaderBlock replyToSOAPHeader =
			// factory.createSOAPHeaderBlock("ReplyTo",
			// addressNamespace);
			// OMElement addressOMElement = factory.createOMElement("Address",
			// addressNamespace);
			// addressOMElement
			// .setText("http://192.168.0.165:8888/simed-repository/services/xdsrepositoryb");
			// replyToSOAPHeader.addChild(addressOMElement);
			// serviceClient.addHeader(replyToSOAPHeader);
		} catch (AxisFault e) {
			e.printStackTrace();
//			logger.error("When create the service client, receive the exception:"
//					+ e);
//			throw new RegistryException("XDSRegistryNotAvailable",
//					"Unable to connect to the Registry to register document",
//					"RegisterDocumentSetbClient");
		}

		return serviceClient;
	}
	private OMElement createMetadata() {
		OMElement requestOMElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		XMLStreamReader parser = null;
		try {
			parser = XMLInputFactory.newInstance().createXMLStreamReader(
					new FileInputStream(requestFileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (XMLStreamException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (FactoryConfigurationError e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		StAXOMBuilder builder = new StAXOMBuilder(parser);
		// get the root element
		// OMElement documentElement = builder.getDocumentElement();
		OMDocument mataDataDocument = builder.getDocument();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);
		requestOMElement = mataDataDocument.getOMDocumentElement();

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return requestOMElement;
	}
}
