package com.kangva.xds.document.consumer;

import java.net.URI;
import java.net.URISyntaxException;

import org.openhealthtools.ihe.common.hl7v2.CX;
import org.openhealthtools.ihe.common.hl7v2.Hl7v2Factory;
import org.openhealthtools.ihe.common.hl7v2.XCN;
import org.openhealthtools.ihe.xds.consumer.query.DateTimeRange;
import org.openhealthtools.ihe.xds.consumer.query.MalformedQueryException;
import org.openhealthtools.ihe.xds.metadata.CodedMetadataType;
import org.openhealthtools.ihe.xds.metadata.MetadataFactory;
import org.openhealthtools.ihe.xds.metadata.constants.DocumentEntryConstants;

public class TestConfiguration {
	//basics
		public static final String LOG4J_PATH = "./resources/conf/xdsconsumer_log4j.xml";
		
	    //ATNA logging enable/disablement
	    public static final boolean DO_AUDIT = true; // change to 'true' to enable auditing
	    public static final String INITIATING_USER = "some user";
	    public static final String AUDIT_SOURCE_ID = "OTHER_OHT";
	    
	    // TLS enablement
	    public static final boolean USE_TLS = true; // change to 'true' to enable TLS
	    public static final String KEY_STORE = "/Users/developer/git/xds-admin/src/test/resources/security/OpenXDS_2013_Keystore.p12";
	    public static final String KEY_STORE_PASS ="123456";
	    public static final String TRUST_STORE="/Users/developer/git/xds-admin/src/test/resources/security/OpenXDS_2016_Truststore.jks";
	    public static final String TRUST_STORE_PASS="123456";
	    
	    // Server Options
	    //////////////////////////////////////////////////////////////////////////////////////////////
	    // XDS.a is deprecated as of TF6 (2009) - not tested in the 2010 NA Connectathon and beyond
	    //////////////////////////////////////////////////////////////////////////////////////////////
		// NIST Registry (query interface)
		public static final String NIST_REGISTRY_QUERY = "http://ihexds.nist.gov:9080/tf5/services/xdsregistrya";

		// NIST Secured Registry (query interface)
		public static final String NIST_REGISTRY_QUERY_SECURED = "https://ihexds.nist.gov:9085/tf5/services/xdsregistrya"; 
		
		// NIST Registry (stored query interface)
		public static final String NIST_STORED_QUERY = "http://ihexds.nist.gov:9080/tf5/services/xdsregistrya";

		// NIST Secured Registry (stored query interface)
		public static final String NIST_STORED_QUERY_SECURED = "https://ihexds.nist.gov:9085/tf5/services/xdsregistrya"; 
		
		// IBM XDS.a Registry (stored query interface)
		public static final String IBM_STORED_QUERY = "http://xds-ibm.lgs.com:9080/IBMXDSRegistry/XDSa/Registry";

		// IBM XDS.a Secured Registry (stored query interface)
		public static final String IBM_STORED_QUERY_SECURED = "https://xds-ibm.lgs.com:9444/IBMXDSRegistry/XDSa/Registry";

		// OLD (prior to fall 2007) NIST Registry (query interface)
		public static final String OLD_NIST_REGISTRY_QUERY = "http://hcxw2k1.nist.gov:8080/xdsServices2/registry/soap/portals/yr3a/query";

		// OLD (prior to fall 2007) NIST Secured Registry (query interface)
		public static final String OLD_NIST_REGISTRY_QUERY_SECURED = "https://hcxw2k1.nist.gov:8443/xdsServices2/registry/soap/portals/yr3a/query";
		
		// OLD (prior to fall 2007) NIST Registry (stored query interface)
		public static final String OLD_NIST_STORED_QUERY = "http://hcxw2k1.nist.gov:8080/xdsServices2/registry/soap/portals/yr3a/storedquery";

		// OLD (prior to fall 2007) NIST Secured Registry (stored query interface)
		public static final String OLD_NIST_STORED_QUERY_SECURED = "https://hcxw2k1.nist.gov:8443/xdsServices2/registry/soap/portals/yr3a/storedquery";
		
		
	    ///////////////////
	    // XDS.b
	    ///////////////////
		// NIST XDS.b Registry (stored query interface)
//		public static final String NIST_B_STORED_QUERY = "https://192.168.0.165:8443/simed-registry/services/xdsregistryb";
	 static final String NIST_B_STORED_QUERY = "http://localhost:8889/simed-xds/services/xdsregistryb";

		// NIST XDS.b Secured Registry (stored query interface)
		public static final String NIST_B_STORED_QUERY_SECURED = "https://ihexds.nist.gov:9085/tf6/services/xdsregistryb";
		
		// NIST XDS.b Registry (stored query interface) - async
		public static final String NIST_B_STORED_QUERY_ASYNC = "http://ihexds.nist.gov:9080/tf6/services/registrybas";

		// NIST XDS.b Secured Registry (stored query interface) - async
		public static final String NIST_B_STORED_QUERY_SECURED_ASYNC = "https://ihexds.nist.gov:9085/tf6/services/registrybas";
		
		// NIST XDS.b Repository (for retrieve)
		public static final String NIST_B_REPOSITORY = "http://ihexds.nist.gov:9080/tf6/services/xdsrepositoryb";
		
		// NIST SECURED XDS.b Repository (for retrieve)
		public static final String NIST_B_REPOSITORY_SECURED = "https://ihexds.nist.gov:9085/tf6/services/xdsrepositoryb";
		

		// NIST XDS.b Repository (for retrieve) - async
		public static final String NIST_B_REPOSITORY_ASYNC = "http://ihexds.nist.gov:9080/tf6/services/repositorybas";
		
		//Synapse proxy for asynch testing
		public static final String SYNAPSE_PROXY = "http://localhost:8280/soap/";
		
		// NIST SECURED XDS.b Repository (for retrieve) - async
		public static final String NIST_B_REPOSITORY_SECURED_ASYNC = "https://ihexds.nist.gov:9085/tf6/services/repositorybas";
		
		// NIST XDS.b Repository Unique Id (for retrieve)
		public static final String NIST_B_REPOSITORY_UNIQUE_ID = "1.19.6.24.109.42.1.5"; 
		
		// NIST XCA Gateway (for test 12342, set as registry endpoint)
		public static final String NIST_GATEWAY_REGISTRY_EMULATOR = "http://ihexds.nist.gov:9080/tf6/services/xcaregistry";
		
		// NIST XCA Gateway (for test 12343, set as XCA gateway endpoint)
		public static final String NIST_GATEWAY = "http://ihexds.nist.gov:9080/tf6/services/xcarepository";
		
		// NIST XCA Home Community Id
		public static final String NIST_HOME_COMMUNITY_ID = "urn:oid:1.19.6.24.109.42.1.3";
		
		// IBM XDS.b Registry (stored query interface)
		public static final String IBM_B_STORED_QUERY = "http://xds-ibm.lgs.com:9080/IBMXDSRegistry/XDSb/SOAP12/Registry"; 

		// IBM XDS.b Secured Registry (stored query interface)
		public static final String IBM_B_STORED_QUERY_SECURED = "https://xds-ibm.lgs.com:9444/IBMXDSRegistry/XDSb/SOAP12/Registry"; 
		
		// IBM XDS.b Repository (for retrieve)
		public static final String IBM_B_REPOSITORY = "http://xds-ibm.lgs.com:9080/IBMXDSRepository/XDSb/SOAP12/Repository"; 
		
		// IBM SECURED XDS.b Repository (for retrieve)
		public static final String IBM_B_REPOSITORY_SECURED = "https://xds-ibm.lgs.com:9444/IBMXDSRepository/XDSb/SOAP12/Repository"; 
		
		// IBM XDS.b Repository Unique Id (for retrieve)
		public static final String IBM_B_REPOSITORY_UNIQUE_ID = "1.3.6.1.4.1.21367.2009.5.1.228"; 
		
	    ///////////////////
	    // Audit
	    ///////////////////
		// IBM Audit Repository
		public static final String IBM_ARR ="syslog://xds-ibm.lgs.com:514";
		
		// NIST Audit Repository
		public static final String NIST_ARR ="syslog://129.6.24.109:8087";
		
		/////////////////////////////////////////////////////////////////////////////////
		// Test Server Set up (this is the endpoint that will actually be used in testing)
		/////////////////////////////////////////////////////////////////////////////////
		public static URI XDS_B_REGISTRY_URI;
		public static URI XDS_B_REPOSITORY_URI; // for XDS.b only
		public static String XDS_B_REPOSITORY_UNIQUE_ID; // for XDS.b only
		public static URI XCA_GATEWAY_URI; // for XDS.b with XCA only
		public static String XCA_HOME_COMMUNITY_ID; // for XDS.b with XCA only
		public static URI AUDIT_REPOSITORY;
		
		static {
			// Set the XDS.a registry URI you want to use to one of the above endpoints
			// XDS.a not tested at 2010 connectathon and beyond
			
	/*		try {
				// Set the registry URI you want to use to 
				XDS_A_REGISTRY_URI = new URI();
			} catch (URISyntaxException e) {
				XDS_A_REGISTRY_URI = null;
			}*/
			
			// Set the XDS.b registry URI you want to use to one of the above endpoints
			try {
				// Set the registry URI you want to use to 
				XDS_B_REGISTRY_URI = new URI(NIST_B_STORED_QUERY);
			} catch (URISyntaxException e) {
				XDS_B_REGISTRY_URI = null;
			}
			
			// Set the XDS.b repository you want to use to one of the above endpoints
			try {
				// Set the registry URI you want to use to 
				XDS_B_REPOSITORY_URI = new URI(NIST_B_REPOSITORY);
			} catch (URISyntaxException e) {
				XDS_B_REPOSITORY_URI = null;
			}
			XDS_B_REPOSITORY_UNIQUE_ID = NIST_B_REPOSITORY_UNIQUE_ID;
			
			
			// Set the gateway you want to use to one of the above endpoints
			try {
				// Set the gateway you want to use to 
				XCA_GATEWAY_URI = new URI(NIST_GATEWAY);
			} catch (URISyntaxException e) {
				XCA_GATEWAY_URI = null;
			}
			XCA_HOME_COMMUNITY_ID = NIST_HOME_COMMUNITY_ID;
			
			
			// set the audit repository endpoint if you desire to additionally test auditing
			try {
				// Set the registry URI you want to use to 
				AUDIT_REPOSITORY = new URI(NIST_ARR);
			} catch (URISyntaxException e) {
				AUDIT_REPOSITORY = null;
			}
			
			// set TLS
			if(USE_TLS){
				System.setProperty("javax.net.ssl.keyStore", KEY_STORE);
				System.setProperty("javax.net.ssl.keyStorePassword", KEY_STORE_PASS);
				System.setProperty("javax.net.ssl.trustStore", TRUST_STORE);
				System.setProperty("javax.net.ssl.trustStorePassword", TRUST_STORE_PASS);
				System.setProperty("javax.net.debug","all");
				
				// 2009 connectathon additional cipher suites
				System.setProperty("https.ciphersuites","SSL_RSA_WITH_NULL_SHA,SSL_RSA_WITH_RC4_128_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,SSL_RSA_WITH_3DES_EDE_CBC_SHA");
			}
		}

		////////////////////////////////////////////////////////////////////
		//Get Documents Query /Get Related Documents Parameters (update this as needed)
		////////////////////////////////////////////////////////////////////
		
		// document entryUUID 
		//public static final String DOCUMENT_ENTRY_UUID = "urn:uuid:21f35040-61f2-3d5e-2762-001b773dad57";
		// ORACLE
		
		//public static final String DOCUMENT_ENTRY_UUID ="urn:uuid:2b87a57a-6b84-3d68-5f65-001b773dad57";
		
		//other
		public static final String DOCUMENT_ENTRY_UUID = "urn:uuid:b1155586-9b20-40ea-a529-f157a4f8fde2";
		
		// secure doc
		//public static final String DOCUMENT_ENTRY_UUID = "urn:uuid:7791d878-f788-8eee-3f43-000d60d00c08";
		
		// document uniqueId
		public static final String DOCUMENT_UNIQUE_ID ="1.2.3.4.5.1019";
		// secure doc
		//public static final String DOCUMENT_UNIQUE_ID ="1.3.6.1.4.1.21367.2009.1.2.166.105000030000008097.12296";
		
		/////////////////////////////////////////
		//Find Documents Query Parameters:  (update this as needed)
		/////////////////////////////////////////
		
		// patient ID
		public static final CX PATIENT_ID;
		static{
			// normal testing
	/*		PATIENT_ID = Hl7v2Factory.eINSTANCE.createCX();
			PATIENT_ID.setIdNumber("0859b9b8b1b64cd");
			PATIENT_ID.setAssigningAuthorityUniversalId("1.3.6.1.4.1.21367.2005.3.7");
			PATIENT_ID.setAssigningAuthorityUniversalIdType("ISO");*/
			
			// 2010 Connectathon 5655294897af4b7^^^&1.19.6.24.109.42.1.3&ISO
			PATIENT_ID = Hl7v2Factory.eINSTANCE.createCX();
			PATIENT_ID.setIdNumber("c6002e5679534ea"); //("NA5156-OHT");
			PATIENT_ID.setAssigningAuthorityUniversalId("1.3.6.1.4.1.21367.2005.3.7");
			PATIENT_ID.setAssigningAuthorityUniversalIdType("ISO");
			
			// NIST-XCA - d05ddc2efd5241f
	/*		PATIENT_ID = Hl7v2Factory.eINSTANCE.createCX();
			PATIENT_ID.setIdNumber("d05ddc2efd5241f");
			PATIENT_ID.setAssigningAuthorityUniversalId("1.3.6.1.4.1.21367.2005.3.7");
			PATIENT_ID.setAssigningAuthorityUniversalIdType("ISO");*/
		}
		
		// classCodes
		public static final CodedMetadataType[] CLASS_CODES;
		static{
			CLASS_CODES = null;
		}
		
		//creation date time range
		public static DateTimeRange[] CREATION_DATE_RANGES;
		static{
			try{
				DateTimeRange range = new DateTimeRange(
						DocumentEntryConstants.CREATION_TIME, "200412252300", "200501010800");
				CREATION_DATE_RANGES = null;
				/*new DateTimeRange[]{range};*/
			}catch(MalformedQueryException e){
				CREATION_DATE_RANGES = null;
			}
		}
				
		
		// practice setting codes
		public static final CodedMetadataType[] PRACTICE_SETTING_CODES;
		static{
			PRACTICE_SETTING_CODES = null;
		}
		
		// healthcare facility codes
		public static final CodedMetadataType[] HEALTHCARE_FACILITY_CODES;
		static{
			CodedMetadataType hcfc1 = MetadataFactory.eINSTANCE.createCodedMetadataType();
		/*	hcfc1.setCode("Children's Hospital");
			hcfc1.setSchemeName("1.2.3.4");*/
			
			CodedMetadataType hcfc2 = MetadataFactory.eINSTANCE.createCodedMetadataType();
		/*	hcfc2.setCode("Emergency Department");*/
			
			HEALTHCARE_FACILITY_CODES = null;//new CodedMetadataType[]{hcfc1, hcfc2};
		}

		
		// eventCodes
		public static final CodedMetadataType[] EVENT_CODES;
		static{
			CodedMetadataType event1 = MetadataFactory.eINSTANCE.createCodedMetadataType();
			event1.setCode("MPQ-eventcode-1");
			event1.setSchemeName("MPQ Testing");
			
			EVENT_CODES = new CodedMetadataType[]{event1}; 
			// EVENT_CODES = null;
		}
		
		// additional event codes to add subject to AND/OR semantics. [i] is a disjunctive clause to 
		//add to the query
		public static final CodedMetadataType[][] ADDITIONAL_EVENT_CODE_CLAUSES;
		static{
			ADDITIONAL_EVENT_CODE_CLAUSES = null;//new CodedMetadataType[1][1];
			/*ADDITIONAL_EVENT_CODE_CLAUSES[0][0] = MetadataFactory.eINSTANCE.createCodedMetadataType();
			ADDITIONAL_EVENT_CODE_CLAUSES[0][0].setCode("12345-6");*/
		}
		
		// authorPerson
		public static final XCN AUTHOR_PERSON;
		static{
			AUTHOR_PERSON = null;
		}
		
		// confidentiality codes (also used for GetFolderAndContents query)
		public static final CodedMetadataType[] CONFIDENTIALITY_CODES;
		static{
			CONFIDENTIALITY_CODES = null;//new CodedMetadataType[1];
			/*CONFIDENTIALITY_CODES[0] = MetadataFactory.eINSTANCE.createCodedMetadataType();
			CONFIDENTIALITY_CODES[0].setCode("N");*/
		}
		
		// additional conf codes to add subject to AND/OR semantics. [i] is a disjunctive clause to 
		//add to the query  (also used for GetFolderAndContents query)
		public static final CodedMetadataType[][] ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES;
		static{
			ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES = null;//new CodedMetadataType[1][1];
			/*ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES[0][0] = MetadataFactory.eINSTANCE.createCodedMetadataType();
			ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES[0][0].setCode("R");*/
		}
		
		// format codes (also used for GetFolderAndContents query)
		public static final CodedMetadataType[] FORMAT_CODES;
		static{
			FORMAT_CODES = null;
		}
		
		/////////////////////////////////////////
		//Get Folder And Contents Query Parameters:  (update this as needed)
		/////////////////////////////////////////
		// folder entry uuid
		public static final String FOLDER_UUID = "urn:uuid:aebd9d1b-65e3-405a-94e6-922c95298452"; //"urn:uuid:4c7aa6ba-4c72-7346-9639-000f1fd35f02";
		// folder unique id
		public static final String FOLDER_UNIQUE_ID = "1.2.3.4.5.988";//"1.3.6.1.4.1.21367.2009.1.2.166.104019007056046009.12354";

		
}
