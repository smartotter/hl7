/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package com.kangva.xds.document.consumer;

import java.net.URI;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.openhealthtools.ihe.xds.consumer.B_Consumer;

/**
 * Base test class for Mesa XDS.b Consumer testing
 * 
 * @author <a href="mailto:seknoop@us.ibm.com">Sarah Knoop</a>
 * 
 */
public abstract class B_ConsumerMesaTest {
	// logger
	private static final Logger logger = Logger
			.getLogger(B_ConsumerMesaTest.class);

	// Consumer instance
	protected B_Consumer c = null;

	@Before
	public void setUp() throws Exception {
		// set registry

		System.setProperty("javax.net.ssl.keyStore",
				TestConfiguration.KEY_STORE);
		System.setProperty("javax.net.ssl.keyStorePassword",
				TestConfiguration.KEY_STORE_PASS);
		System.setProperty("javax.net.ssl.trustStore",
				TestConfiguration.TRUST_STORE);
		System.setProperty("javax.net.ssl.trustStorePassword",
				TestConfiguration.TRUST_STORE_PASS);
		System.setProperty("javax.net.debug", "sslhandshake");


//		c = new B_Consumer(
//				new URI(
//						"http://ihexds.nist.gov:12080/tf6/services/xdsregistryb"));

		c = new B_Consumer(
				new URI(
//						"http://localhost:8888/axonmed-registry/services/xdsregistryb"));
						"https://192.168.1.18:89"));
		
		//fangzheng
//		c = new B_Consumer(
//				new URI(
//						"https://114.242.194.184:8011/axis2/services/xdsregistryb"));
		//hehua
//		c = new B_Consumer(
//				new URI(
//						"https://118.163.131.118:8011/axis2/services/xdsregistryb"));

//		 c = new B_Consumer(
//		 new URI(
//		 "https://192.168.0.165:8443/simed-registry/services/xdsregistryb"));

		// set repository
		c.getRepositoryMap()
				.put("1.19.6.24.109.42.1",
						new URI(
								"https://192.168.0.165:8443/simed-repository/services/xdsrepositoryb"));

//		c.getRepositoryMap()
//				.put("1.3.6.1.4.1.21367.2010.1.2.1125",
//						new URI(
//								"https://118.163.131.118:8021/axis2/services/xdsrepositoryb"));

		c.getRepositoryMap()
		.put("1.3.6.1.4.1.21367.2010.1.2.1125",
						new URI(
								"https://114.242.194.184:8021/axis2/services/xdsrepositoryb"));
	}

	@After
	public void tearDown() throws Exception {
	}

}
