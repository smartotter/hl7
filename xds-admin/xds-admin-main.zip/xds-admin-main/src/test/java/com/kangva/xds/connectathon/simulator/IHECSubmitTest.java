package com.kangva.xds.connectathon.simulator;

import static org.junit.Assert.fail;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMDocument;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.OMText;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.ServiceClient;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class IHECSubmitTest {

	private String registryEndpoint="http://ihexds.nist.gov:12080/tf6/services/xdsregistryb";
//	private String repositoryEndpoint="http://bipdc.axonmed.ca:6061/services/xdsrepositoryb?wsdl";
//	private String repositoryEndpoint="http://bipdc.axonmed.ca:6065/services/xdsagent?wsdl";
	
	private String requestFileName = "src/test/resources/testData/submit/newSubmit.xml";
	private String reportFileName = "src/test/resources/testData/submit/kos.dcm";
	private String responseFileName = "src/test/resources/testData/submit/response.xml";
	private ServiceClient serviceClient = null;
	OMNamespace xdsB = OMAbstractFactory.getOMFactory().createOMNamespace(
			"urn:ihe:iti:xds-b:2007", "xdsb");

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void submit() {
		try {

			serviceClient = new ServiceClient();
			
			serviceClient.getOptions().setTo(
					new EndpointReference(registryEndpoint));
			// serviceClient.getOptions().setProperty(HTTPConstants.CHUNKED,
			// "false");
			// serviceClient.getOptions().setTransportInProtocol(Constants.TRANSPORT_HTTP);
			serviceClient.getOptions().setProperty("enableMTOM", "true");
			// serviceClient.getOptions().setProperty("addMustUnderstandToAddressingHeaders",
			// Boolean.TRUE);
			// serviceClient.getOptions().setAction(
			// "urn:ihe:iti:2007:ProvideAndRegisterDocumentSet-b");
			// serviceClient.getOptions().setTimeOutInMilliSeconds(10000000);
			serviceClient.getOptions().setSoapVersionURI(
					"http://www.w3.org/2003/05/soap-envelope");

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		OMElement body = null;
		FileOutputStream fot = null;
		long sendSOAPBeginTime = 0, sendEndSOAPBeginTime = 0;
		try {
			body = createMetadata();
			sendSOAPBeginTime = System.currentTimeMillis();
			System.out.println("start send the soap");
			OMElement result = serviceClient.sendReceive(body);
			sendEndSOAPBeginTime = System.currentTimeMillis();

			fot = new FileOutputStream(responseFileName);
			result.serialize(fot);
			System.out.println(result.toString());

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("Time cost:"
					+ (sendEndSOAPBeginTime - sendSOAPBeginTime));
		}
	}

	private OMElement createMetadata() {
		OMElement requestOMElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		XMLStreamReader parser = null;
		try {
			parser = XMLInputFactory.newInstance().createXMLStreamReader(
					new FileInputStream(requestFileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (XMLStreamException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (FactoryConfigurationError e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		StAXOMBuilder builder = new StAXOMBuilder(parser);
		// get the root element
		// OMElement documentElement = builder.getDocumentElement();
		OMDocument mataDataDocument = builder.getDocument();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);
		requestOMElement = mataDataDocument.getOMDocumentElement();

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return requestOMElement;
	}

	private OMElement createProvideAndRegisterDocumentSet() {
		OMElement provideAndRegisterDocumentSetRequestElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		// get the root element
		// OMElement documentElement = builder.getDocumentElement();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);

		provideAndRegisterDocumentSetRequestElement = OMAbstractFactory
				.getOMFactory().createOMElement(
						"ProvideAndRegisterDocumentSetRequest", xdsB);

		provideAndRegisterDocumentSetRequestElement.addChild(createMetadata());

		String documentID = "doc1";
		DataHandler dataHandler = new DataHandler(new FileDataSource(
				reportFileName));
		OMText t = OMAbstractFactory.getOMFactory().createOMText(dataHandler,
				true);
		t.setOptimize(true);
		OMElement document = OMAbstractFactory.getOMFactory().createOMElement(
				"Document", xdsB);
		document.addAttribute("id", documentID, null);
		document.addChild(t);
		provideAndRegisterDocumentSetRequestElement.addChild(document);

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return provideAndRegisterDocumentSetRequestElement;
	}

}
