package com.kangva.xds.document.source;

import static org.junit.Assert.fail;

import org.apache.axiom.soap.SOAPFactory;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.junit.Test;

public class Axis2RegisterTest {

	/**
	 * Apache Axis2 client sender mechanism
	 */
	private ServiceClient mSender;

	/**
	 * Apache Axis2 options
	 */
	private Options mOptions;

	/**
	 * SOAP Factory for the respective types
	 */
	private SOAPFactory soapFactory;
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
