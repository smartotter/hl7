package com.kangva.xds.connectathon.simulator;

import java.io.File;
import java.net.URISyntaxException;

import org.apache.log4j.Logger;
import org.openhealthtools.ihe.common.hl7v2.CX;
import org.openhealthtools.ihe.common.hl7v2.Hl7v2Factory;
import org.openhealthtools.ihe.xds.consumer.B_Consumer;

public class DocumentConsumerSimulator {

	private static final Logger logger = Logger
			.getLogger(DocumentConsumerSimulator.class);

//	static final String REGISTRY_URI = "https://118.163.131.118:8011/axis2/services/xdsregistryb";
//	static final String REGISTRY_URI = "https://localhost:9443/simed-registry/services/xdsregistryb";

	protected B_Consumer c = null;
	protected CX patientId = null;

	public DocumentConsumerSimulator() {
		super();
	}

	protected void setPatientId() {
		patientId = Hl7v2Factory.eINSTANCE.createCX();
		patientId.setIdNumber("c6002e5679534eg"); //("NA5156-OHT");
		patientId.setAssigningAuthorityUniversalId("1.3.6.1.4.1.21367.2005.3.7");
		patientId.setAssigningAuthorityUniversalIdType("ISO");
	}

	protected void initialDocumentConsumer() throws URISyntaxException {
		logger.info("Initiat the document consumer");

		File conf = new File(SimulatorTestConfiguration.LOG4J_PATH);
		org.apache.log4j.xml.DOMConfigurator.configure(conf.getAbsolutePath());
		logger.debug("***************** SUBMIT TEST ************************");
//		logger.debug(TestUtils.formTimestamp());
		
		System.setProperty("javax.net.ssl.keyStore",
				SimulatorTestConfiguration.KEY_STORE);
		System.setProperty("javax.net.ssl.keyStorePassword",
				SimulatorTestConfiguration.KEY_STORE_PASS);
		System.setProperty("javax.net.ssl.trustStore",
				SimulatorTestConfiguration.TRUST_STORE);
		System.setProperty("javax.net.ssl.trustStorePassword",
				SimulatorTestConfiguration.TRUST_STORE_PASS);
		System.setProperty("javax.net.debug", "sslhandshake");

		// hehua
		c = new B_Consumer(SimulatorTestConfiguration.XDS_B_REGISTRY_URI);

		// set repository
		c.getRepositoryMap().putAll(SimulatorTestConfiguration.repositoryMap);

	}

}