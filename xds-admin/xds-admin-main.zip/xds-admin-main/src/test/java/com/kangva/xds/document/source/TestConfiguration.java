package com.kangva.xds.document.source;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;

public class TestConfiguration {
	//basics
		public static final String LOG4J_PATH = "./resources/conf/submitTest_log4j.xml";
		org.openhealthtools.ihe.atna.nodeauth.handlers.TLSEnabledSocketHandler a;
	    //ATNA logging enable/disablement
	    public static final boolean DO_AUDIT = false; // change to 'true' to enable auditing
	    public static final String INITIATING_USER = "some user";
	    public static final String AUDIT_SOURCE_ID = "OTHER_OHT";
	    
	    // TLS enablement
	    public static final boolean USE_TLS = true; // change to 'true' to enable TLS
//	    public static final String KEY_STORE = "src/test/resources/security/OpenXDS_2013_Keystore.p12";
	    public static final String KEY_STORE_PASS ="123456";
//	    public static final String KEY_STORE = "src/test/resources/security/keystore-125.jks";
	    public static final String KEY_STORE = "src/test/resources/security/keystore.p12";
//	    public static final String KEY_STORE_PASS ="changeit";
//	    public static final String TRUST_STORE="src/test/resources/security/OpenXDS_2013_Truststore.jks";
	    public static final String TRUST_STORE_PASS="123456";
//	    public static final String TRUST_STORE="src/test/resources/security/keystore-125.jks";
	    public static final String TRUST_STORE = "src/test/resources/security/OpenXDS_2016_Truststore.jks";
//	    public static final String TRUST_STORE_PASS="changeit";
	    
	    // Server Options
	    //////////////////////////////////////////////////////////////////////////////////////////////
	    // XDS.a is deprecated as of TF6 (2009) - not tested in the 2010 NA Connectathon and beyond
	    //////////////////////////////////////////////////////////////////////////////////////////////
	    // NIST Repository 
		public static final String NIST = "http://ihexds.nist.gov:9080/tf6/services/xdsrepositorya";
			
	    // NIST SECURED Repository 
		public static final String NIST_SECURED = "https://ihexds.nist.gov:9085/tf6/services/xdsrepositorya";
		
		// IBM 2007 Test sever
		public static final String IBM = "http://xds-ibm.lgs.com:9081/IBMXDSRepository/XDSa/ProvideAndRegister";
		
		// IBM SECURED 2007 Test sever 
		public static final String IBM_SECURED = "https://xds-ibm.lgs.com:9444/IBMXDSRepository/XDSa/ProvideAndRegister";
		
		// OLD (prior to fall 2007) NIST Repository 
		public static final String OLD_NIST = "http://hcxw2k1.nist.gov:8080/xdsServices2/registry/soap/portals/yr3a/repository";

		// OLD (prior to fall 2007) NIST SECURED Repository 
		public static final String OLD_NIST_SECURED = "https://hcxw2k1.nist.gov:8443/xdsServices2/registry/soap/portals/yr3a/repository";
		
	    ///////////////////
	    // XDS.b
	    ///////////////////
		// NIST XDS.b Repository
		public static final String NIST_B = "http://ihexds.nist.gov:9080/tf6/services/xdsrepositoryb";
		
		// NIST SECURED XDS.b Repository
		public static final String NIST_B_SECURED = "https://ihexds.nist.gov:9085/tf6/services/xdsrepositoryb";
		
		// NIST XDS.b Repository - async
		public static final String NIST_B_REPOSITORY_ASYNC = "http://ihexds.nist.gov:9080/tf6/services/repositorybas";
		
		// NIST SECURED XDS.b - async
		public static final String NIST_B_REPOSITORY_SECURED_ASYNC = "https://ihexds.nist.gov:9085/tf6/services/repositorybas";
		
		// IBM XDS.b Repository
		public static final String IBM_B = "http://xds-ibm.lgs.com:9080/IBMXDSRepository/XDSb/SOAP12/Repository"; 
		
		// IBM SECURED XDS.b Repository
		public static final String IBM_B_SECURED = "https://xds-ibm.lgs.com:9444/IBMXDSRepository/XDSb/SOAP12/Repository"; 
		
		/////////////////////////////////////////
		// Endpoints for special MESA tests
		/////////////////////////////////////////
		// 11728
		public static final String NIST_11728 = "http://ihexds.nist.gov:9080/tf6/services/test11728";

		// 11729
		public static final String NIST_11729 = "http://ihexds.nist.gov:9080/tf6/services/test11729";
		
		// 11747
		public static final String NIST_11747 = "http://ihexds.nist.gov:9080/tf6/services/repositoryA2doc";
		
		// 11748
		public static final String NIST_11748 = "http://ihexds.nist.gov:9080/tf6/services/test11748";
		
		// 11730
		public static final String NIST_11730 = "http://ihexds.nist.gov:9080/tf6/services/test11730";
		
		// 11969
		public static final String NIST_11969 = "http://ihexds.nist.gov:9080/tf6/services/test11969";
		
		// 11970
		public static final String NIST_11970 = "http://ihexds.nist.gov:9080/tf6/services/test11970";
		
		// 11971
		public static final String NIST_11971 = "http://ihexds.nist.gov:9080/tf6/services/test11971";
		
		// 11972
		public static final String NIST_11972 = "http://ihexds.nist.gov:9080/tf6/services/test11972";
		
		// 11973
		public static final String NIST_11973 = "http://ihexds.nist.gov:9080/tf6/services/test11973";
		
		// 11974
		public static final String NIST_11974 = "http://ihexds.nist.gov:9080/tf6/services/test11974";
		
		// 12047
		public static final String NIST_12047 = "http://ihexds.nist.gov:9080/tf6/services/repositoryB2doc";
		
		// 12049
		public static final String NIST_12049 = "http://ihexds.nist.gov:9080/tf6/services/repositoryBonedoc";
		
		
	    ///////////////////
	    // Audit
	    ///////////////////
		// IBM Audit Repository
		public static final String IBM_ARR ="syslog://xds-ibm.lgs.com:514";
		
		// NIST Audit Repository
		public static final String NIST_ARR ="syslog://129.6.24.109:8087";
		
		
		// Test Server Set up (this is the endpoint that will actually be used in testing)
		public static URI XDS_A_REPOSITORY_URI;
		public static URI XDS_B_REPOSITORY_URI;
		public static URI AUDIT_REPOSITORY;
		static {
			// Set the XDS.a repository URI you want to use to one of the above endpoings
			// XDS.a not tested at 2010 connectathon and beyond
			/*
			try {
				// Set the registry URI you want to use to 
				XDS_A_REPOSITORY_URI = new URI(NIST);

			} catch (URISyntaxException e) {
				XDS_A_REPOSITORY_URI = null;
			}*/
			
			// Set the XDS.b repository URI you want to use to one of the above endpoings
			try {
				// Set the registry URI you want to use to 
				XDS_B_REPOSITORY_URI = new URI(NIST_B);
			} catch (URISyntaxException e) {
				XDS_B_REPOSITORY_URI = null;
			}
			// set the audit repository endpoint if you desire to additionally test auditing
			try {
				// Set the registry URI you want to use to 
				AUDIT_REPOSITORY = new URI(NIST_ARR);
			} catch (URISyntaxException e) {
				AUDIT_REPOSITORY = null;
			}
			
			// set TLS
			if(USE_TLS){
				System.setProperty("javax.net.ssl.keyStore", KEY_STORE);
				System.setProperty("javax.net.ssl.keyStorePassword", KEY_STORE_PASS);
				System.setProperty("javax.net.ssl.trustStore", TRUST_STORE);
				System.setProperty("javax.net.ssl.trustStorePassword", TRUST_STORE_PASS);
				System.setProperty("javax.net.debug", "sslhandshake");
				
				// 2009 connectathon additional cipher suites
				//System.setProperty("https.ciphersuites","SSL_RSA_WITH_NULL_SHA,SSL_RSA_WITH_RC4_128_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,SSL_RSA_WITH_3DES_EDE_CBC_SHA");
			}
		}
		
		// oid for your organization
		public static final String ORGANIZATIONAL_OID = "1.3.6.1.4.1.21367.2010.1.2.166";
		
		// uuid for document replacement, MUST exist as 'Approved' in the Registry, Obtain 
		// this information by running a query first (XDS Consumer) or submitting a document
		// via Mesa11746 or Mesa12049 and use the uuid generated by that test
		public static final String REPLACE_UUID = "urn:uuid:99659732-d95c-3dd6-93f9-001b773dad57";

}
