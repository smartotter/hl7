package com.kangva.xds.connectathon.simulator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.UUID;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMDocument;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axiom.soap.SOAPHeaderBlock;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.ServiceClient;

import sun.misc.BASE64Decoder;

public class IHECRetrieveDocumentSetClient {

	// private String repositoryEndpoint =
	// "http://lifeimage/services/xdsrepositoryb?wsdl";
//	private String repositoryEndpoint = "https://64.28.75.46/services/xdsrepositoryb?wsdl";
	private String repositoryEndpoint="http://localhost:8888/simed-repository/services/xdsrepositoryb";
//	private String repositoryEndpoint="http://202.127.1.101:8989/simed-repository/services/xdsrepositoryb";
//	 private String repositoryEndpoint =
//	 "http://www.rsnaclearinghouse.com:9090/services/xdsrepositoryb?wsdl";
	// private String repositoryEndpoint =
	// "http://192.168.0.152:8080/services/xdsrepositoryb";
	private String requestFileName = "src/test/resources/testData/retrieveDocumentSet/RetrieveDocumentSetRequest.xml";
	private String responseFileName = "src/test/resources/testData/retrieveDocumentSet/RetrieveDocumentSetResponse.xml";
	private String kosFileName = "src/test/resources/testData/retrieveDocumentSet/kos.dcm";
	
	private ServiceClient serviceClient = null;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IHECRetrieveDocumentSetClient xdsClient = new IHECRetrieveDocumentSetClient();
		xdsClient.retrieve();
		javax.mail.internet.ParseException s;
	}

	public void retrieve() {
		try {

			serviceClient = new ServiceClient();
			// serviceClient.engageModule("addressing");

			System.setProperty("javax.net.ssl.keyStore", "src\\main\\resources\\keystore.jks");
//			System.setProperty("javax.net.ssl.keyStore", "D:\\lab\\RSNA\\certificate\\labtest\\dell.keystore");
			System.setProperty("javax.net.ssl.keyStorePassword", "123456");
			// System.setProperty("javax.net.ssl.trustStore",
			// "conf/mayotruststore.jks");
			System.setProperty("javax.net.ssl.trustStore", "src\\main\\resources\\keystore.jks");
//			System.setProperty("javax.net.ssl.trustStore", "D:\\lab\\RSNA\\certificate\\labtest\\dell.keystore");
			System.setProperty("javax.net.ssl.trustStorePassword", "123456");
			// System.setProperty("javax.net.debug", "ssl");
			// System.setProperty("https.protocols", "TLSv1");
			// System.setProperty("java.protocol.handler.pkgs","javax.net.ssl");
			// System.setProperty("https.cipherSuites",
			// "SSL_RSA_WITH_3DES_EDE_CBC_SHA,TLS_RSA_WITH_AES_128_CBC_SHA");
			serviceClient.getOptions().setTo(
					new EndpointReference(repositoryEndpoint));
			// serviceClient.getOptions().setProperty(HTTPConstants.CHUNKED,
			// "false");
			// serviceClient.getOptions().setTransportInProtocol(Constants.TRANSPORT_HTTP);
			serviceClient.getOptions().setProperty("enableMTOM", "true");
//			serviceClient.getOptions().setProperty(
//					"addMustUnderstandToAddressingHeaders", Boolean.TRUE);
			// serviceClient.getOptions().setAction(
			// "urn:ihe:iti:2007:ProvideAndRegisterDocumentSet-b");
			serviceClient.getOptions().setTimeOutInMilliSeconds(10000000);
			serviceClient.getOptions().setSoapVersionURI(
					"http://www.w3.org/2003/05/soap-envelope");

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		OMElement body = null;
		FileOutputStream fot = null;
		OMElement result = null;
		long sendSOAPBeginTime = 0, sendEndSOAPBeginTime = 0;
		try {
			body = createRetrieveDocumentSet();
			for (int i = 0; i < 1; i++) {
				sendSOAPBeginTime = System.currentTimeMillis();
				System.out.println("start "+i+" send the soap");
				System.out.println(body.toString());
				SOAPFactory factory = OMAbstractFactory.getSOAP12Factory();
				OMNamespace addressNamespace = factory.createOMNamespace(
						"http://www.w3.org/2005/08/addressing", "a");
				SOAPHeaderBlock actionSOAPHeader = factory.createSOAPHeaderBlock("Action",
						addressNamespace);
				actionSOAPHeader.setMustUnderstand(true);
						actionSOAPHeader.addChild(factory.createOMText("urn:ihe:iti:2007:RetrieveDocumentSet"));
				serviceClient.addHeader(actionSOAPHeader);
				SOAPHeaderBlock messageIDSOAPHeader = factory.createSOAPHeaderBlock(
						"MessageID", addressNamespace);
				messageIDSOAPHeader.addChild(factory.createOMText("urn:uuid:"
						+ (UUID.randomUUID()).toString()));
				serviceClient.addHeader(messageIDSOAPHeader);
				SOAPHeaderBlock toSOAPHeader = factory.createSOAPHeaderBlock("To",
						addressNamespace);
				toSOAPHeader.setMustUnderstand(true);
				toSOAPHeader.addChild(factory.createOMText("http://192.168.0.167:8889/simed-repository/services/xdsrepositoryb"));
				serviceClient.addHeader(toSOAPHeader);
//				SOAPHeaderBlock replyToSOAPHeader = factory.createSOAPHeaderBlock("ReplyTo",
//						addressNamespace);
//				SOAPHeaderBlock addressOMElement = factory.createSOAPHeaderBlock("Address",
//						addressNamespace);
//				addressOMElement
//						.setText("http://www.w3.org/2005/08/addressing/anonymous");
//				replyToSOAPHeader.addChild(addressOMElement);
//				serviceClient.addHeader(replyToSOAPHeader);
				result = serviceClient.sendReceive(body);
				sendEndSOAPBeginTime = System.currentTimeMillis();
				System.out.println(i+" Time cost:"
						+ (sendEndSOAPBeginTime - sendSOAPBeginTime));

			}
			Iterator documentIte = result.getChildElements();
			while (documentIte.hasNext()) {

				
				OMElement childElemnt = (OMElement) documentIte.next();
				Iterator documentChildIte = childElemnt
						.getChildrenWithLocalName("Document");
				while (documentChildIte.hasNext()) {
					System.out.println("Get the image");
					OMElement documentChildChildElement=(OMElement)documentChildIte.next();
					BASE64Decoder decoder = new BASE64Decoder();
					try {
						byte[] b = decoder.decodeBuffer(documentChildChildElement.getText());
						fot = new FileOutputStream(kosFileName);
						fot.write(b);
					} catch (Exception e) {
						System.out.println(e);
					}
				}
			}
			fot = new FileOutputStream(responseFileName);
			result.serialize(fot);
			 System.out.println(result.toString());

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

		}
	}

	private OMElement createRetrieveDocumentSet() {
		OMElement requestOMElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		XMLStreamReader parser = null;
		try {
			parser = XMLInputFactory.newInstance().createXMLStreamReader(
					new FileInputStream(requestFileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (XMLStreamException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (FactoryConfigurationError e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		StAXOMBuilder builder = new StAXOMBuilder(parser);
		// get the root element
		// OMElement documentElement = builder.getDocumentElement();
		OMDocument mataDataDocument = builder.getDocument();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);
		requestOMElement = mataDataDocument.getOMDocumentElement();

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return requestOMElement;
	}
}

