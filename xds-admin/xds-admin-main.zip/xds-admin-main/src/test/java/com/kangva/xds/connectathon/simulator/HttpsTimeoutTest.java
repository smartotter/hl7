package com.kangva.xds.connectathon.simulator;

import static org.junit.Assert.fail;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class HttpsTimeoutTest {

	String keyStoreFileName = "src/test/resources/security/OpenXDS_2013_Keystore.p12";
	String trustStoreFileName = "src/test/resources/security/OpenXDS_2013_Truststore.jks";
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance("TLS");
			KeyManagerFactory keyManagerFactory = KeyManagerFactory
					.getInstance("SunX509");
			TrustManagerFactory trustManagerFactory = TrustManagerFactory
					.getInstance("SunX509");

			KeyStore keyStore = KeyStore.getInstance("JKS");
			KeyStore trustKeyStore = KeyStore.getInstance("JKS");
			keyStore.load(new FileInputStream(keyStoreFileName),
					"123456".toCharArray());
			trustKeyStore.load(new FileInputStream(trustStoreFileName),
					"123456".toCharArray());

			keyManagerFactory.init(keyStore, "123456".toCharArray());
			trustManagerFactory.init(trustKeyStore);

			sslContext.init(keyManagerFactory.getKeyManagers(),
					trustManagerFactory.getTrustManagers(), null);

			// 根据上面配置的SSL上下文来产生SSLServerSocketFactory,与通常的产生方法不同
			SSLSocketFactory factory = sslContext.getSocketFactory();

			URL url = null;
			url = new URL("https://192.168.1.157:9443/simed-registry/services/xdsregistryb");
			HttpsURLConnection httpConnection = (HttpsURLConnection) url
					.openConnection();
			httpConnection.setSSLSocketFactory(factory);
			httpConnection.setConnectTimeout(5000);
			int responseCode = httpConnection.getResponseCode();
			System.out.println(responseCode);
			if (responseCode == 200) {
				return;
			} 
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Throwable e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testPing(){
		String host = "192.168.1.119";
				int timeOut = 3000;
		try {
			boolean status = InetAddress.getByName(host).isReachable(timeOut);
			System.out.println(status);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
