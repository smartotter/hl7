package com.kangva.xds.document.consumer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.openhealthtools.ihe.xds.consumer.response.XDSRetrieveDocumentSetResponseType;
import org.openhealthtools.ihe.xds.consumer.retrieve.DocumentRequestType;
import org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveDocumentSetRequestType;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetDocumentsQuery;
import org.openhealthtools.ihe.xds.document.XDSDocument;
import org.openhealthtools.ihe.xds.metadata.DocumentEntryType;
import org.openhealthtools.ihe.xds.response.DocumentEntryResponseType;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;
import org.openhealthtools.ihe.xds.response.XDSResponseType;

public class Mesa12076 extends B_ConsumerMesaTest{

	// logger
	private static final Logger logger = Logger.getLogger(Mesa12076.class);

	@Test
	public void test() throws Exception {
		logger.debug("BEGIN MESA 12076");
		// make query
		GetDocumentsQuery q = new GetDocumentsQuery(
				new String[] { "1.3.6.1.4.1.21367.2010.1.2.192.168.2.101.20130913090439.2" }, false);

		// run query
		XDSQueryResponseType queryResponse = null;
		try {
			queryResponse = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + queryResponse.getStatus().getName());
		logger.debug("Returned "
				+ queryResponse.getDocumentEntryResponses().size()
				+ " documents.");

		if (queryResponse == null) {
			logger.fatal("NO DOCUMENTS RETURNED from QUERY. CANNOT COMPLETE TEST");
			throw new Exception(
					"NO DOCUMENTS RETURNED from QUERY. CANNOT COMPLETE TEST");
		}
		if (queryResponse.getDocumentEntryResponses().size() == 0) {
			logger.fatal("NO DOCUMENTS RETURNED from QUERY. CANNOT COMPLETE TEST");
			throw new Exception(
					"NO DOCUMENTS RETURNED from QUERY. CANNOT COMPLETE TEST");
		}

		// get the first document entry and retrieve
		DocumentEntryType docEntry = ((DocumentEntryResponseType) queryResponse
				.getDocumentEntryResponses().get(0)).getDocumentEntry();
		logger.debug("Getting document with URI: " + docEntry.getUri());

		// build the document request
		RetrieveDocumentSetRequestType retrieveRequest = org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveFactory.eINSTANCE
				.createRetrieveDocumentSetRequestType();
		DocumentRequestType documentRequest = org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveFactory.eINSTANCE
				.createDocumentRequestType();
		documentRequest.setRepositoryUniqueId(docEntry.getRepositoryUniqueId());
		documentRequest
				.setHomeCommunityId(((DocumentEntryResponseType) queryResponse
						.getDocumentEntryResponses().get(0))
						.getHomeCommunityId());
		documentRequest.setDocumentUniqueId(docEntry.getUniqueId());

		retrieveRequest.getDocumentRequest().add(documentRequest);

		// execute retrieve
		XDSResponseType response = null;
		try {
			response = c.retrieveDocumentSet(retrieveRequest, 
					docEntry.getPatientId());
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		if(response instanceof XDSRetrieveDocumentSetResponseType){
			XDSRetrieveDocumentSetResponseType retrieveDocumentSetResponseType = (XDSRetrieveDocumentSetResponseType)response;
			logger.debug("Returned " + retrieveDocumentSetResponseType.getAttachments().size() + " documents.");
			if (retrieveDocumentSetResponseType.getAttachments().size() > 0) {
				XDSDocument document = (XDSDocument) retrieveDocumentSetResponseType.getAttachments().get(0);
				logger.error("Document Content:"+inputStream2String(document.getStream()));
				logger.debug("First document returned: " + document.toString());
			}
		}
		
		logger.debug("DONE MESA 12076");
	}

	public String inputStream2String(InputStream is)
            throws UnsupportedEncodingException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is,
                "utf-8"));
        StringBuffer sb = new StringBuffer();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
