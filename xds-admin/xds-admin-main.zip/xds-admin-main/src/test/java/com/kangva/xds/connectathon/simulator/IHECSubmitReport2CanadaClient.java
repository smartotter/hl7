package com.kangva.xds.connectathon.simulator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMDocument;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.OMText;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.ServiceClient;

public class IHECSubmitReport2CanadaClient {

//		private String repositoryEndpoint = "https://172.30.33.243/services/xdsrepositoryb?wsdl";
//	private String repositoryEndpoint = "http://192.168.0.93:8080/com.axonmed.xds.war-0.0.1-SNAPSHOT/repositoryb?wsdl";
//		private String repositoryEndpoint = "http://192.168.0.165:8888/axiss/services/repositoryb?wsdl";
	//private String repositoryEndpoint="https://clearinghouse.lifeimage.com/services/xdsrepositoryb?wsdl";
//	private String repositoryEndpoint="https://118.163.131.118:8021/axis2/services/xdsrepositoryb";
	private String repositoryEndpoint="http://localhost:8080/DocumentRepository_Service/XDS_b_DocumentRepository";
//	private String repositoryEndpoint="http://bipdc.axonmed.ca:6061/services/xdsrepositoryb?wsdl";
//	private String repositoryEndpoint="http://bipdc.axonmed.ca:6065/services/xdsagent?wsdl";
	
	private String requestFileName = "src/test/resources/testData/submit/RegisterDocumentSet.xml";
	private String reportFileName = "src/test/resources/testData/submit/newSubmit.xml";
	private String responseFileName = "src/test/resources/testData/submit/response.xml";
	private ServiceClient serviceClient = null;
	OMNamespace xdsB = OMAbstractFactory.getOMFactory().createOMNamespace(
			"urn:ihe:iti:xds-b:2007", "xdsb");

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IHECSubmitReport2CanadaClient xdsClient = new IHECSubmitReport2CanadaClient();
		xdsClient.retrieve();
	}

	public void retrieve() {
		try {

			serviceClient = new ServiceClient();
			//	serviceClient.engageModule("addressing");
			serviceClient = new ServiceClient();
			//	serviceClient.engageModule("addressing");
				System.setProperty("javax.net.ssl.keyStore", "src\\main\\resources\\keystore.jks");
//				System.setProperty("javax.net.ssl.keyStore", "D:\\lab\\RSNA\\certificate\\labtest\\dell.keystore");
				System.setProperty("javax.net.ssl.keyStorePassword", "123456");
				// System.setProperty("javax.net.ssl.trustStore",
				// "conf/mayotruststore.jks");
				System.setProperty("javax.net.ssl.trustStore", "src\\main\\resources\\keystore.jks");
//				System.setProperty("javax.net.ssl.trustStore", "D:\\lab\\RSNA\\certificate\\labtest\\dell.keystore");
				System.setProperty("javax.net.ssl.trustStorePassword", "123456");
				// System.setProperty("javax.net.debug", "ssl");
				// System.setProperty("https.protocols", "TLSv1");
				// System.setProperty("java.protocol.handler.pkgs","javax.net.ssl");
				// System.setProperty("https.cipherSuites",
				// "SSL_RSA_WITH_3DES_EDE_CBC_SHA,TLS_RSA_WITH_AES_128_CBC_SHA");
				serviceClient.getOptions().setTo(
						new EndpointReference(repositoryEndpoint));
//				 serviceClient.getOptions().setProperty(HTTPConstants.CHUNKED,
//				 "false");
//				 serviceClient.getOptions().setTransportInProtocol(Constants.TRANSPORT_HTTP);
				serviceClient.getOptions().setProperty("enableMTOM", "true");
//				serviceClient.getOptions().setProperty("addMustUnderstandToAddressingHeaders", Boolean.TRUE);
//				 serviceClient.getOptions().setAction(
//				 "urn:ihe:iti:2007:ProvideAndRegisterDocumentSet-b");
//				serviceClient.getOptions().setTimeOutInMilliSeconds(10000000);
				serviceClient.getOptions().setSoapVersionURI(
						"http://www.w3.org/2003/05/soap-envelope");

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		OMElement body = null;
		FileOutputStream fot = null;
		long sendSOAPBeginTime = 0, sendEndSOAPBeginTime = 0;
		try {
			body = createProvideAndRegisterDocumentSet();
			sendSOAPBeginTime = System.currentTimeMillis();
			System.out.println("start send the soap");
			OMElement result = serviceClient.sendReceive(body);
			sendEndSOAPBeginTime = System.currentTimeMillis();

			fot = new FileOutputStream(responseFileName);
			result.serialize(fot);
			System.out.println(result.toString());

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("Time cost:"
					+ (sendEndSOAPBeginTime - sendSOAPBeginTime));
		}
	}

	private OMElement createMetadata() {
		OMElement requestOMElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		XMLStreamReader parser = null;
		try {
			parser = XMLInputFactory.newInstance().createXMLStreamReader(
					new FileInputStream(requestFileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (XMLStreamException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (FactoryConfigurationError e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		StAXOMBuilder builder = new StAXOMBuilder(parser);
		// get the root element
		// OMElement documentElement = builder.getDocumentElement();
		OMDocument mataDataDocument = builder.getDocument();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);
		requestOMElement = mataDataDocument.getOMDocumentElement();

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return requestOMElement;
	}

	private OMElement createProvideAndRegisterDocumentSet() {
		OMElement provideAndRegisterDocumentSetRequestElement = null;
		long buildSOAPBeginTime = System.currentTimeMillis();

		// get the root element
		// OMElement documentElement = builder.getDocumentElement();

		// OMElement metaDataElement = fac.createOMElement(new
		// QName("sitp"),mataDataDcoment);

		provideAndRegisterDocumentSetRequestElement = OMAbstractFactory
				.getOMFactory().createOMElement(
						"ProvideAndRegisterDocumentSetRequest", xdsB);

		provideAndRegisterDocumentSetRequestElement.addChild(createMetadata());

		String documentID = "doc1";
		DataHandler dataHandler = new DataHandler(new FileDataSource(
				reportFileName));
		OMText t = OMAbstractFactory.getOMFactory().createOMText(dataHandler,
				true);
		t.setOptimize(true);
		OMElement document = OMAbstractFactory.getOMFactory().createOMElement(
				"Document", xdsB);
		document.addAttribute("id", documentID, null);
		document.addChild(t);
		provideAndRegisterDocumentSetRequestElement.addChild(document);

		long buildSOAPStopTime = System.currentTimeMillis();
		System.err.println("Elapsed building time in millisecond: "
				+ ((buildSOAPStopTime - buildSOAPBeginTime)));

		return provideAndRegisterDocumentSetRequestElement;
	}

}
