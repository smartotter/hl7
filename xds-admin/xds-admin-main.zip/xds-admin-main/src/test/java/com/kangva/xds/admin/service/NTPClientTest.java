package com.kangva.xds.admin.service;

import java.util.Date;

import org.junit.Test;

public class NTPClientTest {

	@Test
	public void test(){
		for(int i =0;i<100;i++){

			NTPClient nptc = new NTPClient();
			Date date = nptc.processResponse("115.28.122.198");
			System.out.println("date:"+date);
		}
	}
}
