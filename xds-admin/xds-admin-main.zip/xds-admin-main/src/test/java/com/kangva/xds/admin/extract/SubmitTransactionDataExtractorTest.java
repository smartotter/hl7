package com.kangva.xds.admin.extract;

import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.junit.Assert;
import org.junit.Test;
import org.openhealthtools.ihe.xds.metadata.ProvideAndRegisterDocumentSetType;
import org.openhealthtools.ihe.xds.metadata.transform.EbXML_3_0ProvideAndRegisterDocumentSetTransformer;
import org.openhealthtools.ihe.xds.source.SubmitTransactionData;
import org.openhealthtools.ihe.xds.source.utils.EbXML_3_0MetadataUtils;
import org.springframework.mock.web.MockHttpServletRequest;
import org.w3c.dom.Element;

public class SubmitTransactionDataExtractorTest {

	@Test
	public void test() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest("POSTT", "/services/xdsrepositoryb");
		request.addParameter("patientId", "ABC201309261134^^^&2.16.840.1.113883.3.72.5.9.1&ISO");
		request.addParameter("fileUploadName", "src/test/resources/sampleresponse.xml");
		request.addParameter("submissionSetAuthorPerson", "张三");

		SubmitTransactionData result = new SubmitTransactionData();
		SubmitTransactionDataExtractor.extract(request, "orgnizationId",result);
		Assert.assertNotNull(result);
		System.out.println(result.toString());
		EbXML_3_0ProvideAndRegisterDocumentSetTransformer setTransformer = new EbXML_3_0ProvideAndRegisterDocumentSetTransformer();

		// Transform our P&R request metadata to ebXML 3.0
		ProvideAndRegisterDocumentSetType meta = result.getMetadata();
		setTransformer.transform(meta);

		// Serialize to ebXML payload to DOM
		Element ebXMLMetadata = EbXML_3_0MetadataUtils.unpackSubmitObjectsRequest(setTransformer.getSubmitReq());

		// wrap the ebXML metadata in XDS b wrapper schema.

		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = transFactory.newTransformer();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		}
		StringWriter buffer = new StringWriter();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		try {
			transformer.transform(new DOMSource(ebXMLMetadata), new StreamResult(buffer));
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		String s = buffer.toString();
		System.out.println(s);
	}

}
