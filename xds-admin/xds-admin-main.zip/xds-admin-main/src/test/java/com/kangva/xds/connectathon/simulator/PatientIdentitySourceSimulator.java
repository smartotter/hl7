package com.kangva.xds.connectathon.simulator;

public class PatientIdentitySourceSimulator {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String hl7Message = "MSH|^~\\&|EMR|Acme Corporation|ImageGrid|Candelis|20100202234217||ADT^A05|4369504|P|2.5\r"
				+ "PID|1|00001|c6002e5679534eg^^^&1.3.6.1.4.1.21367.2005.3.7&ISO||Doe^John^^^|\"\"|19900515|M\r"
				+ "PV1|1|I|LRJ^2706^C|3|||43009^DOCSAMPLE^ALI^^^MD^HL70010|12346^KEVORKIAN^JACK^^^DR|\"\"|OBS\r";
		HL7Sender.sender(hl7Message);

	}
}
