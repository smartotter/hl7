package com.kangva.xds.connectathon.simulator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class XDS_b_Patient_Feed_HL7 {
	private static final String PatientSId = "c6002e5679534s1^^^&1.3.6.1.4.1.21367.2005.3.7&ISO";
	private static final String PatientNId = "c6002e5679534n1^^^&1.3.6.1.4.1.21367.2005.3.7&ISO";

	private static final String hl7MessageTemplate = "MSH|^~\\&|EMR|Acme Corporation|ImageGrid|Candelis|20100202234217||ADT^A04|4369504|P|2.3.1\r"
			+ "PID|1|00001|%s||Doe^John^^^|\"\"|19900515|M\r"
			+ "PV1|1|I|LRJ^2706^C|3|||43009^DOCSAMPLE^ALI^^^MD^HL70010|12346^KEVORKIAN^JACK^^^DR|\"\"|OBS\r";
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		String patientSMessage = hl7MessageTemplate.format(hl7MessageTemplate, PatientSId);
		HL7Sender.sender(patientSMessage);
		String patientNMessage = hl7MessageTemplate.format(hl7MessageTemplate, PatientNId);
		HL7Sender.sender(patientNMessage);
	}

}
