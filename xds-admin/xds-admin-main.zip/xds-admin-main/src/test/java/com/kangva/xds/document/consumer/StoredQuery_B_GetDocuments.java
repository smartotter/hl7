package com.kangva.xds.document.consumer;

import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetDocumentsQuery;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;

public class StoredQuery_B_GetDocuments extends B_ConsumerMesaTest {

	// logger
	private static final Logger logger = Logger
			.getLogger(StoredQuery_B_GetDocuments.class);

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() throws Exception {
		logger.debug("BEGIN MESA 11741 - stored query");

		// // make query
		GetDocumentsQuery q = new GetDocumentsQuery(new String[]{"urn:uuid:067acb2c-2672-0d20-bccb-7479a013dc79"}, true);
		
		// run query
		XDSQueryResponseType response = null;
		try {
			response = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		logger.debug("Returned " + response.getReferences().size()
				+ " references.");
	}

}
