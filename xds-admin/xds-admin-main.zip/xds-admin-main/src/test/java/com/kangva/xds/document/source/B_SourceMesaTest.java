/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package com.kangva.xds.document.source;

import java.net.URI;
import java.util.UUID;

import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openhealthtools.ihe.xds.source.B_Source;

/**
 * Base test class for Mesa XDS.b Source testing
 * 
 * @author <a href="mailto:seknoop@us.ibm.com">Sarah Knoop</a>
 * 
 */
public abstract class B_SourceMesaTest {
	// logger
	private static final Logger logger = Logger
			.getLogger(B_SourceMesaTest.class);

	protected B_Source source = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		logger.info("init the source");
		System.setProperty("javax.net.ssl.keyStore",
				TestConfiguration.KEY_STORE);
		System.setProperty("javax.net.ssl.keyStorePassword",
				TestConfiguration.KEY_STORE_PASS);
		System.setProperty("javax.net.ssl.trustStore",
				TestConfiguration.TRUST_STORE);
		System.setProperty("javax.net.ssl.trustStorePassword",
				TestConfiguration.TRUST_STORE_PASS);
		System.setProperty("javax.net.debug", "sslhandshake");
		Options options = new Options();
		//options.setTo(new EndpointReference("https://192.168.1.11:12345/GreenRepository"));
		options.setTo(new EndpointReference("https://192.168.1.18:90"));
		// serviceClient.getOptions().setProperty(HTTPConstants.CHUNKED,
		// "false");
		// serviceClient.getOptions().setTransportInProtocol(Constants.TRANSPORT_HTTP);
//		options.setProperty("enableMTOM", "true");
		options.setProperty("addMustUnderstandToAddressingHeaders",
				Boolean.TRUE);
		options.setReplyTo(new EndpointReference(
				"http://www.w3.org/2005/08/addressing/anonymous"));
		options.setAction("urn:ihe:iti:2007:RegisterDocumentSet-b");
		options.setMessageId("urn:uuid:"
				+ UUID.randomUUID().toString());
		options.setTimeOutInMilliSeconds(100000);
		options.setSoapVersionURI("http://www.w3.org/2003/05/soap-envelope");
		options.setTimeOutInMilliSeconds(10000000);
		options.setProperty("enableMTOM", "true");
//		source = new B_Source(
//				new URI(
//						"http://70.28.25.88:8032/services/xdsregistryb"));

//		source = new B_Source(
//				new URI(
//						"http://localhost:8080/DocumentRepository_Service/XDS_b_DocumentRepository"));

//		source = new B_Source(
//				new URI(
//						"http://192.168.0.149:8080/services/xdsrepositoryb"));
		source = new B_Source(
				new URI(
						"https://192.168.1.11:12347/GreenRepository"));
//						"https://192.168.1.18:90"));
//		source = new B_Source(
//				new URI(
//						"https://localhost:8443/simed-repository/services/xdsrepositoryb"));
//		source = new B_Source(
//				new URI(
//						"https://192.168.0.165:8443/simed-repository/services/xdsrepositoryb"));
		//fangzheng
//		source = new B_Source(
//				new URI(
//						"https://114.242.194.184:8021/axis2/services/xdsrepositoryb"));
//		 source = new B_Source(new
//		 URI("https://118.163.131.118:8021/axis2/services/xdsrepositoryb"));
	}

	@After
	public void tearDown() throws Exception {
	}

}
