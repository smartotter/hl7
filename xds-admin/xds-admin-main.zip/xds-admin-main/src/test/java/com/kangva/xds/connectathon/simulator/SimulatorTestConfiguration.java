/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package com.kangva.xds.connectathon.simulator;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.openhealthtools.ihe.common.hl7v2.CX;
import org.openhealthtools.ihe.common.hl7v2.Hl7v2Factory;
import org.openhealthtools.ihe.common.hl7v2.XCN;
import org.openhealthtools.ihe.xds.consumer.query.DateTimeRange;
import org.openhealthtools.ihe.xds.consumer.query.MalformedQueryException;
import org.openhealthtools.ihe.xds.metadata.CodedMetadataType;
import org.openhealthtools.ihe.xds.metadata.MetadataFactory;
import org.openhealthtools.ihe.xds.metadata.constants.DocumentEntryConstants;

/**
 * This is a consolidated configuration file for running the Mesa test code. You
 * may need to edit this class to get the examples working on your own system.
 * Minimally, you will need to set your test server endpoint (as a URL) and set
 * your patient ID.
 * 
 * @author <a href="mailto:seknoop@us.ibm.com">Sarah Knoop</a>
 * 
 */
public class SimulatorTestConfiguration {
	// basics
	public static final String LOG4J_PATH = "src/test/resources/conf/xdsconsumer_log4j.xml";

	// ATNA logging enable/disablement
	public static final boolean DO_AUDIT = true; // change to 'true' to enable
													// auditing
	public static final String INITIATING_USER = "some user";
	public static final String AUDIT_SOURCE_ID = "OTHER_OHT";

	// TLS enablement
	public static final boolean USE_TLS = true; // change to 'true' to enable
												// TLS
	public static final String KEY_STORE = "src/test/resources/security/OpenXDS_2013_Keystore.p12";
//	public static final String KEY_STORE = "src/test/resources/security/keystore.jks";
	public static final String KEY_STORE_PASS = "123456";
	public static final String TRUST_STORE = "src/test/resources/security/OpenXDS_2013_Truststore.jks";
//	public static final String TRUST_STORE = "src/test/resources/security/keystore.jks";
	public static final String TRUST_STORE_PASS = "123456";

	// /////////////////
	// XDS.b
	// /////////////////
	// NIST XDS.b Registry (stored query interface)
	// public static final String NIST_B_STORED_QUERY =
	// "https://192.168.0.165:8443/simed-registry/services/xdsregistryb";
//	public static final String XDS_B_REGISTRY_LOCAL = "http://localhost:8890/simed-registry/services/xdsregistryb";
//	public static final String XDS_B_REPOSITORY_LOCAL = "http://localhost:8889/simed-repository/services/xdsrepositoryb";
	public static final String XDS_B_REGISTRY_LOCAL = "https://192.168.1.94:9080/xdsservice/xdsregistry";
//	public static final String XDS_B_REPOSITORY_LOCAL = "https://192.168.1.94:9080/XdsService/XDSRepository";
	public static final String XDS_B_REPOSITORY_LOCAL = "https://localhost:8443/simed-repository/services/xdsrepositoryb";
//	public static final String XDS_B_REPOSITORY_LOCAL = "http://www.rsnaclearinghouse.com:9090/services/xdsrepositoryb?wsdl";
	public static final String XDS_B_REPOSITORY_UNIQUE_ID_LOCAL = "1.19.6.24.109.42.1.1"; // for

	// SIMED XDS.b
//	public static final String XDS_B_REGISTRY_SIMED = "https://192.168.0.165:8443/simed-registry/services/xdsregistryb";
//	public static final String XDS_B_REPOSITORY_SIMED = "https://192.168.0.165:8443/simed-repository/services/xdsrepositoryb";
//	public static final String XDS_B_REPOSITORY_UNIQUE_ID_SIMED = "1.19.6.24.109.42.1"; // for

	// HEHUA XDS.b
	public static final String XDS_B_REGISTRY_HEHUA = "https://118.163.131.118:8011/axis2/services/xdsregistryb";
	public static final String XDS_B_REPOSITORY_HEHUA = "https://118.163.131.118:8021/axis2/services/xdsrepositoryb";
	public static final String XDS_B_REPOSITORY_UNIQUE_ID_HEHUA = "1.3.6.1.4.1.21367.2010.1.2.1125"; // for

	// FANGZHENG XDS.b
	public static final String XDS_B_REGISTRY_FANGZHENG = "https://192.168.1.38:8011/axis2/services/xdsregistryb";
	public static final String XDS_B_REPOSITORY_FANGZHENG = "https://192.168.1.38:8010/axis2/services/xdsrepositoryb";
	public static final String XDS_B_REPOSITORY_UNIQUE_ID_FANGZHENG = "1.3.6.1.4.1.21367.2010.1.2.1125.1"; // for

	// chuangye XDS.b
	public static final String XDS_B_REGISTRY_CHANGYE = "https://192.168.1.15:8020/axis2/services/xdsregistryb";
	public static final String XDS_B_REPOSITORY_CHANGYE = "https://192.168.1.15:8010/axis2/services/xdsrepositoryb";
	public static final String XDS_B_REPOSITORY_UNIQUE_ID_CHANGYE = "1.3.6.1.4.1.21367.2010.1.2.1125.1"; // for
	
	// meidehua XDS.b
	public static final String XDS_B_REGISTRY_MEIDEHUA = "https://192.168.1.107:4433/XdsService/XDSRegistry";
	public static final String XDS_B_REPOSITORY_MEIDEHUA = "https://192.168.1.107:4433/XdsService/XDSRepository";
	public static final String XDS_B_REPOSITORY_UNIQUE_ID_MEIDEHUA = "1.3.6.1.4.1.21367.2010.1.2.1125.1"; 

	public static final String XDS_B_REGISTRY_MEIDIKANG = "https://192.168.1.107:4433/XdsService/XDSRegistry";
	public static final String XDS_B_REPOSITORY_MEIDIKANG = "http://192.168.1.107:9090/XdsService/XDSRepository";
	public static final String XDS_B_REPOSITORY_UNIQUE_ID_MEIDIKANG = "1.19.6.24.109.42.1.2"; 
	// ///////////////////////////////////////////////////////////////////////////////
	// Test Server Set up (this is the endpoint that will actually be used in
	// testing)
	// ///////////////////////////////////////////////////////////////////////////////
	public static URI XDS_B_REGISTRY_URI;
	public static URI XDS_B_REPOSITORY_URI;
	public static String XDS_B_REPOSITORY_UNIQUE_ID;

	public static Map<String, URI> repositoryMap = new HashMap<String, URI>();

	static {
		// Set the XDS.a registry URI you want to use to one of the above
		// endpoints
		// XDS.a not tested at 2010 connectathon and beyond

		/*
		 * try { // Set the registry URI you want to use to XDS_A_REGISTRY_URI =
		 * new URI(); } catch (URISyntaxException e) { XDS_A_REGISTRY_URI =
		 * null; }
		 */

		// Set the XDS.b registry URI you want to use to one of the above
		// endpoints
		try {
			// Set the registry URI you want to use to
			XDS_B_REGISTRY_URI = new URI(XDS_B_REGISTRY_LOCAL);
		} catch (URISyntaxException e) {
			XDS_B_REGISTRY_URI = null;
		}

		// Set the XDS.b repository you want to use to one of the above
		// endpoints
		try {
			// Set the registry URI you want to use to
			XDS_B_REPOSITORY_URI = new URI(XDS_B_REPOSITORY_MEIDIKANG);
		} catch (URISyntaxException e) {
			XDS_B_REPOSITORY_URI = null;
		}
		XDS_B_REPOSITORY_UNIQUE_ID = XDS_B_REPOSITORY_UNIQUE_ID_LOCAL;

		try {
			repositoryMap.put(XDS_B_REPOSITORY_UNIQUE_ID_LOCAL,
					new URI(XDS_B_REPOSITORY_LOCAL));
//			repositoryMap.put(XDS_B_REPOSITORY_UNIQUE_ID_SIMED,
//					new URI(XDS_B_REPOSITORY_SIMED));
			repositoryMap.put(XDS_B_REPOSITORY_UNIQUE_ID_HEHUA,
					new URI(XDS_B_REPOSITORY_HEHUA));
			repositoryMap.put(XDS_B_REPOSITORY_UNIQUE_ID_FANGZHENG,
					new URI(XDS_B_REPOSITORY_FANGZHENG));
			repositoryMap.put(XDS_B_REPOSITORY_UNIQUE_ID_MEIDIKANG,
					new URI(XDS_B_REPOSITORY_MEIDIKANG));
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// patient ID
	public static final CX PATIENT_ID;
	static {
		// normal testing
		/*
		 * PATIENT_ID = Hl7v2Factory.eINSTANCE.createCX();
		 * PATIENT_ID.setIdNumber("0859b9b8b1b64cd");
		 * PATIENT_ID.setAssigningAuthorityUniversalId
		 * ("1.3.6.1.4.1.21367.2005.3.7");
		 * PATIENT_ID.setAssigningAuthorityUniversalIdType("ISO");
		 */

		// 2010 Connectathon 5655294897af4b7^^^&1.19.6.24.109.42.1.3&ISO
		PATIENT_ID = Hl7v2Factory.eINSTANCE.createCX();
		PATIENT_ID.setIdNumber("c6002e5679534ea"); // ("NA5156-OHT");
		PATIENT_ID
				.setAssigningAuthorityUniversalId("1.3.6.1.4.1.21367.2005.3.7");
		PATIENT_ID.setAssigningAuthorityUniversalIdType("ISO");

		// NIST-XCA - d05ddc2efd5241f
		/*
		 * PATIENT_ID = Hl7v2Factory.eINSTANCE.createCX();
		 * PATIENT_ID.setIdNumber("d05ddc2efd5241f");
		 * PATIENT_ID.setAssigningAuthorityUniversalId
		 * ("1.3.6.1.4.1.21367.2005.3.7");
		 * PATIENT_ID.setAssigningAuthorityUniversalIdType("ISO");
		 */
	}

	// classCodes
	public static final CodedMetadataType[] CLASS_CODES;
	static {
		CLASS_CODES = null;
	}

	// creation date time range
	public static DateTimeRange[] CREATION_DATE_RANGES;
	static {
		try {
			DateTimeRange range = new DateTimeRange(
					DocumentEntryConstants.CREATION_TIME, "200412252300",
					"200501010800");
			CREATION_DATE_RANGES = new DateTimeRange[] { range };
		} catch (MalformedQueryException e) {
			CREATION_DATE_RANGES = null;
		}
	}

	// practice setting codes
	public static final CodedMetadataType[] PRACTICE_SETTING_CODES;
	static {
		PRACTICE_SETTING_CODES = null;
	}

	// healthcare facility codes
	public static final CodedMetadataType[] HEALTHCARE_FACILITY_CODES;
	static {
		CodedMetadataType hcfc1 = MetadataFactory.eINSTANCE
				.createCodedMetadataType();
		/*
		 * hcfc1.setCode("Children's Hospital"); hcfc1.setSchemeName("1.2.3.4");
		 */

		CodedMetadataType hcfc2 = MetadataFactory.eINSTANCE
				.createCodedMetadataType();
		/* hcfc2.setCode("Emergency Department"); */

		HEALTHCARE_FACILITY_CODES = null;// new CodedMetadataType[]{hcfc1,
											// hcfc2};
	}

	// eventCodes
	public static final CodedMetadataType[] EVENT_CODES;
	static {
		CodedMetadataType event1 = MetadataFactory.eINSTANCE
				.createCodedMetadataType();
		event1.setCode("MPQ-eventcode-1");
		event1.setSchemeName("MPQ Testing");

		EVENT_CODES = new CodedMetadataType[] { event1 };
		// EVENT_CODES = null;
	}

	// additional event codes to add subject to AND/OR semantics. [i] is a
	// disjunctive clause to
	// add to the query
	public static final CodedMetadataType[][] ADDITIONAL_EVENT_CODE_CLAUSES;
	static {
		ADDITIONAL_EVENT_CODE_CLAUSES = null;// new CodedMetadataType[1][1];
		/*
		 * ADDITIONAL_EVENT_CODE_CLAUSES[0][0] =
		 * MetadataFactory.eINSTANCE.createCodedMetadataType();
		 * ADDITIONAL_EVENT_CODE_CLAUSES[0][0].setCode("12345-6");
		 */
	}

	// authorPerson
	public static final XCN AUTHOR_PERSON;
	static {
		AUTHOR_PERSON = null;
	}

	// confidentiality codes (also used for GetFolderAndContents query)
	public static final CodedMetadataType[] CONFIDENTIALITY_CODES;
	static {
		CONFIDENTIALITY_CODES = null;// new CodedMetadataType[1];
		/*
		 * CONFIDENTIALITY_CODES[0] =
		 * MetadataFactory.eINSTANCE.createCodedMetadataType();
		 * CONFIDENTIALITY_CODES[0].setCode("N");
		 */
	}

	// additional conf codes to add subject to AND/OR semantics. [i] is a
	// disjunctive clause to
	// add to the query (also used for GetFolderAndContents query)
	public static final CodedMetadataType[][] ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES;
	static {
		ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES = null;// new
														// CodedMetadataType[1][1];
		/*
		 * ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES[0][0] =
		 * MetadataFactory.eINSTANCE.createCodedMetadataType();
		 * ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES[0][0].setCode("R");
		 */
	}

	// format codes (also used for GetFolderAndContents query)
	public static final CodedMetadataType[] FORMAT_CODES;
	static {
		FORMAT_CODES = null;
	}

	// ///////////////////////////////////////
	// Get Folder And Contents Query Parameters: (update this as needed)
	// ///////////////////////////////////////
	// folder entry uuid
	public static final String FOLDER_UUID = "urn:uuid:aebd9d1b-65e3-405a-94e6-922c95298452"; // "urn:uuid:4c7aa6ba-4c72-7346-9639-000f1fd35f02";
	// folder unique id
	public static final String FOLDER_UNIQUE_ID = "1.2.3.4.5.988";// "1.3.6.1.4.1.21367.2009.1.2.166.104019007056046009.12354";

}
