package com.kangva.xds.admin.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.http.HttpStatus;
import org.junit.Test;

public class QueryTest {

	@Test
	public void test() throws UnsupportedEncodingException {
		String ridIHERetrieveListInfoAddress = "http://localhost:8080/xds-admin/rid/IHERetrieveListInfo", requestType = "LIST-MEDS", patientID = "", assigningAuthority = "";

		String requestURL = ridIHERetrieveListInfoAddress
				+ "?requestType="
				+ URLEncoder.encode(requestType,"utf-8")
				+ "&patientID="
				+ URLEncoder.encode(patientID + "^^^"
						+ assigningAuthority,"utf-8");

		System.out.println("request url:"+requestURL);
		HttpClient httpClient = null;
		try {
			// 创建HttpClient对象
			httpClient = new HttpClient();
			// HttpClient
			GetMethod getMethod = new GetMethod(requestURL);
			httpClient.executeMethod(getMethod);
			// 发送请求获得返回结果
			// 如果成功
			if (getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				
			} else if (getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_NOT_FOUND) {
			}
		} catch (IOException e) {
			e.printStackTrace();
			Map<String, String> result = new HashMap<>();
			result.put("request", requestURL);
		}
	}
}
