package com.kangva.xds.admin.service;

public class StoredQueryServiceTest {

}
