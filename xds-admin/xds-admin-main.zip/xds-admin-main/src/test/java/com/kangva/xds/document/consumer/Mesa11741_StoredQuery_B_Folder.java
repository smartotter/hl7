package com.kangva.xds.document.consumer;

import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openhealthtools.ihe.xds.consumer.storedquery.FindFoldersStoredQuery;
import org.openhealthtools.ihe.xds.metadata.AvailabilityStatusType;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;

public class Mesa11741_StoredQuery_B_Folder extends B_ConsumerMesaTest{

	// logger
	private static final Logger logger = Logger
			.getLogger(Mesa11741_StoredQuery_B_Folder.class);
		
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}


	@Test
	public void test() throws Exception {
		logger.debug("BEGIN MESA 11741 - stored query");
		// make query
		FindFoldersStoredQuery q = new FindFoldersStoredQuery(
				TestConfiguration.PATIENT_ID,
				new AvailabilityStatusType[] { AvailabilityStatusType.APPROVED_LITERAL });

//		q.getQueryParameters().put("$XDSFolderLastUpdateTimeTo", "2018");
//		q.getQueryParameters().put("$XDSFolderLastUpdateTimeFrom", "2010");
		// run query
		XDSQueryResponseType response = null;
		try {
			response = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		logger.debug("Returned " + response.getReferences().size()
				+ " references.");
	}

}
