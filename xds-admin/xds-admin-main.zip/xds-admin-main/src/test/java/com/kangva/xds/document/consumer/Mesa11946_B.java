/*******************************************************************************
 * Copyright (c) 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package com.kangva.xds.document.consumer;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetFolderAndContentsQuery;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;

/**
 * Prior to running this test you will need to set the appropriate parameters in 
 * TestConfiguration.java
 * <br>
 * Get Folder And Contents Query by folder entryUUID or by folder uniqueID with XDS.b Consumer object.
 * Corresponds to Connectathon 2008-2009 Test: 11946
 * <br>
 * http://ihewiki.wustl.edu/wiki/index.php/XDS_Test_Kit_2007-2008_Test_Descriptions#11946
 * @author <a href="mailto:seknoop@us.ibm.com">Sarah Knoop</a>
 */
public class Mesa11946_B extends B_ConsumerMesaTest {

	// logger
	private static final Logger logger = Logger.getLogger(Mesa11946_B.class);
	
	/**
	 * Get Documents Stored Query by document entryUUID
	 * Corresponds to Connectathon 2006-2007 Test: 11946
	 * <br>
	 * http://ihewiki.wustl.edu/wiki/index.php/XDS_Test_Kit_2007-2008_Test_Descriptions#Stored_Query_-_Testing_the_Document_Consumer
	 *
	 * @throws Throwable
	 */
	public void test1() throws Throwable {
		logger.debug("BEGIN MESA 11940 with UUID");
		
		// make query
		GetFolderAndContentsQuery q = new GetFolderAndContentsQuery(TestConfiguration.FOLDER_UUID, 
				true, TestConfiguration.FORMAT_CODES, TestConfiguration.CONFIDENTIALITY_CODES);
		
		// add any additional conf code clauses
		if(TestConfiguration.ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES != null){
			for(int i = 0; i < TestConfiguration.ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES.length; i++){
				q.addConfidentialityCodes(TestConfiguration.ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES[i]);
			}
		}
		
		
		// run query
		XDSQueryResponseType response = null;
		try {
			response = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		logger.debug("Returned " + response.getFolderResponses().size() + " folders.");
		logger.debug("Returned " + response.getAssociations().size() + " associations.");
		logger.debug("Returned " + response.getDocumentEntryResponses().size() + " documents.");
		logger.debug("DONE MESA 11946 with UUID");
	}
	/**
	 * Get Documents Stored Query by document unique id
	 * Corresponds to Connectathon 2006-2007 Test: 11946
	 * <br>
	 * http://ihewiki.wustl.edu/wiki/index.php/XDS_Test_Kit_2007-2008_Test_Descriptions#Stored_Query_-_Testing_the_Document_Consumer
	 *
	 * @throws Throwable
	 */
	@Test
	public void test2() throws Throwable{
		logger.debug("BEGIN MESA 11946 with uniqueID");
		
		// make query
		GetFolderAndContentsQuery q = new GetFolderAndContentsQuery(TestConfiguration.FOLDER_UNIQUE_ID, 
				false, TestConfiguration.FORMAT_CODES, TestConfiguration.CONFIDENTIALITY_CODES);
		
		// add any additional conf code clauses
		if(TestConfiguration.ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES != null){
			for(int i = 0; i < TestConfiguration.ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES.length; i++){
				q.addConfidentialityCodes(TestConfiguration.ADDITIONAL_CONFIDENTIALITY_CODE_CLAUSES[i]);
			}
		}
		
		// run query
		XDSQueryResponseType response = null;
		try {
			response = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		logger.debug("Returned " + response.getFolderResponses().size() + " folders.");
		logger.debug("Returned " + response.getAssociations().size() + " associations.");
		logger.debug("Returned " + response.getDocumentEntryResponses().size() + " documents.");
		logger.debug("DONE MESA 11946 with uniqueId");
	}
}
