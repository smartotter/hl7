package com.kangva.xds.connectathon.simulator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

public class HL7Sender {
	private static final String DEFAULT_CHARSET = "UTF-8";
	private static final char START_MESSAGE = '\u000b';// character indicating
	private static final char END_MESSAGE = '\u001c'; // character indicating
	private static final char LAST_CHARACTER = '\r'; // the final character

	/**
	 * @param args
	 */
	public static void sender(String hl7Message) {
		// TODO Auto-generated method stub
		String keyStoreFileName = "src/test/resources/security/OpenXDS_2013_Keystore.p12";
		String trustStoreFileName = "src/test/resources/security/OpenXDS_2013_Truststore.jks";
//		String hl7Message = "MSH|^~\\&|HNAM|CAPIOUK|JDE|JDE|20030821153359||ADT^A04|Q590076T590056X77||2.3"+LAST_CHARACTER
//				+ "EVN|A04|20030822172800|||1"+LAST_CHARACTER
//				+ "PID|||2ca5e00d0ee2403ac6c1a8d5cffcd5361d2bdc1d9bba4e9a996cc4da8433b90f^^^&1.3.6.1.4.1.19376.2.840.1.1.1.1&ISO||ZZTEST^selfpayGT^^^^^766"+LAST_CHARACTER;
		SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance("TLS");
			KeyManagerFactory keyManagerFactory = KeyManagerFactory
					.getInstance("SunX509");
			TrustManagerFactory trustManagerFactory = TrustManagerFactory
					.getInstance("SunX509");

			KeyStore keyStore = KeyStore.getInstance("JKS");
			KeyStore trustKeyStore = KeyStore.getInstance("JKS");
			keyStore.load(new FileInputStream(keyStoreFileName),
					"123456".toCharArray());
			trustKeyStore.load(new FileInputStream(trustStoreFileName),
					"123456".toCharArray());

			keyManagerFactory.init(keyStore, "123456".toCharArray());
			trustManagerFactory.init(trustKeyStore);

			sslContext.init(keyManagerFactory.getKeyManagers(),
					trustManagerFactory.getTrustManagers(), null);

			// 根据上面配置的SSL上下文来产生SSLServerSocketFactory,与通常的产生方法不同
			SSLSocketFactory factory = sslContext.getSocketFactory();

			/**
			SSLSocket sslSocket = (SSLSocket) factory.createSocket(
//									"64.28.75.46", 8890);// sslSocket.
//						"118.163.131.118", 3612);// sslSocket.s
							"localhost", 1237);// sslSocket.
//					"172.30.33.243", 8888);// sslSocket.
//					"clearinghouse.lifeimage.com", 8888);// sslSocket.**/
			Socket sslSocket =  new Socket("localhost", 1237);
			InputStream input = sslSocket.getInputStream();
			OutputStream output = sslSocket.getOutputStream();
			BufferedWriter myWriter = new BufferedWriter(
					new OutputStreamWriter(output, DEFAULT_CHARSET));
			myWriter.write(START_MESSAGE);
			myWriter.write(hl7Message);
			myWriter.write(END_MESSAGE);
			myWriter.write(LAST_CHARACTER);
			myWriter.flush();
			BufferedReader myReader=new BufferedReader(
					new InputStreamReader(input, DEFAULT_CHARSET));
			
			System.out.println(getMessage(myReader));

			sslSocket.close();

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnrecoverableKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public static String getMessage(BufferedReader myReader) throws IOException {

		StringBuffer s_buffer = new StringBuffer();

		boolean end_of_message = false;

		int c = 0;
		c = myReader.read();
		// log.info("SocketException on read() attempt. Socket appears to
		// have been closed: "
		// + e.getMessage());
		// System.out.println("SocketException occurs");

		// trying to read when there is no data (stream may have been closed at
		// other end)
		if (c == -1) {
			return null;
		}

		if (c != START_MESSAGE) {
			throw new IOException(
					"Message received is not a HL7 message: no HL7 MLLP header");
		}

		while (!end_of_message) {
			c = myReader.read();

			if (c == -1) {
				throw new IOException(
						"Message received is not a HL7 message: no HL7 MLLP tail");
			}

			if (c == END_MESSAGE) {
				// subsequent character should be a carriage return
				c = myReader.read();
				if (c != LAST_CHARACTER) {
					throw new IOException("Message "
							+ "violates the minimal lower layer protocol: "
							+ "message terminator not followed by a return "
							+ "character ('\r')");
				}
				end_of_message = true;
			} else {
				s_buffer.append((char) c);
			}
		}

		return s_buffer.toString();
	}
}
