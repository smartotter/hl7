package com.kangva.xds.connectathon.simulator;

import java.net.URISyntaxException;

import org.apache.axis2.client.Options;
import org.apache.log4j.Logger;
import org.openhealthtools.ihe.common.hl7v2.CX;
import org.openhealthtools.ihe.common.hl7v2.Hl7v2Factory;
import org.openhealthtools.ihe.xds.source.B_Source;

import com.kangva.xds.document.source.TestConfiguration;


public class DocumentSourceSimulator {

	private static final Logger logger = Logger
			.getLogger(DocumentSourceSimulator.class);

	protected B_Source source = null;
	protected CX patientId = null;

	public DocumentSourceSimulator() {
		super();
	}

	protected void initialDocumentSource() throws URISyntaxException {
		logger.info("init the source");
		System.setProperty("javax.net.ssl.keyStore",
				TestConfiguration.KEY_STORE);
		System.setProperty("javax.net.ssl.keyStorePassword",
				TestConfiguration.KEY_STORE_PASS);
		System.setProperty("javax.net.ssl.trustStore",
				TestConfiguration.TRUST_STORE);
		System.setProperty("javax.net.ssl.trustStorePassword",
				TestConfiguration.TRUST_STORE_PASS);
		System.setProperty("javax.net.debug", "sslhandshake");
		Options options = new Options();
		options.setTimeOutInMilliSeconds(10000000);
		 
		source = new B_Source(SimulatorTestConfiguration.XDS_B_REPOSITORY_URI);
		
	}

	protected void setPatientId() {
		patientId = Hl7v2Factory.eINSTANCE.createCX();
		patientId.setIdNumber("5655294897af4b7"); // ("NA5156-OHT");
		patientId.setAssigningAuthorityUniversalId("1.19.6.24.109.42.1.3");
		patientId.setAssigningAuthorityUniversalIdType("ISO");
	}
}