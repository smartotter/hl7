package com.kangva.xds.document.consumer;

import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetRelatedDocumentsQuery;
import org.openhealthtools.ihe.xds.metadata.ParentDocumentRelationshipType;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;

public class StoredQuery_B_GetRelatedDocuments extends B_ConsumerMesaTest {

	// logger
	private static final Logger logger = Logger
			.getLogger(StoredQuery_B_GetRelatedDocuments.class);

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() throws Exception {
		logger.debug("BEGIN MESA 11741 - stored query");

		// // make query
		GetRelatedDocumentsQuery q = new GetRelatedDocumentsQuery("urn:uuid:06021d3a-25fa-0d20-79d7-fea9069c7bb0", true,
				new ParentDocumentRelationshipType[] {
						ParentDocumentRelationshipType.APND_LITERAL,
						ParentDocumentRelationshipType.RPLC_LITERAL,
						ParentDocumentRelationshipType.XFRM_LITERAL,
						ParentDocumentRelationshipType.XFRMRPLC_LITERAL });
		// run query
		XDSQueryResponseType response = null;
		try {
			response = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		logger.debug("Returned " + response.getReferences().size()
				+ " references.");
	}

}
