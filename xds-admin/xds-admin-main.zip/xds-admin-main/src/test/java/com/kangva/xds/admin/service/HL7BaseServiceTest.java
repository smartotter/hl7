package com.kangva.xds.admin.service;

import org.junit.Test;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.GenericMessage;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.Structure;
import ca.uhn.hl7v2.model.v25.segment.PID;
import ca.uhn.hl7v2.model.v25.segment.QPD;
import ca.uhn.hl7v2.parser.Parser;
import ca.uhn.hl7v2.parser.PipeParser;

public class HL7BaseServiceTest {

	@Test
	public void testExtractK21() throws HL7Exception{
		String msg = "MSH|^~\\&|kangva|kangvapixpdq|PDQConsumer|PDQConsumer|20160514223850||RSP^K22^RSP_K21|1463236730056|P|2.5\r"+
"MSA|AA|1463236730036\r"+
"QAK|QRY1463236730036|OK\r"+
"QPD|Q22|QRY1463236730036|@PID.3.1^1.23.5.117085109001270144.1463071119632.2\r"+
"PID|1||1.23.5.117085109001270144.1463071119632.2^^^NIST2010&2.16.840.1.113883.3.72.5.9.1&ISO||qqq^qqq|qqq|20160504|F\r";
	
		Parser parser = new PipeParser();
		Message message = parser.parse(msg);
		Structure[] qpdSegments = message.getAll("PID");
		System.out.println("Get the all messages");
		if(qpdSegments != null){
			for(Structure structure: qpdSegments){
				if(structure instanceof QPD){
					QPD response = (QPD)structure;
				}
			}
		}
	}
	

	@Test
	public void testExtractK22() throws HL7Exception{
		String msg = "MSH|^&~\\|HOSPMPI|HOSP|CLINREG|WESTCLIN|199912121135-0600||RSP^K22^RSP_K22|1|D|2.5\r"+
"MSA|AA|1463236730036\r"+
"QAK|QRY1463236730036|OK\r"+
"QPD|Q22|QRY1463236730036|@PID.3.1^1.23.5.117085109001270144.1463071119632.2\r"+
"PID|1||1.23.5.117085109001270144.1463071119632.2^^^NIST2010&2.16.840.1.113883.3.72.5.9.1&ISO||qqq^qqq|qqq|20160504|F\r";
	
		Parser parser = new PipeParser();
		Message message = parser.parse(msg);
		if(message instanceof GenericMessage.V25){
			System.out.println("asdds");
		}
		Structure[] qpdSegments = message.getAll("PID");
		System.out.println("Get the all messages");
		if(qpdSegments != null){
			for(Structure structure: qpdSegments){
				if(structure instanceof GenericMessage.V25){
					
				}
			}
		}
	}
	
	@Test
	public void testExtractK22xinlan() throws HL7Exception{
		String msg = "MSH|^~\\&|LWClient|LWClient|LWClient|LWClient|201605191723||RSP^K22^RSP_K22|36561045235833858|P|2.5\r"+
"MSA|AA|1463649807235\r"+
"QAK|QRY1463649807236|OK|Q22^Find Candidates^HL7|1\r"+
"QPD|Q22^Find Candidates^HL7|QRY1463649807236|@PID.3.1^1.23.5.121059065005225208.1463469313145.22\r"+
"PID|1||1.23.5.121059065005225208.1463469313145.22^^^LWClient12&2.16.840.1.113883.3.72.5.9.4&ISO^PI~ER-22^^^NIST2010&2.16.840.1.113883.3.72.5.9.1&ISO^PI||Salazar^Lillian^^^^^L|Blue^Barbara^Blue^^^^^L|19920301|F|||1475 Glenwood Drive^^San Diego^CA^33445||123-456-7890||||||216345455|||||Y|2||||||||20010519|15\r";
	
		Parser parser = new PipeParser();
		Message message = parser.parse(msg);
		if(message instanceof GenericMessage.V25){
			System.out.println("asdds");
		}
		Structure[] qpdSegments = message.getAll("PID");
		System.out.println("Get the all messages");
		if(qpdSegments != null){
			for(Structure structure: qpdSegments){
				if(structure instanceof PID){
					PID pid = (PID)structure;
					System.out.println("pid");
				}
			}
		}
	}
	

	@Test
	public void testExtractZV2() throws HL7Exception{
		String msg = "MSH|^~\\&|||||||RSP^ZV2^RSP_ZV2|20120131102736HL7Event_ZV1|P|2.5\r"+
"MSA|AA|20120131102731HL7Event_ZV1||||\r"+
"QPD|CREALIFE_PDQ|QRY123456|@PV1.2^I||||\r"+
"QAK|QRY123456|OK|CREALIFE_PDQ|2||\r"+
"PID|1||1.23.5.117085109001270144.1463071119632.2^^^NIST2010&2.16.840.1.113883.3.72.5.9.1&ISO||qqq^qqq|qqq|20160504|F\r"+
"PV1||I|||||||||||||||||||||||||||||||||||||||||||||||\r";
	
		Parser parser = new PipeParser();
		Message message = parser.parse(msg);
		Structure[] qpdSegments = message.getAll("PID");
		System.out.println("Get the all messages");
		if(qpdSegments != null){
			for(Structure structure: qpdSegments){
				if(structure instanceof QPD){
					QPD response = (QPD)structure;
				}
			}
		}
	}
}
