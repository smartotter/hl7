package com.kangva.xds.connectathon.simulator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.axis2.client.Options;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.openhealthtools.ihe.xds.consumer.response.XDSRetrieveDocumentSetResponseType;
import org.openhealthtools.ihe.xds.consumer.retrieve.DocumentRequestType;
import org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveDocumentSetRequestType;
import org.openhealthtools.ihe.xds.consumer.storedquery.FindDocumentsQuery;
import org.openhealthtools.ihe.xds.document.XDSDocument;
import org.openhealthtools.ihe.xds.metadata.AvailabilityStatusType;
import org.openhealthtools.ihe.xds.metadata.CodedMetadataType;
import org.openhealthtools.ihe.xds.metadata.DocumentEntryType;
import org.openhealthtools.ihe.xds.metadata.MetadataFactory;
import org.openhealthtools.ihe.xds.metadata.impl.MetadataFactoryImpl;
import org.openhealthtools.ihe.xds.response.DocumentEntryResponseType;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;
import org.openhealthtools.ihe.xds.response.XDSResponseType;

import com.kangva.xds.document.consumer.TestConfiguration;

public class XDS_b_Consumer_Query_Retrieve extends DocumentConsumerSimulator {
	// logger
	static final Logger logger = Logger
			.getLogger(XDS_b_Consumer_Query_Retrieve.class);

	private List<DocumentEntryResponseType> documentEntryResponseTypes = new ArrayList<DocumentEntryResponseType>();

	@Test
	public void testQueryAndRetrieve() {
		XDS_b_Consumer_Query_Retrieve simulator = new XDS_b_Consumer_Query_Retrieve();
		try {
			logger.info("1. first step:");
			simulator.initialDocumentConsumer();
			simulator.setPatientId();
			logger.info("2. second step:");
			simulator.storedQuery();
			logger.info("3. third step:");
			simulator.retrieveDocument();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void retrieveDocument() throws Exception {
		logger.info("Document Consumer retrieves document from Document Repository.");

		Options options = new Options();
		options.setTimeOutInMilliSeconds(10000000);
		options.setProperty("enableMTOM", "true");
		RetrieveDocumentSetRequestType retrieveRequest = org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveFactory.eINSTANCE
				.createRetrieveDocumentSetRequestType();
		for (DocumentEntryResponseType documentEntryResponseType : documentEntryResponseTypes) {
			DocumentEntryType docEntry = documentEntryResponseType
					.getDocumentEntry();
			// build the document request
			DocumentRequestType documentRequest = org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveFactory.eINSTANCE
					.createDocumentRequestType();
			documentRequest.setRepositoryUniqueId(docEntry
					.getRepositoryUniqueId());
			documentRequest.setHomeCommunityId(documentEntryResponseType
					.getHomeCommunityId());
			documentRequest.setDocumentUniqueId(docEntry.getUniqueId());
			patientId = docEntry.getPatientId();

			retrieveRequest.getDocumentRequest().add(documentRequest);
		}
		// execute retrieve
		XDSResponseType response = null;
		try {
			response = c.retrieveDocumentSet(retrieveRequest, patientId);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		if (response instanceof XDSRetrieveDocumentSetResponseType) {
			XDSRetrieveDocumentSetResponseType retrieveDocumentSetResponseType = (XDSRetrieveDocumentSetResponseType) response;
			if (retrieveDocumentSetResponseType.getAttachments() != null) {
				logger.debug("Returned "
						+ retrieveDocumentSetResponseType.getAttachments()
								.size() + " documents.");
				for (XDSDocument document : retrieveDocumentSetResponseType
						.getAttachments()) {
					logger.error("Document Content:"
							+ inputStream2String(document.getStream()));
					logger.debug("First document returned: "
							+ document.toString());
				}
			}
		}

		logger.debug("DONE MESA 12076");
	}

	public String inputStream2String(InputStream is)
			throws UnsupportedEncodingException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is,
				"utf-8"));
		StringBuffer sb = new StringBuffer();
		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	private void storedQuery() throws Exception {
		logger.info("Document Consumer sends stored query to Document Registry to get document list for one patient. ");
		MetadataFactory metadataFactory = new MetadataFactoryImpl();
		CodedMetadataType formatCode = metadataFactory
				.createCodedMetadataType();
		formatCode.setCode("Summarization of episode");
		formatCode.setSchemeName("Connect-a-thon classCodes");

		CodedMetadataType practiceSettingCodes = metadataFactory
				.createCodedMetadataType();
		practiceSettingCodes.setCode("Summarization of episode");
		practiceSettingCodes.setSchemeName("Connect-a-thon classCodes");

		CodedMetadataType confidentialityCode1 = metadataFactory
				.createCodedMetadataType();
		confidentialityCode1.setCode("Summarization of episode");
		confidentialityCode1.setSchemeName("Connect-a-thon classCodes");
		CodedMetadataType confidentialityCode2 = metadataFactory
				.createCodedMetadataType();
		confidentialityCode2.setCode("Summarization of episode");
		confidentialityCode2.setSchemeName("Connect-a-thon classCodes");
		
		CodedMetadataType classCodes = metadataFactory
				.createCodedMetadataType();
		classCodes.setCode("Summarization of episode");
		classCodes.setSchemeName("Connect-a-thon classCodes");
		
		CodedMetadataType healthCareFacilityCodes = metadataFactory
				.createCodedMetadataType();
		healthCareFacilityCodes.setCode("Summarization of episode");
		healthCareFacilityCodes.setSchemeName("Connect-a-thon classCodes");
		
		CodedMetadataType eventCode1 = metadataFactory
				.createCodedMetadataType();
		eventCode1.setCode("Summarization of episode");
		eventCode1.setSchemeName("Connect-a-thon classCodes");
		CodedMetadataType eventCode2 = metadataFactory
				.createCodedMetadataType();
		eventCode2.setCode("Summarization of episode");
		eventCode2.setSchemeName("Connect-a-thon classCodes");
//		FindDocumentsQuery q = new FindDocumentsQuery(
//				TestConfiguration.PATIENT_ID,
//				new CodedMetadataType[]{practiceSettingCodes},
//				new DateTimeRange[] { new DateTimeRange(
//						DocumentEntryConstants.SERVICE_START_TIME, "1900", "2014") },
//				new CodedMetadataType[]{classCodes},
//				new CodedMetadataType[]{healthCareFacilityCodes},
//				new CodedMetadataType[] { eventCode1,eventCode2 },
//				new CodedMetadataType[] { confidentialityCode1,confidentialityCode2 },
//				new CodedMetadataType[] { formatCode },
//				null,
//				new AvailabilityStatusType[] { AvailabilityStatusType.APPROVED_LITERAL });
		FindDocumentsQuery q = new FindDocumentsQuery(
				TestConfiguration.PATIENT_ID,
				null,
				null,
				null,
				null,
				null,
				null,
				null,
				null,
				new AvailabilityStatusType[] { AvailabilityStatusType.APPROVED_LITERAL });

		// run query
		XDSQueryResponseType response = null;
		try {
			response = c.invokeStoredQuery(q, false);
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		logger.debug("Returned " + response.getReferences().size()
				+ " references.");
		for (DocumentEntryResponseType documentEntryResponseType : response
				.getDocumentEntryResponses()) {
			documentEntryResponseTypes.add(documentEntryResponseType);
		}
	}

}
