package com.kangva.xds.connectathon.simulator;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ XDS_b_Consumer_Query_Retrieve.class,
		XDS_b_Document_Source_Stores_Document.class,
		XDS_b_Folder_Management.class })
public class ConnectathonAllActorsTest {

}
