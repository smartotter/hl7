package com.kangva.xds.admin.convert;

import org.openhealthtools.ihe.common.hl7v2.format.HL7V2MessageFormat;
import org.openhealthtools.ihe.common.hl7v2.format.MessageDelimiters;
import org.openhealthtools.ihe.xds.metadata.SubmissionSetType;

import com.kangva.xds.admin.dto.SubmissionSetMetadataDto;

public class SubmissionSetTypeConvertor {

	public static SubmissionSetMetadataDto convert(
			SubmissionSetType submissionSet, String homeCommunityId) {
		if(submissionSet == null){
			return null;
		}
		SubmissionSetMetadataDto result = new SubmissionSetMetadataDto();
		if(submissionSet.getContentTypeCode() != null){
			result.setContentTypeCode(submissionSet.getContentTypeCode().getCode());
			result.setContentTypeCodeScheme(submissionSet.getContentTypeCode().getSchemeName());
		}
		result.setHomeCommunityId(homeCommunityId);
		result.setId(submissionSet.getEntryUUID());
		result.setPatientId(HL7V2MessageFormat.toMessageString(submissionSet.getPatientId(), MessageDelimiters.COMPONENT,MessageDelimiters.SUBCOMPONENT));
		result.setSourceId(submissionSet.getSourceId());
		result.setStatus(submissionSet.getAvailabilityStatus().getName());
		result.setSubmissionTime(submissionSet.getSubmissionTime());
		result.setUniqueId(submissionSet.getUniqueId());
		return result;
	}
}
