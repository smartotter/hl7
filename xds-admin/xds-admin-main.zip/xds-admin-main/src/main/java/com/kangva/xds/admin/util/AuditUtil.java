package com.kangva.xds.admin.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openhealthexchange.openpixpdq.data.PatientIdentifier;
import org.openhealthexchange.openpixpdq.data.PersonName;

import com.kangva.xds.patient.model.Domain;
import com.kangva.xds.patient.model.Patient;
import com.misyshealthcare.connect.base.SharedEnums.SexType;
import com.misyshealthcare.connect.base.demographicdata.Address;
import com.misyshealthcare.connect.net.Identifier;

public class AuditUtil {
	public static org.openhealthexchange.openpixpdq.data.Patient convertPatient(Domain domain, Patient p){
		org.openhealthexchange.openpixpdq.data.Patient r=new org.openhealthexchange.openpixpdq.data.Patient();
		List<Address> addList=new ArrayList<Address>();
		Address add=new Address();
		add.setAddCity(p.getCity());
		add.setAddState(p.getProvince());
		add.setAddLine1(p.getAddress());
		add.setAddZip(p.getZipCode());
		addList.add(add);
		r.setAddresses(addList);
		if("F".equals(p.getSex()))
			r.setAdministrativeSex(SexType.FEMALE);
		else if("M".equals(p.getSex()))
			r.setAdministrativeSex(SexType.MALE);
		else
			r.setAdministrativeSex(SexType.UNKNOWN);
		if(p.getBirthday()!=null){
			try {
				Calendar birthday=Calendar.getInstance();
				birthday.setTime(DateUtil.parse(p.getBirthday(), DateUtil.DATE_SHORT_FORMAT));
				r.setBirthDateTime(birthday);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		PatientIdentifier pi=new PatientIdentifier();
		pi.setId(p.getSsn());
		r.setPatientAccountNumber(pi);
		List<PatientIdentifier> plist=new ArrayList<PatientIdentifier>();
		pi=new PatientIdentifier();
		pi.setId(p.getLocalId());
		Identifier identifier=new Identifier(domain.getNamespaceId(),domain.getUniversalId(),domain.getUniversalidType());
		pi.setAssigningAuthority(identifier);
		plist.add(pi);
		r.setPatientIds(plist);
		PersonName pn=new PersonName();
		pn.setFirstName(p.getFamilyName());
		pn.setLastName(p.getGivenName());
		r.setPatientName(pn);
//		r.setPhoneNumbers(phoneNumbers);TODO
		r.setSsn(p.getSsn());
		return r;
	}
}
