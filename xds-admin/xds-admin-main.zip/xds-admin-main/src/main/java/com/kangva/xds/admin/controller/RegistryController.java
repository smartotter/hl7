package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.openhealthtools.ihe.xds.consumer.storedquery.StoredQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.admin.dto.DocumentEntryDto;
import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.dto.StoredQueryResponseDto;
import com.kangva.xds.admin.extract.StoredQueryRequestExtractor;
import com.kangva.xds.admin.service.DocumentEntryIndexService;
import com.kangva.xds.admin.service.StoredQueryService;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;

@Controller
@RequestMapping(PathConstants.PATH_REGISTRY)
public class RegistryController {
	private static Logger logger = LoggerFactory.getLogger(RegistryController.class);

	@Autowired
	private StoredQueryService storedQueryService;
	
	@Autowired
	private DocumentEntryIndexService documentEntryIndexService;
	
	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */

	@RequestMapping(method = RequestMethod.GET)
	public String loginGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_REGISTRY;
	}
	
	@RequestMapping(value = PathConstants.PATH_REGISTRY_DOCUMENT, method = RequestMethod.GET)
	public @ResponseBody DataTable<DocumentEntryDto> queryDocumentList(HttpServletRequest request){
		DataTableParameter dataTableParameter = DataTableParameter.extract(request);
		
		Map<String, String> parameters = new HashMap<>();
		parameters.put("patientGlobalId", StringUtils.trimToNull(request.getParameter("patientGlobalId")));
		parameters.put("patientLocalId", StringUtils.trimToNull(request.getParameter("patientLocalId")));
		parameters.put("patientName", StringUtils.trimToNull(request.getParameter("patientName")));
		
		DataTable<DocumentEntryDto> result = documentEntryIndexService.searchDocuments(parameters,dataTableParameter);
		result.setDraw(dataTableParameter.getDraw());
		return result;
	}

	@RequestMapping(value = PathConstants.PATH_REGISTRY_QUERY, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper queryPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the query page request!");

		String registryAddressIdStr = request.getParameter("registryAddressId");
		
		if(StringUtils.isEmpty(registryAddressIdStr)){
			return null;
		}
		
		int registryAddressId = Integer.valueOf(registryAddressIdStr);
		
		StoredQuery storedQuery = null;
		try {
			storedQuery = StoredQueryRequestExtractor.extract(request);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return RestResponseWrapper.error(e1.getMessage());
		}
		
		StoredQueryResponseDto queryResponse = null;
		try {
			queryResponse = storedQueryService.query(false,registryAddressId, storedQuery);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return RestResponseWrapper.error(e1.getMessage());
		}
		
		return RestResponseWrapper.ok(queryResponse);
	}
}
