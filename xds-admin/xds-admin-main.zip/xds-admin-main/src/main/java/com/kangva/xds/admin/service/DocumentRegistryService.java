package com.kangva.xds.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.repository.mapper.DocumentRegistryMapper;
import com.kangva.xds.repository.model.DocumentRegistry;

@Service
public class DocumentRegistryService {
	@Autowired
	private DocumentRegistryMapper documentRegistryMapper;
	
	public List<DocumentRegistry> getAll(){
		return documentRegistryMapper.getAll();
	}

	public DataTable<DocumentRegistry> search(Map<String, String> parameters, DataTableParameter dataTableParameter) {
		PageBounds pageBounds = dataTableParameter.toPageBounds();
		PageList<DocumentRegistry> pageList = documentRegistryMapper.search(parameters,pageBounds);
		DataTable<DocumentRegistry> result = new DataTable<>();
		result.setData(pageList);
		int totalRecords = pageList.getPaginator().getTotalCount();
		result.setRecordsTotal(totalRecords);
		result.setRecordsFiltered(totalRecords);
		return result;
	}

	public DocumentRegistry get(int registryEndpointId) {
		return documentRegistryMapper.get(registryEndpointId);
	}

	public boolean saveOrEdit(DocumentRegistry documentRegistry) {
		if(documentRegistry.getId() == null){
			documentRegistryMapper.insert(documentRegistry);
			if(documentRegistry.getId() != null){
				return true;
			}
		}else{
			int result = documentRegistryMapper.edit(documentRegistry);
			if(result > 0){
				return true;
			}
		}
		return false;
	}

	public int delete(int id) {
		return documentRegistryMapper.delete(id);
	}
}
