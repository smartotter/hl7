package com.kangva.xds.admin.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;

@Controller
@RequestMapping(PathConstants.PATH_FILE)
public class FileDownloadController {
	private static Logger logger = LoggerFactory.getLogger(FileDownloadController.class);

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(value = "/{fileName}", method = RequestMethod.GET)
	public void doGet(HttpServletRequest request, HttpServletResponse response, @PathVariable String fileName) throws IOException {
		logger.info("Get the error page request!");
		File rootDir = new File(System.getProperty("java.io.tmpdir"));

		File absolutePath = new File(rootDir, fileName);
		FileUtils.copyFile(absolutePath, response.getOutputStream());
	
	}

	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVELISTINFO , method = RequestMethod.GET)
	public String doGetIHERetrieveListInfo(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_DISPLAY;
	}

	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVEDOCUMENT , method = RequestMethod.GET)
	public void doGetIHERetrieveDocument(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
//		response.setContentType("image/jpeg");
//		FileUtils.copyFile(new File("/Users/developer/git/xds-admin/src/main/resources/data/rid/10141.jpeg"), response.getOutputStream());
		response.setContentType("application/pdf");
		FileUtils.copyFile(new File("/Users/developer/git/xds-admin/src/main/resources/data/rid/10142.pdf"), response.getOutputStream());
	}
	
	
}
