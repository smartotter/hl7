package com.kangva.xds.admin.service;

import java.net.InetAddress;

import org.openhealthtools.ihe.atna.auditor.events.AuditEventMessage;
import org.openhealthtools.ihe.atna.auditor.sender.AuditMessageSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuditLog4jSenderImpl implements AuditMessageSender {

	private static Logger logger = LoggerFactory
			.getLogger(AuditLog4jSenderImpl.class);

	@Override
	public void sendAuditEvent(AuditEventMessage[] msg) throws Exception {
		// TODO Auto-generated method stub
		log(msg);
	}

	@Override
	public void sendAuditEvent(AuditEventMessage[] msg,
			InetAddress paramInetAddress, int paramInt) throws Exception {
		// TODO Auto-generated method stub
		log(msg);
	}

	private void log(AuditEventMessage[] msg) {
		for (AuditEventMessage message : msg) {
			logger.info(new String(message.getSerializedMessage(true)));
		}
	}
}
