package com.kangva.xds.admin.service;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kangva.xds.repository.mapper.RepositoryApplicationConfigurationMapper;
import com.kangva.xds.repository.mapper.StorageLocationMapper;
import com.kangva.xds.repository.model.RepositoryApplicationConfiguration;

@Service
public class RepositoryApplicationConfigurationService {
	private static final String SOURCE_ORGANIZATION_OID = "source.organization.oid";
	
	@Autowired
	private RepositoryApplicationConfigurationMapper repositoryApplicationConfigurationMapper;
	
	@Autowired
	private StorageLocationMapper storageLocationMapper;
	
	public String getSourceOrganization() {
		RepositoryApplicationConfiguration repositoryApplicationConfiguration = repositoryApplicationConfigurationMapper.findByKey(SOURCE_ORGANIZATION_OID);
		if(repositoryApplicationConfiguration != null){
			return repositoryApplicationConfiguration.getValue();
		}else{
			return "1.3.6.1.4.1.21367.2010.1.2.166";
		}
	}

	public String findByKey(String key) {
		
		if(StringUtils.equals(key, "storageLocation")){
			return storageLocationMapper.get();
		}
		if(StringUtils.equals(key, "repositoryUid")){
			key = "repository.uid";
		}else if(StringUtils.equals(key, "homeCommunityId")){
			key = "home.community.id";
		}else if(StringUtils.equals(key, "registryTimeout")){
			key = "registry.time.out";
		}else if(StringUtils.equals(key, "sourceId")){
			key = "source.organization.oid";
		}
		RepositoryApplicationConfiguration repositoryApplicationConfiguration = repositoryApplicationConfigurationMapper.findByKey(key);
		if(repositoryApplicationConfiguration != null){
			return repositoryApplicationConfiguration.getValue();
		}else{
			return null;
		}
	}

	public int update(String key, String value) {
		if(StringUtils.equals(key, "storageLocation")){
			return storageLocationMapper.edit(value);
		}
		if(StringUtils.equals(key, "repositoryUid")){
			key = "repository.uid";
		}else if(StringUtils.equals(key, "homeCommunityId")){
			key = "home.community.id";
		}else if(StringUtils.equals(key, "registryTimeout")){
			key = "registry.time.out";
		}else if(StringUtils.equals(key, "sourceId")){
			key = "source.organization.oid";
		}
		return repositoryApplicationConfigurationMapper.edit(key, value);
	}

}
