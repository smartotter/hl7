package com.kangva.xds.patient.model;

import java.io.Serializable;

public class Patient implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3820398533341438630L;
	private long id;

	/**
	 * PID-5
	 */
	private String familyName;
	private String givenName;
	private String secondGivenName;
	private String nameTypeCode;

	/**
	 * PID-6
	 */
	private String motherFamilyName;
	private String motherGivenName;
	private String motherSecondGivenName;
	private String motherNameTypeCode;

	/**
	 * PID-7
	 */
	private String birthday;
	/*
	 * PID-8
	 */
	private String sex;
	/**
	 * PID-10
	 */
	private String ssn;

	/**
	 * PID-11
	 */
	private String address;
	private String city;
	private String province;
	private String zipCode;

	/**
	 * PID-13
	 */
	private String phone;

	/**
	 * PID-25 1,2
	 */
	private int birthOrder;

	/**
	 * PID-24
	 * 
	 */
	private String multipleBirthInd;

	/**
	 * PID-33
	 */
	private String lastUpdateDate;

	/**
	 * PID-34
	 */
	private String lastUpdateFacility;

	private String comment;

	private String localId;
	private String globalId;
	private String domainIdOfGlobalId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getSecondGivenName() {
		return secondGivenName;
	}

	public void setSecondGivenName(String secondGivenName) {
		this.secondGivenName = secondGivenName;
	}

	public String getNameTypeCode() {
		return nameTypeCode;
	}

	public void setNameTypeCode(String nameTypeCode) {
		this.nameTypeCode = nameTypeCode;
	}

	public String getMotherFamilyName() {
		return motherFamilyName;
	}

	public void setMotherFamilyName(String motherFamilyName) {
		this.motherFamilyName = motherFamilyName;
	}

	public String getMotherGivenName() {
		return motherGivenName;
	}

	public void setMotherGivenName(String motherGivenName) {
		this.motherGivenName = motherGivenName;
	}

	public String getMotherSecondGivenName() {
		return motherSecondGivenName;
	}

	public void setMotherSecondGivenName(String motherSecondGivenName) {
		this.motherSecondGivenName = motherSecondGivenName;
	}

	public String getMotherNameTypeCode() {
		return motherNameTypeCode;
	}

	public void setMotherNameTypeCode(String motherNameTypeCode) {
		this.motherNameTypeCode = motherNameTypeCode;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getBirthOrder() {
		return birthOrder;
	}

	public void setBirthOrder(int birthOrder) {
		this.birthOrder = birthOrder;
	}

	public String getMultipleBirthInd() {
		return multipleBirthInd;
	}

	public void setMultipleBirthInd(String multipleBirthInd) {
		this.multipleBirthInd = multipleBirthInd;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdateFacility() {
		return lastUpdateFacility;
	}

	public void setLastUpdateFacility(String lastUpdateFacility) {
		this.lastUpdateFacility = lastUpdateFacility;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getLocalId() {
		return localId;
	}

	public void setLocalId(String localId) {
		this.localId = localId;
	}

	public String getGlobalId() {
		return globalId;
	}

	public void setGlobalId(String globalId) {
		this.globalId = globalId;
	}

	public String getDomainIdOfGlobalId() {
		return domainIdOfGlobalId;
	}

	public void setDomainIdOfGlobalId(String domainIdOfGlobalId) {
		this.domainIdOfGlobalId = domainIdOfGlobalId;
	}

}
