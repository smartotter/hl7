package com.kangva.xds.admin.controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;

@Controller
@RequestMapping(PathConstants.PATH_RID)
public class RIDController {
	private static Logger logger = LoggerFactory.getLogger(RIDController.class);

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(value = PathConstants.PATH_IHERETRIEVESUMMARYINFO , method = RequestMethod.GET)
	public String doGetIHERetrieveSummaryInfo(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_DISPLAY;
	}

	@RequestMapping(value = PathConstants.PATH_IHERETRIEVESUMMARYINFO+"_404" , method = RequestMethod.GET)
	public void doGetIHERetrieveSummaryInfo404(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		response.setStatus(HttpStatus.SC_NOT_FOUND);
	}
	
	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVELISTINFO , method = RequestMethod.GET)
	public String doGetIHERetrieveListInfo(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_DISPLAY;
	}

	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVELISTINFO+"_404" , method = RequestMethod.GET)
	public void doGetIHERetrieveListInfo404(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		response.setStatus(HttpStatus.SC_NOT_FOUND);
	}
	

	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVEDOCUMENT , method = RequestMethod.GET)
	public void doGetIHERetrieveDocument(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
//		response.setContentType("image/jpeg");
//		FileUtils.copyFile(new File("/Users/developer/git/xds-admin/src/main/resources/data/rid/10141.jpeg"), response.getOutputStream());
		String preferredContentType = request.getParameter("preferredContentType");
		
		 URL url = RIDController.class.getClassLoader().getResource("/");
		 String path = url.getPath();
		if(StringUtils.equals(preferredContentType, "application/pdf")){
			response.setContentType("application/pdf");
			FileUtils.copyFile(new File(path+"/data/rid/10142.pdf"), response.getOutputStream());			
		}else if(StringUtils.equals(preferredContentType, "application/x-hl7-cda-level-one+xml")){
			response.setContentType("application/x-hl7-cda-level-one+xml");
			FileUtils.copyFile(new File(path+"/data/rid/codes.xml"), response.getOutputStream());			
		}else if(StringUtils.equals(preferredContentType, "image/jpeg")){
			response.setContentType("image/jpeg");
			FileUtils.copyFile(new File(path+"/data/rid/10141.jpeg"), response.getOutputStream());			
		}
	}
	
	
}
