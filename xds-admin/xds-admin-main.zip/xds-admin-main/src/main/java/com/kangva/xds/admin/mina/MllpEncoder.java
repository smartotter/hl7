package com.kangva.xds.admin.mina;

import java.nio.charset.Charset;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderAdapter;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;


public class MllpEncoder extends ProtocolEncoderAdapter{
	Log log=LogFactory.getLog(MllpEncoder.class);
	private Charset charset;
	public MllpEncoder(){
		charset=Charset.forName("utf-8");
	}
	@Override
	public void encode(IoSession session, Object obj,
			ProtocolEncoderOutput out) throws Exception {
		MllpConfig config=new MllpConfig();
		String msg=obj.toString();
		IoBuffer buf = IoBuffer.allocate(msg.length()).setAutoExpand(true);
		buf.put(config.getStartByte());
		buf.putString(msg, charset.newEncoder());
		log.info(msg);
//		buf.put(msg.getBytes());
		buf.put(config.getEndByte1());
		buf.put(config.getEndByte2());
		buf.flip();
		out.write(buf);
		
	}

}
