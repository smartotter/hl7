package com.kangva.xds.admin.service;

import java.util.List;
import java.util.Map;

import org.openhealthtools.ihe.utils.OID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.patient.mapper.PatientMapper;
import com.kangva.xds.patient.model.Patient;

@Service
public class PatientService {
	@Autowired
	private PatientMapper patientMapper;

	@Value("${organization.root.id}")
	private String organizationRootId;
	
	public DataTable<Patient> search(Map<String, String> parameters, DataTableParameter dataTableParameter) {
		PageBounds pageBounds = dataTableParameter.toPageBounds();
		PageList<Patient> pageList = patientMapper.search(parameters,pageBounds);
		DataTable<Patient> result = new DataTable<>();
		result.setData(pageList);
		int totalRecords = pageList.getPaginator().getTotalCount();
		result.setRecordsTotal(totalRecords);
		result.setRecordsFiltered(totalRecords);
		return result;
	}

	public int delete(int id) {
		return patientMapper.delete(id);
	}

	public Patient get(long id) {
		// TODO Auto-generated method stub
		return patientMapper.get(id);
	}

	public boolean saveOrUpdate(Patient patient) {
		Patient patientFromDB = patientMapper.get(patient.getId());
		int result = -1;
		if(patientFromDB == null){
			patient.setLocalId(OID.createOIDGivenRoot(organizationRootId));
			result = patientMapper.insert(patient);
		}else{
			result = patientMapper.edit(patient);
		}
		if(result > 0){
			return true;
		}else{
			return false;
		}
	}

	public List<Patient> getAll() {
		return patientMapper.getAll();
	}

	public void update(Patient patient) {
		Patient patientFromDB = patientMapper.findByLocalId(patient.getLocalId());
		if(patientFromDB != null){
			patientFromDB.setBirthday(patient.getBirthday());
			patientFromDB.setAddress(patient.getAddress());
			patientFromDB.setSex(patient.getSex());
			patientFromDB.setFamilyName(patient.getFamilyName());
			patientFromDB.setGivenName(patient.getGivenName());
			patientFromDB.setSsn(patient.getSsn());
			patientMapper.edit(patientFromDB);
		}
	}

}
