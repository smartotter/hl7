package com.kangva.xds.admin.dto;

public class CodedMetadataTypeDto {

	private String code;
	private String schemeName;
	private String schemeUUID;
	private String displayName;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getSchemeUUID() {
		return schemeUUID;
	}

	public void setSchemeUUID(String schemeUUID) {
		this.schemeUUID = schemeUUID;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

}
