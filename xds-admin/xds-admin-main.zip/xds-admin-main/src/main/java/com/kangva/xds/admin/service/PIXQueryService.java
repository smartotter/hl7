package com.kangva.xds.admin.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openhealthexchange.openpixpdq.data.PatientIdentifier;
import org.openhealthexchange.openpixpdq.ihe.audit.IheAuditTrail;
import org.openhealthexchange.openpixpdq.ihe.audit.ParticipantObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.DataTypeException;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.v25.datatype.CX;
import ca.uhn.hl7v2.model.v25.datatype.HD;
import ca.uhn.hl7v2.model.v25.group.RSP_K23_QUERY_RESPONSE;
import ca.uhn.hl7v2.model.v25.message.QBP_Q21;
import ca.uhn.hl7v2.model.v25.message.RSP_K23;
import ca.uhn.hl7v2.model.v25.segment.MSH;
import ca.uhn.hl7v2.model.v25.segment.PID;
import ca.uhn.hl7v2.model.v25.segment.QPD;
import ca.uhn.hl7v2.model.v25.segment.RCP;
import ca.uhn.hl7v2.parser.EncodingCharacters;
import ca.uhn.hl7v2.parser.Parser;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;

import com.alibaba.druid.util.StringUtils;
import com.kangva.xds.admin.dto.QueryPatientDto;
import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.util.DateUtil;
import com.kangva.xds.admin.util.PIDUtil;
import com.kangva.xds.patient.mapper.DomainMapper;
import com.kangva.xds.patient.mapper.PIXEndpointMapper;
import com.kangva.xds.patient.model.Domain;
import com.kangva.xds.patient.model.PIXEndpoint;
import com.misyshealthcare.connect.base.audit.ActiveParticipant;
import com.misyshealthcare.connect.net.Identifier;

@Service
public class PIXQueryService extends HL7BaseService {
	private static Logger logger = LoggerFactory
			.getLogger(PIXQueryService.class);

	private static String SENDING_APPLICATION = "LWClient";
	private static String SENDING_FACILITY = "LWClient";

	@Autowired
	private DomainMapper domainMapper;

	@Autowired
	private PIXEndpointMapper pixEndpointMapper;

	public RestResponseWrapper query(String pixEndpointId, String patientLocalId,
			String sourceDomainId, String[] targetDomainIds) {
		PIXEndpoint pixEndpoint = pixEndpointMapper.get(Long.valueOf(pixEndpointId));

		if (pixEndpoint == null) {
			return RestResponseWrapper.error("Can not find the pix endpoint!");
		}

		Domain sourceDomain = null;
		if (!StringUtils.isEmpty(sourceDomainId)) {
			sourceDomain = domainMapper.get(Long.valueOf(sourceDomainId));
			if (sourceDomain == null) {
				return RestResponseWrapper
						.error("Can not found the source domain!");
			}
		}
		org.openhealthtools.ihe.xds.consumer.storedquery.FindFoldersStoredQuery a;
		List<Domain> targetDomains = new ArrayList<>();
		if(targetDomainIds != null){

			for (String domainId : targetDomainIds) {
				Domain targetDomain = domainMapper.get(Long.valueOf(domainId));
				if (targetDomain != null) {
					targetDomains.add(targetDomain);
				}
			}
		}
		

		Map<String,Object> request = constructRequestMsg(patientLocalId, sourceDomain,
				targetDomains);

		String sentMsg = (String)request.get("request");
		
		logger.info("To send messag:"+sentMsg);
		try {
			Map<String, Object> result = sendMsg(pixEndpoint, sentMsg);

			String responseMsg = (String)result.get("response");
			
			List<PatientIdentifier> patientIdentifierlist=new ArrayList<PatientIdentifier>();
			
			if(!StringUtils.isEmpty(responseMsg)){
				try{
					Parser parser = new PipeParser();
					Message message = parser.parse(responseMsg);
					if(message instanceof RSP_K23){
						RSP_K23 response = (RSP_K23)message;
						RSP_K23_QUERY_RESPONSE queryResponse = response.getQUERY_RESPONSE();
						if(queryResponse != null){
							List<QueryPatientDto> responsePatients = new ArrayList<>();
							PID pid = queryResponse.getPID();
							for(CX cx:pid.getPatientIdentifierList()){
								responsePatients.add(PIDUtil.extractPatient(cx, pid));
								patientIdentifierlist.add(convert2PatientIdentifier(cx));
							}
							result.put("patients", responsePatients);
						}
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			auditQueryLog(patientIdentifierlist, (MSH)request.get("msh"), (QPD)request.get("qpd"));
			return RestResponseWrapper.ok(result);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return RestResponseWrapper.error(e.getMessage());
		}
	}

	private PatientIdentifier convert2PatientIdentifier(CX cx) {
		PatientIdentifier pi=new PatientIdentifier();
		pi.setId(cx.getIDNumber().getValue());
		HD assigningAuthority = cx.getCx4_AssigningAuthority();
		if(assigningAuthority!=null){
			Identifier identifier=new Identifier(assigningAuthority.getHd1_NamespaceID().getValue(),assigningAuthority.getHd2_UniversalID().getValue(),assigningAuthority.getHd3_UniversalIDType().getValue());
			pi.setAssigningAuthority(identifier);
		}
		return pi;
	}

	private Map<String,Object> constructRequestMsg(String patientLocalId,
			Domain sourceDomain, List<Domain> targetDomains) {
		Map<String,Object> result = new HashMap<>();
		
		QBP_Q21 qbp = new QBP_Q21();
		MSH msh = qbp.getMSH();
		QPD qpd = qbp.getQPD();
		RCP rcp = qbp.getRCP();

		try {
			msh.getFieldSeparator().setValue("|");
			msh.getEncodingCharacters().setValue("^~\\&");
			msh.getMessageType().getMsg1_MessageCode().setValue("QBP");
			msh.getMessageType().getMsg2_TriggerEvent().setValue("Q23");
			msh.getMessageType().getMsg3_MessageStructure().setValue("QBP_Q21");
			msh.getMessageControlID().setValue(
					String.valueOf(System.currentTimeMillis()));
			msh.getMsh3_SendingApplication().getHd1_NamespaceID()
					.setValue(SENDING_APPLICATION);
			msh.getMsh4_SendingFacility().getHd1_NamespaceID()
					.setValue(SENDING_FACILITY);
			 msh.getMsh5_ReceivingApplication().getHd1_NamespaceID().setValue(SENDING_APPLICATION);
			 msh.getMsh6_ReceivingFacility().getHd1_NamespaceID().setValue(SENDING_FACILITY);
			msh.getMsh7_DateTimeOfMessage()
					.getTs1_Time()
					.setValue(
							DateUtil.format(new Date(),
									DateUtil.DATETIME_SHORT_FORMAT));
			msh.getProcessingID().getProcessingID().setValue("P");
			msh.getVersionID().getVersionID().setValue(HL7_VERSION);

			qpd.getQpd1_MessageQueryName().getCe1_Identifier()
					.setValue("IHEPIXQuery");
			qpd.getQpd1_MessageQueryName().getCe2_Text().setValue("Get Corresponding IDs");
			qpd.getQpd1_MessageQueryName().getCe3_NameOfCodingSystem().setValue("IHETest");
			
			qpd.getQpd2_QueryTag().setValue("QRY" + System.currentTimeMillis());
			Terser.set(qpd, 3, 0, 1, 1, patientLocalId);
			if (sourceDomain != null) {
				Terser.set(qpd, 3, 0, 4, 1, sourceDomain.getNamespaceId());
				Terser.set(qpd, 3, 0, 4, 2, sourceDomain.getUniversalId());
				Terser.set(qpd, 3, 0, 4, 3, sourceDomain.getUniversalidType());
			}
			for (int i = 0; i < targetDomains.size(); i++) {
				Domain targetDomain = targetDomains.get(i);
				Terser.set(qpd, 4, i, 4, 1, targetDomain.getNamespaceId());
				Terser.set(qpd, 4, i, 4, 2, targetDomain.getUniversalId());
				Terser.set(qpd, 4, i, 4, 3, targetDomain.getUniversalidType());

			}

			rcp.getRcp1_QueryPriority().setValue("I");
			Parser parser = new PipeParser();
			result.put("msh", msh);
			result.put("request", parser.encode(qbp));
			result.put("qpd", qpd);
			
			return result;
		} catch (DataTypeException e) {
			e.printStackTrace();
		} catch (HL7Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	

	   /**
	     * Audit Logging of PDQ Query Message.
	     * 
	     * @param patientIds the list of patient Identifiers to log
	     * @param hl7Header the message header from the request
	     * @param queryTag the query tag from the MSA segment of the PIX Query message
	     * @param qpd the QPD segment of the PIX Query message
	     */
	    private void auditQueryLog(List<PatientIdentifier> patientIds, ca.uhn.hl7v2.model.v25.segment.MSH hl7Header, QPD qpd) {

	    	IheAuditTrail auditTrail = getIheAuditTrail();
			//Source Application
	    	String userId = hl7Header.getMsh4_SendingFacility().getHd1_NamespaceID().getValue() + "|" +
					hl7Header.getMsh3_SendingApplication().getHd1_NamespaceID().getValue();
	    	String messageId = hl7Header.getMsh10_MessageControlID().getValue();
	    	String queryTag = qpd.getQueryTag().getValue();
			//TODO: Get the ip address of the source application
			String sourceIp = "127.0.0.1";
			ActiveParticipant source = new ActiveParticipant(userId, messageId, sourceIp);
			//Patient Info
			ParticipantObject po = new ParticipantObject();
			po.setId(patientIds);
			//Query Info
			ParticipantObject queryObj = new ParticipantObject();
			queryObj.setId(queryTag);
			queryObj.setQuery(PipeParser.encode(qpd, new EncodingCharacters('|', "^~\\&"))); 
			queryObj.setDetail(messageId);		
		
			//Finally Log it.
			auditTrail.logPixQuery(source, po, queryObj);
	    }
}
