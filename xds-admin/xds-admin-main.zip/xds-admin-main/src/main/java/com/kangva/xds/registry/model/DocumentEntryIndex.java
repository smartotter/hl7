package com.kangva.xds.registry.model;

public class DocumentEntryIndex {
	private String id;
	private String home;
	private String status;
	private String mimeType;
	private String hash;
	private String creationTime;
	private String serviceStartTime;
	private String serviceStopTime;
	private String uniqueId;
	private String classCode;
	private String classCodeScheme;
	private String clinicalEventID;
	private String formatCode;
	private String formatCodeScheme;
	private String healthCareFacilityTypeCode;
	private String healthCareFacilityTypeCodeScheme;
	private String practiceSettingCode;
	private String practiceSettingCodeScheme;
	private String typeCode;
	private String typeCodeScheme;
	private String metadata;
	private String extendedField1;
	private String extendedField2;
	private String extendedField3;
	private String patientGlobalId;
	private String insertedDateTime;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHome() {
		return home;
	}

	public void setHome(String home) {
		this.home = home;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getServiceStartTime() {
		return serviceStartTime;
	}

	public void setServiceStartTime(String serviceStartTime) {
		this.serviceStartTime = serviceStartTime;
	}

	public String getServiceStopTime() {
		return serviceStopTime;
	}

	public void setServiceStopTime(String serviceStopTime) {
		this.serviceStopTime = serviceStopTime;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	public String getClassCodeScheme() {
		return classCodeScheme;
	}

	public void setClassCodeScheme(String classCodeScheme) {
		this.classCodeScheme = classCodeScheme;
	}

	public String getClinicalEventID() {
		return clinicalEventID;
	}

	public void setClinicalEventID(String clinicalEventID) {
		this.clinicalEventID = clinicalEventID;
	}

	public String getFormatCode() {
		return formatCode;
	}

	public void setFormatCode(String formatCode) {
		this.formatCode = formatCode;
	}

	public String getHealthCareFacilityTypeCode() {
		return healthCareFacilityTypeCode;
	}

	public void setHealthCareFacilityTypeCode(String healthCareFacilityTypeCode) {
		this.healthCareFacilityTypeCode = healthCareFacilityTypeCode;
	}

	public String getHealthCareFacilityTypeCodeScheme() {
		return healthCareFacilityTypeCodeScheme;
	}

	public void setHealthCareFacilityTypeCodeScheme(
			String healthCareFacilityTypeCodeScheme) {
		this.healthCareFacilityTypeCodeScheme = healthCareFacilityTypeCodeScheme;
	}

	public String getPracticeSettingCode() {
		return practiceSettingCode;
	}

	public void setPracticeSettingCode(String practiceSettingCode) {
		this.practiceSettingCode = practiceSettingCode;
	}

	public String getPracticeSettingCodeScheme() {
		return practiceSettingCodeScheme;
	}

	public void setPracticeSettingCodeScheme(String practiceSettingCodeScheme) {
		this.practiceSettingCodeScheme = practiceSettingCodeScheme;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getExtendedField1() {
		return extendedField1;
	}

	public void setExtendedField1(String extendedField1) {
		this.extendedField1 = extendedField1;
	}

	public String getExtendedField2() {
		return extendedField2;
	}

	public void setExtendedField2(String extendedField2) {
		this.extendedField2 = extendedField2;
	}

	public String getExtendedField3() {
		return extendedField3;
	}

	public void setExtendedField3(String extendedField3) {
		this.extendedField3 = extendedField3;
	}

	public String getFormatCodeScheme() {
		return formatCodeScheme;
	}

	public void setFormatCodeScheme(String formatCodeScheme) {
		this.formatCodeScheme = formatCodeScheme;
	}

	public String getTypeCodeScheme() {
		return typeCodeScheme;
	}

	public void setTypeCodeScheme(String typeCodeScheme) {
		this.typeCodeScheme = typeCodeScheme;
	}

	public String getPatientGlobalId() {
		return patientGlobalId;
	}

	public void setPatientGlobalId(String patientGlobalId) {
		this.patientGlobalId = patientGlobalId;
	}

	public String getInsertedDateTime() {
		return insertedDateTime;
	}

	public void setInsertedDateTime(String insertedDateTime) {
		this.insertedDateTime = insertedDateTime;
	}

}
