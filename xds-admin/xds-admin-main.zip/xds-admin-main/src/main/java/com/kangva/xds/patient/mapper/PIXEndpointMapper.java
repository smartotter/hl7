package com.kangva.xds.patient.mapper;

import java.util.List;

import com.kangva.xds.patient.model.PIXEndpoint;

public interface PIXEndpointMapper {

	List<PIXEndpoint> getAll();

	PIXEndpoint get(long id);

}
