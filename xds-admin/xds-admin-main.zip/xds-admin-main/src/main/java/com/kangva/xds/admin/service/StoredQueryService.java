package com.kangva.xds.admin.service;

import java.net.URI;

import org.openhealthtools.ihe.atna.auditor.XDSSourceAuditor;
import org.openhealthtools.ihe.atna.auditor.context.AuditorModuleContext;
import org.openhealthtools.ihe.common.ebxml._3._0.rim.AssociationType1;
import org.openhealthtools.ihe.xds.consumer.B_Consumer;
import org.openhealthtools.ihe.xds.consumer.storedquery.StoredQuery;
import org.openhealthtools.ihe.xds.response.DocumentEntryResponseType;
import org.openhealthtools.ihe.xds.response.FolderResponseType;
import org.openhealthtools.ihe.xds.response.SubmissionSetResponseType;
import org.openhealthtools.ihe.xds.response.XDSQueryResponseType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kangva.xds.admin.convert.AssociationTypeConvertor;
import com.kangva.xds.admin.convert.DocumentEntryTypeConvertor;
import com.kangva.xds.admin.convert.FolderTypeConvertor;
import com.kangva.xds.admin.convert.SubmissionSetTypeConvertor;
import com.kangva.xds.admin.dto.StoredQueryResponseDto;
import com.kangva.xds.repository.mapper.DocumentRegistryMapper;
import com.kangva.xds.repository.model.DocumentRegistry;

@Service
public class StoredQueryService {
	private static Logger logger = LoggerFactory.getLogger(StoredQueryService.class);

	@Autowired
	private DocumentRegistryMapper documentRegistryMapper;

	public StoredQueryResponseDto query(boolean useAsync,int registryAddressId, StoredQuery storedQuery) throws Exception {
		DocumentRegistry documentRegistry = documentRegistryMapper.get(registryAddressId);
		if (documentRegistry == null) {
			throw new Exception("Provde wrong Registry Address!");
		}

		XDSQueryResponseType queryResponse = null;
		if (documentRegistry.isSecure()) {
			// serviceClient.engageModule("addressing");
			System.setProperty("javax.net.ssl.keyStore", documentRegistry.getKeyStoreFileName());
			System.setProperty("javax.net.ssl.keyStorePassword", documentRegistry.getKeyStorePassword());
			// System.setProperty("javax.net.ssl.trustStore",
			// "conf/mayotruststore.jks");
			System.setProperty("javax.net.ssl.trustStore", documentRegistry.getTrustKeyStoreFileName());
			System.setProperty("javax.net.ssl.trustStorePassword", documentRegistry.getTrustKeyStorePassword());

			System.setProperty("javax.net.debug", "sslhandshake");
		}

		B_Consumer c = new B_Consumer(new URI(documentRegistry.getAddress()));

		XDSSourceAuditor.getAuditor().getConfig().setAuditorEnabled(true);
		XDSSourceAuditor.getAuditor().getConfig().setAuditRepositoryHost("localhost");
		XDSSourceAuditor.getAuditor().getConfig().setAuditRepositoryPort(1234);
		XDSSourceAuditor.getAuditor().getConfig().setAuditSourceId("mdavis");
		AuditorModuleContext.getContext().setSender(new AuditLog4jSenderImpl());
		
		queryResponse = c.invokeStoredQuery(useAsync, storedQuery, false);

		logger.debug("Response status: " + queryResponse.getStatus().getName());
		logger.debug("Returned " + queryResponse.getReferences().size() + " references.");
		StoredQueryResponseDto result = new StoredQueryResponseDto();
		if(queryResponse.getDocumentEntryResponses()!=null){
			for(DocumentEntryResponseType documentEntryResponseType: queryResponse.getDocumentEntryResponses()){
				if(documentEntryResponseType.getDocumentEntry() != null){
					result.getDocuments().add(DocumentEntryTypeConvertor.convert(documentEntryResponseType.getDocumentEntry()));
				}
			}
		}
		if(queryResponse.getFolderResponses()!=null){
			for(FolderResponseType folderResponseType: queryResponse.getFolderResponses()){
				if(folderResponseType.getFolder() != null){
					result.getFolders().add(FolderTypeConvertor.convert(folderResponseType.getFolder()));
				}
			}
		}
		if(queryResponse.getSubmissionSetResponses()!=null){
			for(SubmissionSetResponseType submissionSetResponseType: queryResponse.getSubmissionSetResponses()){
				if(submissionSetResponseType.getSubmissionSet() != null){
					result.getSubmissionSets().add(SubmissionSetTypeConvertor.convert(submissionSetResponseType.getSubmissionSet(),submissionSetResponseType.getHomeCommunityId()));
				}
			}
		}
		if(queryResponse.getAssociations()!=null){
			for(AssociationType1 associationType1: queryResponse.getAssociations()){
				if(associationType1 != null){
					result.getAssociations().add(AssociationTypeConvertor.convert(associationType1));
				}
			}
		}
		return result;
	}
}
