package com.kangva.xds.repository.mapper;

import org.apache.ibatis.annotations.Param;


public interface StorageLocationMapper {
	String get();

	int edit(@Param("value")String value);
}
