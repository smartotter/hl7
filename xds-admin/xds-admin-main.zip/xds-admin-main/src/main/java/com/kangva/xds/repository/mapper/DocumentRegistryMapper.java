package com.kangva.xds.repository.mapper;

import java.util.List;
import java.util.Map;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.repository.model.DocumentRegistry;

public interface DocumentRegistryMapper {
	DocumentRegistry get(int id);
	int delete(int id);
	List<DocumentRegistry> getAll();
	void update(DocumentRegistry documentRegistry);
	void insert(DocumentRegistry documentRegistry);
	PageList<DocumentRegistry> search(Map<String, String> parameters, PageBounds pageBounds);
	int edit(DocumentRegistry documentRegistry);
}
