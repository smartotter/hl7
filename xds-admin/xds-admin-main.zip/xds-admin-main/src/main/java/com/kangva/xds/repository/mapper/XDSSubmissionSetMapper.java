package com.kangva.xds.repository.mapper;

import java.util.Map;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.repository.model.XDSSubmissionSet;

public interface XDSSubmissionSetMapper {

	PageList<XDSSubmissionSet> searchSubmissionSets(Map<String, String> parameters, PageBounds pageBounds);

}
