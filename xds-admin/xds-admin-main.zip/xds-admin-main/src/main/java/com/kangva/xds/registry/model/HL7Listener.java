package com.kangva.xds.registry.model;


public class HL7Listener {
	private Long id;
	private boolean active;
	private String displayName;
	private String hostname;
	private Integer port;
	private String description;
	private boolean secure;
	private String keyStoreFileName;
	private String trustKeyStoreFileName;
	private String keyStoreType = "JKS";
	private String trustKeyStoreType = "JKS";
	private String keyManagerFactoryAlgorithm = "SunX509";
	private String trustManagerFactoryAlgorithm = "SunX509";
	private String sslContextProtocol = "TLS";
	private String keyStorePassword;
	private String trustKeyStorePassword;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isSecure() {
		return secure;
	}

	public void setSecure(boolean secure) {
		this.secure = secure;
	}

	public String getKeyStoreFileName() {
		return keyStoreFileName;
	}

	public void setKeyStoreFileName(String keyStoreFileName) {
		this.keyStoreFileName = keyStoreFileName;
	}

	public String getTrustKeyStoreFileName() {
		return trustKeyStoreFileName;
	}

	public void setTrustKeyStoreFileName(String trustKeyStoreFileName) {
		this.trustKeyStoreFileName = trustKeyStoreFileName;
	}

	public String getKeyStoreType() {
		return keyStoreType;
	}

	public void setKeyStoreType(String keyStoreType) {
		this.keyStoreType = keyStoreType;
	}

	public String getTrustKeyStoreType() {
		return trustKeyStoreType;
	}

	public void setTrustKeyStoreType(String trustKeyStoreType) {
		this.trustKeyStoreType = trustKeyStoreType;
	}

	public String getKeyManagerFactoryAlgorithm() {
		return keyManagerFactoryAlgorithm;
	}

	public void setKeyManagerFactoryAlgorithm(String keyManagerFactoryAlgorithm) {
		this.keyManagerFactoryAlgorithm = keyManagerFactoryAlgorithm;
	}

	public String getTrustManagerFactoryAlgorithm() {
		return trustManagerFactoryAlgorithm;
	}

	public void setTrustManagerFactoryAlgorithm(
			String trustManagerFactoryAlgorithm) {
		this.trustManagerFactoryAlgorithm = trustManagerFactoryAlgorithm;
	}

	public String getSslContextProtocol() {
		return sslContextProtocol;
	}

	public void setSslContextProtocol(String sslContextProtocol) {
		this.sslContextProtocol = sslContextProtocol;
	}

	public String getKeyStorePassword() {
		return keyStorePassword;
	}

	public void setKeyStorePassword(String keyStorePassword) {
		this.keyStorePassword = keyStorePassword;
	}

	public String getTrustKeyStorePassword() {
		return trustKeyStorePassword;
	}

	public void setTrustKeyStorePassword(String trustKeyStorePassword) {
		this.trustKeyStorePassword = trustKeyStorePassword;
	}

}