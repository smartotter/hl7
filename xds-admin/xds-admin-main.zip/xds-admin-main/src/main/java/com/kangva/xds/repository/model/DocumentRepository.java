package com.kangva.xds.repository.model;

public class DocumentRepository {

	private Long id;

	private boolean active;

	private String name;
	private String homeCommunityId;

	private String uniqueId;
	
	private String address;

	private String comment;
	private boolean secure;

	private String keyStoreFileName;
	private String trustKeyStoreFileName;
	private String keyStorePassword;
	private String trustKeyStorePassword;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isSecure() {
		return secure;
	}

	public void setSecure(boolean secure) {
		this.secure = secure;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getKeyStoreFileName() {
		return keyStoreFileName;
	}

	public void setKeyStoreFileName(String keyStoreFileName) {
		this.keyStoreFileName = keyStoreFileName;
	}

	public String getTrustKeyStoreFileName() {
		return trustKeyStoreFileName;
	}

	public void setTrustKeyStoreFileName(String trustKeyStoreFileName) {
		this.trustKeyStoreFileName = trustKeyStoreFileName;
	}

	public String getKeyStorePassword() {
		return keyStorePassword;
	}

	public void setKeyStorePassword(String keyStorePassword) {
		this.keyStorePassword = keyStorePassword;
	}

	public String getTrustKeyStorePassword() {
		return trustKeyStorePassword;
	}

	public void setTrustKeyStorePassword(String trustKeyStorePassword) {
		this.trustKeyStorePassword = trustKeyStorePassword;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getHomeCommunityId() {
		return homeCommunityId;
	}

	public void setHomeCommunityId(String homeCommunityId) {
		this.homeCommunityId = homeCommunityId;
	}

}
