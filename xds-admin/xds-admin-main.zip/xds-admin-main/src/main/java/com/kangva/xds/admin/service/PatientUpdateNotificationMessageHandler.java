package com.kangva.xds.admin.service;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.DataTypeException;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.v25.datatype.CX;
import ca.uhn.hl7v2.model.v25.message.ACK;
import ca.uhn.hl7v2.model.v25.message.ADT_A05;
import ca.uhn.hl7v2.model.v25.segment.MSA;
import ca.uhn.hl7v2.model.v25.segment.MSH;
import ca.uhn.hl7v2.model.v25.segment.PID;
import ca.uhn.hl7v2.parser.EncodingNotSupportedException;
import ca.uhn.hl7v2.parser.GenericParser;
import ca.uhn.hl7v2.parser.Parser;
import ca.uhn.hl7v2.parser.PipeParser;

import com.kangva.xds.admin.dto.QueryPatientDto;
import com.kangva.xds.admin.util.DateUtil;
import com.kangva.xds.admin.util.PIDUtil;

@Service
public class PatientUpdateNotificationMessageHandler extends IoHandlerAdapter {  
	private static Logger logger = LoggerFactory.getLogger(PatientUpdateNotificationMessageHandler.class);

	private static String SENDING_APPLICATION = "PatientIdentityConsumer";
	private static String SENDING_FACILITY = "PatientIdentityConsumer";

	@Value("${pix.domain.universalid}")
	private String pixDomainUniversalid;
	
	@Autowired
	private PatientService patientService;
	
    public void exceptionCaught(IoSession session, Throwable cause){  
        session.close(true);  
        cause.printStackTrace();  
    }  
      
     
    public void messageReceived(IoSession session, Object msg) throws Exception {  
        String msgStr = (String)msg;  
        InetSocketAddress ra=(InetSocketAddress)session.getRemoteAddress();
        logger.info("收到客户端 IP:"+ra.getHostName()+" Port:"+ra.getPort()+"发送的字符串：" + msgStr);  
        session.write(handleMessage(msgStr));  
    }  
    
    private String handleMessage(String req){
    	logger.info(req);
    	Parser p = new GenericParser();
		Message msg;
		try {
			msg = p.parse(req);
			Parser parser = new PipeParser();
			if(msg instanceof ADT_A05){
				ADT_A05 adt=(ADT_A05)msg;
				PID pid = adt.getPID();
				List<QueryPatientDto> responsePatients = new ArrayList<>();
				for(CX cx:pid.getPatientIdentifierList()){
					responsePatients.add(PIDUtil.extractPatient(cx, pid));
				}
				for(QueryPatientDto queryPatientDto : responsePatients){
//					if(StringUtils.equals(queryPatientDto.getDomain().getUniversalId(),pixDomainUniversalid)){
						patientService.update(queryPatientDto.getPatient());
//					}
					
				}
				ACK ack=new ACK();
				MSH ackMsh=ack.getMSH();
				buildMshV25(ackMsh, "ACK", "A31", "ACK");
				MSA msa=ack.getMSA();
				msa.getMsa1_AcknowledgmentCode().setValue("AA");
				msa.getMsa2_MessageControlID().setValue(adt.getMSH().getMsh10_MessageControlID().getValue());
				String encodedMessage = parser.encode(ack);
		        logger.info(encodedMessage);
		        return encodedMessage;
			}
		} catch (EncodingNotSupportedException e) {
			e.printStackTrace();
		} catch (HL7Exception e) {
			e.printStackTrace();
		}
		
		
		return "Can't handle message:\n "+req;
    }
    private void buildMshV25(MSH ackMsh,String messageType,String triggerEvent,String msgStructure) throws DataTypeException{
		ackMsh.getFieldSeparator().setValue("|");
		ackMsh.getEncodingCharacters().setValue("^~\\&");
		ackMsh.getMessageType().getMsg1_MessageCode().setValue(messageType);
		ackMsh.getMessageType().getMsg2_TriggerEvent().setValue(triggerEvent);
		ackMsh.getMessageType().getMsg3_MessageStructure().setValue(msgStructure);
		ackMsh.getMessageControlID().setValue(String.valueOf(System.currentTimeMillis()));
		ackMsh.getMsh3_SendingApplication().getHd1_NamespaceID().setValue(SENDING_APPLICATION);
		ackMsh.getMsh4_SendingFacility().getHd1_NamespaceID().setValue(SENDING_FACILITY);
//		ackMsh.getMsh5_ReceivingApplication().getHd1_NamespaceID().setValue(receivingApplication);
//		ackMsh.getMsh6_ReceivingFacility().getHd1_NamespaceID().setValue(receivingFacility);
		ackMsh.getMsh7_DateTimeOfMessage().getTs1_Time().setValue(DateUtil.format(new Date(), DateUtil.DATETIME_SHORT_FORMAT));
		ackMsh.getProcessingID().getProcessingID().setValue("P");
		ackMsh.getVersionID().getVersionID().setValue("2.5");
	}
}  