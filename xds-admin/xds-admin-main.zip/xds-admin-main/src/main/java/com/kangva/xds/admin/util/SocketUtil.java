package com.kangva.xds.admin.util;

import java.io.IOException;
import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ca.uhn.hl7v2.llp.MinLLPReader;
import ca.uhn.hl7v2.llp.MinLLPWriter;

import com.kangva.xds.patient.model.PIXEndpoint;

public class SocketUtil {
	private static Log log=LogFactory.getLog(SocketUtil.class);
	public static String sendHL7Msg(PIXEndpoint pixEndpoint,String msg) throws Exception{
		Socket socket=null;
		String receiveMsg=null;
		try {
			socket = new Socket(pixEndpoint.getHostname(), pixEndpoint.getPort());
			MinLLPReader reader=new MinLLPReader(socket.getInputStream());
			MinLLPWriter writer=new MinLLPWriter(socket.getOutputStream());
			log.info("sending message:\n"+msg);
			writer.writeMessage(msg,"utf-8");
			receiveMsg=reader.getMessage();
			log.info("receiving message:\n" + receiveMsg);
		} finally {
			if(socket!= null){
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return receiveMsg;
	}
}
