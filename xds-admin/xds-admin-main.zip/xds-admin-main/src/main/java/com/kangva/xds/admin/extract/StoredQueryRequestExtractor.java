package com.kangva.xds.admin.extract;

import javax.servlet.http.HttpServletRequest;

import org.openhealthtools.ihe.common.hl7v2.CX;
import org.openhealthtools.ihe.common.hl7v2.XCN;
import org.openhealthtools.ihe.common.hl7v2.format.HL7V2MessageFormat;
import org.openhealthtools.ihe.common.hl7v2.format.MessageDelimiters;
import org.openhealthtools.ihe.xds.consumer.query.DateTimeRange;
import org.openhealthtools.ihe.xds.consumer.storedquery.FindDocumentsForMultiplePatientsQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.FindDocumentsQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.FindFoldersStoredQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetDocumentsQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetFolderAndContentsQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.GetRelatedDocumentsQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.StoredQuery;
import org.openhealthtools.ihe.xds.consumer.storedquery.StoredQueryConstants;
import org.openhealthtools.ihe.xds.metadata.AvailabilityStatusType;
import org.openhealthtools.ihe.xds.metadata.CodedMetadataType;
import org.openhealthtools.ihe.xds.metadata.MetadataFactory;
import org.springframework.util.StringUtils;

public class StoredQueryRequestExtractor {

	private static MetadataFactory metadataFactory = MetadataFactory.eINSTANCE;

	public static StoredQuery extract(HttpServletRequest request)
			throws Exception {
		StoredQuery result = null;
		String storedQueryPattern = request.getParameter("storedQueryPattern");
		if (StringUtils.isEmpty(storedQueryPattern)) {
			throw new Exception("Should provide the StoredQuery Pattern");
		}
		switch (storedQueryPattern) {
		case StoredQueryConstants.FIND_DOCUMENTS_UUID:
			String[] documentStatus = request
					.getParameterValues("documentStatus");
			if (documentStatus == null || documentStatus.length == 0) {
				throw new Exception("Should provide the document status");
			}
			AvailabilityStatusType[] status = new AvailabilityStatusType[documentStatus.length];
			for (int i = 0; i < documentStatus.length; i++) {
				status[i] = AvailabilityStatusType.get(documentStatus[i]);
			}

			DateTimeRange[] dateTimeRanges = null;

			String dateTimeFrom = request.getParameter("dateTimeFrom");
			String dateTimeTo = request.getParameter("dateTimeTo");

			if (!StringUtils.isEmpty(dateTimeFrom)
					&& !StringUtils.isEmpty(dateTimeTo)) {
				dateTimeRanges = new DateTimeRange[] { new DateTimeRange(
						"serviceStartTime", dateTimeFrom, dateTimeTo) };
			}

			result = new FindDocumentsQuery(extractPatientId(request),
					extractCodedMetadataTypes(request, "classCode"),
					dateTimeRanges, extractCodedMetadataTypes(request,
							"practiceSettingCode"), extractCodedMetadataTypes(
							request, "heathcareFacilityCode"),
					extractCodedMetadataTypes(request, "eventCode"),
					extractCodedMetadataTypes(request, "confidentialityCode"),
					extractCodedMetadataTypes(request, "formatCode"),
					extractAuthorPerson(request), status);
			break;
		case StoredQueryConstants.FIND_FOLDERS_UUID:

			String[] folderStatusStrs = request
					.getParameterValues("folderStatus");
			if (folderStatusStrs == null || folderStatusStrs.length == 0) {
				throw new Exception("Should provide the folder status");
			}
			AvailabilityStatusType[] folderStatus = new AvailabilityStatusType[folderStatusStrs.length];
			for (int i = 0; i < folderStatusStrs.length; i++) {
				folderStatus[i] = AvailabilityStatusType.get(folderStatusStrs[i]);
			}

			result = new FindFoldersStoredQuery(
					extractPatientId(request),folderStatus);
			break;
		case StoredQueryConstants.GET_DOCUMENTS_UUID:
			String documentId = request.getParameter("documentId");
			String isUUIDStr = request.getParameter("isUUID");
			boolean isUUID = false;
			if (!StringUtils.isEmpty(isUUIDStr)) {
				isUUID = Boolean.valueOf(isUUIDStr);
			}
			result = new GetDocumentsQuery(new String[] { documentId }, isUUID);
			break;
		case StoredQueryConstants.GET_FOLDER_AND_CONTENTS_UUID:
			result = new GetFolderAndContentsQuery("", true, null, null);
			break;
		case StoredQueryConstants.GET_RELATED_DOCUMENTS_UUID:
			result = new GetRelatedDocumentsQuery("", true, null);
			break;
		case StoredQueryConstants.MPQ_FIND_DOCUMENTS_UUID:
			result = new FindDocumentsForMultiplePatientsQuery(null);
			break;
		case StoredQueryConstants.MPQ_FIND_FOLDERS_UUID:
			result = new GetDocumentsQuery(new String[] {}, true);
			break;
		}
		return result;
	}

	private static XCN extractAuthorPerson(HttpServletRequest request) {
		String authorPerson = request.getParameter("authorPerson");
		if (StringUtils.isEmpty(authorPerson)) {
			return null;
		}
		return HL7V2MessageFormat.buildXCNFromMessageString(authorPerson,
				MessageDelimiters.COMPONENT, MessageDelimiters.SUBCOMPONENT);
	}

	private static CodedMetadataType[] extractCodedMetadataTypes(
			HttpServletRequest request, String code) {
		String heathcareFacilityCode = request.getParameter(code);
		CodedMetadataType[] heathcareFacilityCodes = null;
		if (!StringUtils.isEmpty(heathcareFacilityCode)) {
			CodedMetadataType heathcareFacilityCodeMetadata = metadataFactory
					.createCodedMetadataType();
			heathcareFacilityCodeMetadata.setCode(heathcareFacilityCode);
			heathcareFacilityCodes = new CodedMetadataType[] { heathcareFacilityCodeMetadata };
		}
		return heathcareFacilityCodes;
	}

	public static CX extractPatientId(HttpServletRequest request)
			throws Exception {
		String patientIdStr = request.getParameter("patientId");
		if (StringUtils.isEmpty(patientIdStr)) {
			throw new Exception("should input the patient id!");
		}
		CX patientId = HL7V2MessageFormat.buildCXFromMessageString(
				patientIdStr, MessageDelimiters.COMPONENT,
				MessageDelimiters.SUBCOMPONENT);

		return patientId;
	}
}
