package com.kangva.xds.admin.convert;

import org.openhealthtools.ihe.common.hl7v2.format.HL7V2MessageFormat;
import org.openhealthtools.ihe.common.hl7v2.format.MessageDelimiters;
import org.openhealthtools.ihe.xds.metadata.DocumentEntryType;

import com.kangva.xds.admin.dto.DocumentEntryMetadataDto;

public class DocumentEntryTypeConvertor {
	
	public static DocumentEntryMetadataDto convert(DocumentEntryType documentEntryType){
		if(documentEntryType == null){
			return null;
		}
		DocumentEntryMetadataDto result = new DocumentEntryMetadataDto();
		result.setId(documentEntryType.getEntryUUID());
		result.setPatientId(HL7V2MessageFormat.toMessageString(documentEntryType.getPatientId(),MessageDelimiters.COMPONENT,MessageDelimiters.SUBCOMPONENT));
		result.setUniqueId(documentEntryType.getUniqueId());
		result.setMimeType(documentEntryType.getMimeType());
		result.setStatus(documentEntryType.getAvailabilityStatus().getName());
		result.setUniqueId(documentEntryType.getUniqueId());
		result.setRepositoryUniqueId(documentEntryType.getRepositoryUniqueId());
		result.setCreationTime(documentEntryType.getCreationTime());
		return result;
	}
	
}
