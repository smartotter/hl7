package com.kangva.xds.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.kangva.xds.patient.mapper.DomainMapper;
import com.kangva.xds.patient.model.Domain;

@Service
public class DomainService {
	@Autowired
	private DomainMapper domainMapper;

	@Value("${organization.root.id}")
	private String organizationRootId;
	
	public List<Domain> getAll() {
		return domainMapper.getAll();
	}

}
