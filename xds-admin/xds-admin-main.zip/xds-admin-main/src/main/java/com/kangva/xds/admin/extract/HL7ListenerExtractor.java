package com.kangva.xds.admin.extract;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.kangva.xds.registry.model.HL7Listener;

public class HL7ListenerExtractor {

	public static HL7Listener extract(HttpServletRequest request) throws Exception{
		HL7Listener hl7Listener = new HL7Listener();
		String hl7ListenerIdStr = request.getParameter("id");
		if(!StringUtils.isEmpty(hl7ListenerIdStr)){
			hl7Listener.setId(Long.valueOf(hl7ListenerIdStr));
		}
		hl7Listener.setHostname(request.getParameter("hostname"));
		hl7Listener.setDisplayName(request.getParameter("displayName"));
		hl7Listener.setDescription(request.getParameter("description"));
		hl7Listener.setSecure(StringUtils.isEmpty(request.getParameter("secure"))?false:Boolean.valueOf(request.getParameter("secure")));
		hl7Listener.setKeyStoreFileName(request.getParameter("keyStoreFileName"));
		hl7Listener.setKeyStorePassword(request.getParameter("keyStorePassword"));
		hl7Listener.setTrustKeyStoreFileName(request.getParameter("trustKeyStoreFileName"));
		hl7Listener.setTrustKeyStorePassword(request.getParameter("trustKeyStorePassword"));
		
		return hl7Listener;
	}
}
