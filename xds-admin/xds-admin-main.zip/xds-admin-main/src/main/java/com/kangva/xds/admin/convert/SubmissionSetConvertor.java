package com.kangva.xds.admin.convert;

import com.kangva.xds.admin.dto.SubmissionSetDto;
import com.kangva.xds.repository.model.XDSSubmissionSet;

public class SubmissionSetConvertor {
	
	public static SubmissionSetDto convert(XDSSubmissionSet submissionSet){
		if(submissionSet == null){
			return null;
		}
		SubmissionSetDto newSubmissionSetDto = new SubmissionSetDto();
		newSubmissionSetDto.setId(submissionSet.getId());
		newSubmissionSetDto.setHome(submissionSet.getHome());
		newSubmissionSetDto.setPatientGlobalId(submissionSet.getPatientGlobalId());
		newSubmissionSetDto.setSourceId(submissionSet.getSourceId());
		newSubmissionSetDto.setSubmissionTime(submissionSet.getSubmissionTime());
		newSubmissionSetDto.setUniqueId(submissionSet.getUniqueId());
		newSubmissionSetDto.setInsertedDateTime(submissionSet.getInsertedDateTime());
		return newSubmissionSetDto;
	}
}
