package com.kangva.xds.repository.mapper;

import org.apache.ibatis.annotations.Param;

import com.kangva.xds.repository.model.RepositoryApplicationConfiguration;


public interface RepositoryApplicationConfigurationMapper {
	RepositoryApplicationConfiguration findByKey(String sourceOrganizationOid);

	int edit(@Param("key")String key, @Param("value")String value);
}
