package com.kangva.xds.repository.model;

public class User {

}
