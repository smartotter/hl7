package com.kangva.xds.admin.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.admin.convert.DocumentEntryIndexConvertor;
import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.admin.dto.DocumentEntryDto;
import com.kangva.xds.registry.mapper.DocumentEntryIndexMapper;
import com.kangva.xds.registry.model.DocumentEntryIndex;

@Service
public class DocumentEntryIndexService {

	@Autowired
	private DocumentEntryIndexMapper documentEntryIndexMapper;

	public DataTable<DocumentEntryDto> searchDocuments(Map<String,String> parameters,DataTableParameter dataTableParameter) {
		PageBounds pageBounds = dataTableParameter.toPageBounds();
		PageList<DocumentEntryIndex> pageList = documentEntryIndexMapper.searchDocuments(parameters,pageBounds);
		List<DocumentEntryDto> documentEntryDtos = new ArrayList<>();
		for (DocumentEntryIndex documentEntryIndex : pageList) {
			documentEntryDtos.add(DocumentEntryIndexConvertor.convert(documentEntryIndex));
		}
		DataTable<DocumentEntryDto> result = new DataTable<>();
		result.setData(documentEntryDtos);
		int totalRecords = pageList.getPaginator().getTotalCount();
		result.setRecordsTotal(totalRecords);
		result.setRecordsFiltered(totalRecords);
		return result;
	}
}
