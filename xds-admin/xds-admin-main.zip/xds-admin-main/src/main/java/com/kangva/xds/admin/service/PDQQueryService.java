package com.kangva.xds.admin.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.openhealthexchange.openpixpdq.ihe.audit.IheAuditTrail;
import org.openhealthexchange.openpixpdq.ihe.audit.ParticipantObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.DataTypeException;
import ca.uhn.hl7v2.model.GenericMessage;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.Structure;
import ca.uhn.hl7v2.model.v25.datatype.CX;
import ca.uhn.hl7v2.model.v25.group.RSP_K21_QUERY_RESPONSE;
import ca.uhn.hl7v2.model.v25.message.QBP_Q21;
import ca.uhn.hl7v2.model.v25.message.RSP_K21;
import ca.uhn.hl7v2.model.v25.segment.MSH;
import ca.uhn.hl7v2.model.v25.segment.PID;
import ca.uhn.hl7v2.model.v25.segment.QPD;
import ca.uhn.hl7v2.model.v25.segment.RCP;
import ca.uhn.hl7v2.parser.EncodingCharacters;
import ca.uhn.hl7v2.parser.Parser;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;

import com.kangva.xds.admin.dto.QueryPatientDto;
import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.util.AuditUtil;
import com.kangva.xds.admin.util.DateUtil;
import com.kangva.xds.admin.util.PIDUtil;
import com.kangva.xds.patient.mapper.DomainMapper;
import com.kangva.xds.patient.mapper.PIXEndpointMapper;
import com.kangva.xds.patient.model.Domain;
import com.kangva.xds.patient.model.PIXEndpoint;
import com.kangva.xds.patient.model.Patient;
import com.misyshealthcare.connect.base.audit.ActiveParticipant;

@Service
public class PDQQueryService extends HL7BaseService {
	private static Logger logger = LoggerFactory
			.getLogger(PDQQueryService.class);

	private static String SENDING_APPLICATION = "LWClient";
	private static String SENDING_FACILITY = "LWClient";

	@Autowired
	private DomainMapper domainMapper;

	@Autowired
	private PIXEndpointMapper pixEndpointMapper;

	public RestResponseWrapper query(String pixEndpointId,
			String sourceDomainId, String[] targetDomainIds, Patient patient) {
		PIXEndpoint pixEndpoint = pixEndpointMapper.get(Long
				.valueOf(pixEndpointId));

		if (pixEndpoint == null) {
			return RestResponseWrapper.error("Can not find the pix endpoint!");
		}

		Domain sourceDomain = null;
		if (!StringUtils.isEmpty(sourceDomainId)) {
			sourceDomain = domainMapper.get(Long.valueOf(sourceDomainId));
			if (sourceDomain == null) {
				return RestResponseWrapper
						.error("Can not found the source domain!");
			}
		}

		List<Domain> targetDomains = new ArrayList<>();
		if (targetDomainIds != null) {

			for (String domainId : targetDomainIds) {
				Domain targetDomain = domainMapper.get(Long.valueOf(domainId));
				if (targetDomain != null) {
					targetDomains.add(targetDomain);
				}
			}
		}

		Map<String, Object> requestMap = constructQPDRequestMsg("Q22", patient,
				sourceDomain, targetDomains, null);

		String sentMsg = (String) requestMap.get("request");

		logger.info("To send messag:" + sentMsg);
		try {
			Map<String, Object> result = sendMsg(pixEndpoint, sentMsg);

			String responseMsg = (String) result.get("response");

			List<org.openhealthexchange.openpixpdq.data.Patient> patients = new ArrayList<org.openhealthexchange.openpixpdq.data.Patient>();

			if (!StringUtils.isEmpty(responseMsg)) {
				try {
					Parser parser = new PipeParser();
					Message message = parser.parse(responseMsg);
					logger.info("message type:" + message);
					List<QueryPatientDto> responsePatients = new ArrayList<>();
					if (message instanceof RSP_K21) {
						RSP_K21 response = (RSP_K21) message;
						List<RSP_K21_QUERY_RESPONSE> queryResponseList = response
								.getQUERY_RESPONSEAll();
						if (queryResponseList != null) {
							for (RSP_K21_QUERY_RESPONSE queryResponse : queryResponseList) {
								PID pid = queryResponse.getPID();
								for (CX cx : pid.getPatientIdentifierList()) {
									QueryPatientDto queryPatientDto = PIDUtil.extractPatient(
											cx, pid);
									responsePatients.add(queryPatientDto);
									try {
										patients.add(AuditUtil.convertPatient(
												queryPatientDto.getDomain(),
												queryPatientDto.getPatient()));
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}
							result.put("patients", responsePatients);
						}
					} else if (message instanceof GenericMessage.V25) {
						Structure[] qpdSegments = message.getAll("PID");
						for (Structure structure : qpdSegments) {
							if (structure instanceof PID) {
								PID pid = (PID) structure;
								for (CX cx : pid.getPatientIdentifierList()) {
									QueryPatientDto queryPatientDto = PIDUtil.extractPatient(
											cx, pid);
									responsePatients.add(queryPatientDto);
									try {
										patients.add(AuditUtil.convertPatient(
												queryPatientDto.getDomain(),
												queryPatientDto.getPatient()));
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}
							result.put("patients", responsePatients);

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			auditLog(patients, (MSH) requestMap.get("msh"),
					(QPD) requestMap.get("qpd"));
			return RestResponseWrapper.ok(result);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return RestResponseWrapper.error(e.getMessage());
		}
	}

	private void buildQpd(QPD qpd, Patient patient, HttpServletRequest request,
			Domain sourceDomain) throws HL7Exception {
		int i = 0;
		if (!StringUtils.isEmpty(patient.getFamilyName())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.5.1.1");
			Terser.set(qpd, 3, i, 2, 1, patient.getFamilyName());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getGivenName())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.5.2");
			Terser.set(qpd, 3, i, 2, 1, patient.getGivenName());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getMotherFamilyName())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.6.1.1");
			Terser.set(qpd, 3, i, 2, 1, patient.getMotherFamilyName());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getMotherGivenName())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.6.2");
			Terser.set(qpd, 3, i, 2, 1, patient.getMotherGivenName());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getLocalId())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.3.1");
			Terser.set(qpd, 3, i, 2, 1, patient.getLocalId());
			i++;
		}

		if (sourceDomain != null) {
			if (!StringUtils.isEmpty(sourceDomain.getNamespaceId())) {
				Terser.set(qpd, 3, i, 1, 1, "@PIX.3.4.1");
				Terser.set(qpd, 3, i, 2, 1, sourceDomain.getNamespaceId());
				i++;
			}
			if (!StringUtils.isEmpty(sourceDomain.getUniversalId())) {
				Terser.set(qpd, 3, i, 1, 1, "@PIX.3.4.2");
				Terser.set(qpd, 3, i, 2, 1, sourceDomain.getUniversalId());
				i++;
			}
			if (!StringUtils.isEmpty(sourceDomain.getUniversalidType())) {
				Terser.set(qpd, 3, i, 1, 1, "@PIX.3.4.3");
				Terser.set(qpd, 3, i, 2, 1, sourceDomain.getUniversalidType());
				i++;
			}
		}

		if (!StringUtils.isEmpty(patient.getBirthday())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.7.1");
			Terser.set(qpd, 3, i, 2, 1, patient.getBirthday());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getSex())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.8");
			Terser.set(qpd, 3, i, 2, 1, patient.getSex());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getAddress())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.11.1.1");
			Terser.set(qpd, 3, i, 2, 1, patient.getAddress());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getCity())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.11.3");
			Terser.set(qpd, 3, i, 2, 1, patient.getCity());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getProvince())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.11.4");
			Terser.set(qpd, 3, i, 2, 1, patient.getProvince());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getZipCode())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.11.5");
			Terser.set(qpd, 3, i, 2, 1, patient.getZipCode());
			i++;
		}
		if (!StringUtils.isEmpty(patient.getSsn())) {
			Terser.set(qpd, 3, i, 1, 1, "@PID.18.1");
			Terser.set(qpd, 3, i, 2, 1, patient.getSsn());
			i++;
		}

		if (request != null) {
			String patientClass = request.getParameter("patientClass");
			if (!StringUtils.isEmpty(patientClass)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, patientClass);
				i++;
			}

			String assignedPatientLocation = request
					.getParameter("assignedPatientLocation");
			if (!StringUtils.isEmpty(assignedPatientLocation)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, assignedPatientLocation);
				i++;
			}

			String attendingDoctor = request.getParameter("attendingDoctor");
			if (!StringUtils.isEmpty(attendingDoctor)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, attendingDoctor);
				i++;
			}

			String referringDoctor = request.getParameter("referringDoctor");
			if (!StringUtils.isEmpty(referringDoctor)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, referringDoctor);
				i++;
			}

			String consultingDoctor = request.getParameter("consultingDoctor");
			if (!StringUtils.isEmpty(consultingDoctor)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, consultingDoctor);
				i++;
			}

			String hospitalService = request.getParameter("hospitalService");
			if (!StringUtils.isEmpty(hospitalService)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, hospitalService);
				i++;
			}

			String admittingDoctor = request.getParameter("admittingDoctor");
			if (!StringUtils.isEmpty(admittingDoctor)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, admittingDoctor);
				i++;
			}

			String visitNumber = request.getParameter("visitNumber");
			if (!StringUtils.isEmpty(visitNumber)) {
				Terser.set(qpd, 3, i, 1, 1, "@PV1.2");
				Terser.set(qpd, 3, i, 2, 1, visitNumber);
				i++;
			}
		}

	}

	public RestResponseWrapper vQuery(String pixEndpointId,
			String sourceDomainId, String[] targetDomainIds, Patient patient,
			HttpServletRequest request) {
		PIXEndpoint pixEndpoint = pixEndpointMapper.get(Long
				.valueOf(pixEndpointId));

		if (pixEndpoint == null) {
			return RestResponseWrapper.error("Can not find the pix endpoint!");
		}

		Domain sourceDomain = null;
		if (!StringUtils.isEmpty(sourceDomainId)) {
			sourceDomain = domainMapper.get(Long.valueOf(sourceDomainId));
			if (sourceDomain == null) {
				return RestResponseWrapper
						.error("Can not found the source domain!");
			}
		}

		List<Domain> targetDomains = new ArrayList<>();
		if (targetDomainIds != null) {

			for (String domainId : targetDomainIds) {
				Domain targetDomain = domainMapper.get(Long.valueOf(domainId));
				if (targetDomain != null) {
					targetDomains.add(targetDomain);
				}
			}
		}

		Map<String, Object> requestMap = constructQPDRequestMsg("ZV1", patient,
				sourceDomain, targetDomains, request);

		String sentMsg = (String) requestMap.get("request");

		logger.info("To send messag:" + sentMsg);

		List<org.openhealthexchange.openpixpdq.data.Patient> patients = new ArrayList<org.openhealthexchange.openpixpdq.data.Patient>();

		try {
			Map<String, Object> result = sendMsg(pixEndpoint, sentMsg);

			String responseMsg = (String) result.get("response");

			if (!StringUtils.isEmpty(responseMsg)) {
				try {
					Parser parser = new PipeParser();
					Message message = parser.parse(responseMsg);
					logger.info("message type:" + message);
					List<QueryPatientDto> responsePatients = new ArrayList<>();
					if (message instanceof RSP_K21) {
						RSP_K21 response = (RSP_K21) message;
						List<RSP_K21_QUERY_RESPONSE> queryResponseList = response
								.getQUERY_RESPONSEAll();
						if (queryResponseList != null) {
							for (RSP_K21_QUERY_RESPONSE queryResponse : queryResponseList) {
								PID pid = queryResponse.getPID();
								for (CX cx : pid.getPatientIdentifierList()) {
									QueryPatientDto queryPatientDto = PIDUtil.extractPatient(
											cx, pid);
									responsePatients.add(queryPatientDto);
									try {
										patients.add(AuditUtil.convertPatient(
												queryPatientDto.getDomain(),
												queryPatientDto.getPatient()));
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}
							result.put("patients", responsePatients);
						}
					} else if (message instanceof GenericMessage.V25) {
						Structure[] qpdSegments = message.getAll("PID");
						for (Structure structure : qpdSegments) {
							if (structure instanceof PID) {
								PID pid = (PID) structure;
								for (CX cx : pid.getPatientIdentifierList()) {
									QueryPatientDto queryPatientDto = PIDUtil.extractPatient(
											cx, pid);
									responsePatients.add(queryPatientDto);
									try {
										patients.add(AuditUtil.convertPatient(
												queryPatientDto.getDomain(),
												queryPatientDto.getPatient()));
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}
							result.put("patients", responsePatients);

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return RestResponseWrapper.ok(result);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return RestResponseWrapper.error(e.getMessage());
		}
	}

	/**
	 * 
	 * @param triggerEvent
	 *            ZV1/Q22
	 * @param patient
	 * @param sourceDomain
	 * @param targetDomains
	 * @param request
	 * @return
	 */
	private Map<String, Object> constructQPDRequestMsg(String triggerEvent,
			Patient patient, Domain sourceDomain, List<Domain> targetDomains,
			HttpServletRequest request) {

		Map<String, Object> result = new HashMap<>();

		QBP_Q21 qbp = new QBP_Q21();
		MSH msh = qbp.getMSH();
		QPD qpd = qbp.getQPD();
		RCP rcp = qbp.getRCP();

		try {
			msh.getFieldSeparator().setValue("|");
			msh.getEncodingCharacters().setValue("^~\\&");
			msh.getMessageType().getMsg1_MessageCode().setValue("QBP");
			msh.getMessageType().getMsg2_TriggerEvent().setValue(triggerEvent);
			msh.getMessageType().getMsg3_MessageStructure().setValue("QBP_Q21");
			msh.getMessageControlID().setValue(
					String.valueOf(System.currentTimeMillis()));
			msh.getMsh3_SendingApplication().getHd1_NamespaceID()
					.setValue(SENDING_APPLICATION);
			msh.getMsh4_SendingFacility().getHd1_NamespaceID()
					.setValue(SENDING_APPLICATION);
			msh.getMsh5_ReceivingApplication().getHd1_NamespaceID()
					.setValue(SENDING_APPLICATION);
			msh.getMsh6_ReceivingFacility().getHd1_NamespaceID()
					.setValue(SENDING_APPLICATION);
			msh.getMsh7_DateTimeOfMessage()
					.getTs1_Time()
					.setValue(
							DateUtil.format(new Date(),
									DateUtil.DATETIME_SHORT_FORMAT));
			msh.getProcessingID().getProcessingID().setValue("P");
			msh.getVersionID().getVersionID().setValue(HL7_VERSION);

			qpd.getQpd1_MessageQueryName().getCe1_Identifier().setValue("Q22");
			qpd.getQpd1_MessageQueryName().getCe2_Text()
					.setValue("Find Candidates");
			qpd.getQpd1_MessageQueryName().getCe3_NameOfCodingSystem()
					.setValue("HL7");
			qpd.getQpd2_QueryTag().setValue("QRY" + System.currentTimeMillis());

			buildQpd(qpd, patient, request, sourceDomain);

			for (int i = 0; i < targetDomains.size(); i++) {
				Domain targetDomain = targetDomains.get(i);
				Terser.set(qpd, 8, i, 4, 1, targetDomain.getNamespaceId());
				Terser.set(qpd, 8, i, 4, 2, targetDomain.getUniversalId());
				Terser.set(qpd, 8, i, 4, 3, targetDomain.getUniversalidType());

			}

			rcp.getRcp1_QueryPriority().setValue("I");
			rcp.getRcp2_QuantityLimitedRequest().getCq1_Quantity()
					.setValue("10");
			rcp.getRcp2_QuantityLimitedRequest().getCq2_Units()
					.getCe1_Identifier().setValue("RD");

			Parser parser = new PipeParser();
			result.put("request", parser.encode(qbp));
			result.put("msh", msh);
			result.put("qpd", qpd);
			return result;
		} catch (DataTypeException e) {
			e.printStackTrace();
		} catch (HL7Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Audit Logging of PDQ Query Message.
	 * 
	 * @param patients
	 *            the patients returned
	 * @param hl7Header
	 *            the message header from the request
	 * @param queryTag
	 *            the query tag from the MSA segment of the PDQ request
	 * @param qpd
	 *            the QPD segment of the PDQ request
	 */
	private void auditLog(
			List<org.openhealthexchange.openpixpdq.data.Patient> patients,
			MSH hl7Header, QPD qpd) {

		IheAuditTrail auditTrail = getIheAuditTrail();

		// Source Application
		String userId = hl7Header.getSendingFacility().getNamespaceID()
				.getValue()
				+ "|"
				+ hl7Header.getSendingApplication().getNamespaceID().getValue();
		String messageId = hl7Header.getMessageControlID().getValue();
		// TODO: Get the ip address of the source application
		String sourceIp = "127.0.0.1";
		ActiveParticipant source = new ActiveParticipant(userId, messageId,
				sourceIp);

		// Patient Info
		Collection<ParticipantObject> pos = new ArrayList<ParticipantObject>();
		for (org.openhealthexchange.openpixpdq.data.Patient patient : patients) {
			ParticipantObject patientObj = new ParticipantObject(patient);
			pos.add(patientObj);
		}
		// Query Info
		ParticipantObject queryObj = new ParticipantObject();
		queryObj.setId(qpd.getQpd2_QueryTag().getValue());
		queryObj.setQuery(PipeParser.encode(qpd, new EncodingCharacters('|',
				"^~\\&")));
		queryObj.setDetail(messageId);

		// Finally Log it.
		auditTrail.logPdqQuery(source, pos, queryObj);
	}
}
