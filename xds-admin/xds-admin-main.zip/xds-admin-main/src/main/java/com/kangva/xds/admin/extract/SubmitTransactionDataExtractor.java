package com.kangva.xds.admin.extract;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.openhealthtools.ihe.common.hl7v2.CX;
import org.openhealthtools.ihe.common.hl7v2.Hl7v2Factory;
import org.openhealthtools.ihe.common.hl7v2.SourcePatientInfoType;
import org.openhealthtools.ihe.common.hl7v2.XAD;
import org.openhealthtools.ihe.common.hl7v2.XCN;
import org.openhealthtools.ihe.common.hl7v2.XON;
import org.openhealthtools.ihe.common.hl7v2.XPN;
import org.openhealthtools.ihe.common.hl7v2.format.HL7V2MessageFormat;
import org.openhealthtools.ihe.common.hl7v2.format.MessageDelimiters;
import org.openhealthtools.ihe.utils.OID;
import org.openhealthtools.ihe.xds.document.DocumentDescriptor;
import org.openhealthtools.ihe.xds.document.XDSDocument;
import org.openhealthtools.ihe.xds.document.XDSDocumentFromFile;
import org.openhealthtools.ihe.xds.metadata.AuthorType;
import org.openhealthtools.ihe.xds.metadata.CodedMetadataType;
import org.openhealthtools.ihe.xds.metadata.DocumentEntryType;
import org.openhealthtools.ihe.xds.metadata.FolderType;
import org.openhealthtools.ihe.xds.metadata.InternationalStringType;
import org.openhealthtools.ihe.xds.metadata.LocalizedStringType;
import org.openhealthtools.ihe.xds.metadata.MetadataFactory;
import org.openhealthtools.ihe.xds.metadata.ParentDocumentRelationshipType;
import org.openhealthtools.ihe.xds.metadata.ParentDocumentType;
import org.openhealthtools.ihe.xds.metadata.ProvideAndRegisterDocumentSetType;
import org.openhealthtools.ihe.xds.metadata.SubmissionSetType;
import org.openhealthtools.ihe.xds.metadata.extract.MetadataExtractionException;
import org.openhealthtools.ihe.xds.metadata.transform.EbXML_3_0ProvideAndRegisterDocumentSetTransformer;
import org.openhealthtools.ihe.xds.metadata.transform.MetadataTransformationException;
import org.openhealthtools.ihe.xds.source.SubmitTransactionCompositionException;
import org.openhealthtools.ihe.xds.source.SubmitTransactionData;
import org.openhealthtools.ihe.xds.source.utils.EbXML_3_0MetadataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import com.kangva.xds.admin.dto.CodedMetadataTypeDto;
import com.kangva.xds.admin.util.CodesResources;

public class SubmitTransactionDataExtractor {

	private static Logger logger = LoggerFactory.getLogger(SubmitTransactionDataExtractor.class);

	private static Hl7v2Factory hl7v2Factory = Hl7v2Factory.eINSTANCE;
	
	private static MetadataFactory metadataFactory = MetadataFactory.eINSTANCE;
	
	public static String transform(SubmitTransactionData submitTransactionData){
		EbXML_3_0ProvideAndRegisterDocumentSetTransformer setTransformer = new EbXML_3_0ProvideAndRegisterDocumentSetTransformer();

		// Transform our P&R request metadata to ebXML 3.0
		ProvideAndRegisterDocumentSetType meta = submitTransactionData.getMetadata();
		try {
			setTransformer.transform(meta);
		} catch (MetadataTransformationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// Serialize to ebXML payload to DOM
		Element ebXMLMetadata;
		try {
			ebXMLMetadata = EbXML_3_0MetadataUtils.unpackSubmitObjectsRequest(setTransformer.getSubmitReq());
			TransformerFactory transFactory = TransformerFactory.newInstance();
			Transformer transformer = null;
			try {
				transformer = transFactory.newTransformer();
			} catch (TransformerConfigurationException e) {
				e.printStackTrace();
			}
			StringWriter buffer = new StringWriter();
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");  
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			try {
				transformer.transform(new DOMSource(ebXMLMetadata), new StreamResult(buffer));
			} catch (TransformerException e) {
				e.printStackTrace();
			}
			return buffer.toString();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return null;
		
	}
	
	public static void extract(HttpServletRequest request, String organizationOID,SubmitTransactionData txnData) throws Exception {
		logger.info("extract SubmitTransactionData from the http request");

		//SubmitTransactionData txnData = new SubmitTransactionData();

		String selectedUploadTypeStr = request.getParameter("selectedUploadType");
		
		boolean isUploadDocument = false;
		
		if(!StringUtils.isEmpty(selectedUploadTypeStr)){
			try{
				isUploadDocument = Boolean.valueOf(selectedUploadTypeStr);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		if(isUploadDocument){
			logger.info("Upload the document");
			//addDocumentEntry(request, organizationOID, txnData);
		}else{
			logger.info("upload folder");
			addFolder(request, organizationOID, txnData);
		}
		addSubmissionSet(request, organizationOID, txnData.getSubmissionSet());

	}

	private static void addSubmissionSet(HttpServletRequest request, String organizationOID,
			SubmissionSetType submissionSetType) throws Exception {
		// add submission set metadata
		logger.debug("Applying Submission Set Metadata to the Submission.");
		submissionSetType.setUniqueId(OID.create64CharOIDGivenRoot(organizationOID));
		// set submission time
		submissionSetType.setSubmissionTime(formGMT_DTM());
//		submissionSetType.setAuthor(arg0);
		submissionSetType.setTitle(createInternationalStringType(request.getParameter("submissionSetTitle")));
		submissionSetType.setComments(createInternationalStringType(request.getParameter("submissionSetComments")));
		submissionSetType.setPatientId(extractPatientId(request));
		submissionSetType.setContentTypeCode(getCodedMetadataType(CodesResources.contentTypeCodes,request.getParameter("contentTypeCode")));
		// set submission set source id
		submissionSetType.setSourceId(organizationOID);
		AuthorType authorType = createAuthor(request.getParameter("submissionSetAuthorPerson"),null,null,null);
		if(authorType != null){
			submissionSetType.setAuthor(authorType);
		}
	}

	@SuppressWarnings("unchecked")
	private static String addFolder(HttpServletRequest request, String organizationOID, SubmitTransactionData txnData) throws Exception {
		logger.debug("Applying Submission Set Metadata to the Submission.");
		String folderUUID = txnData.addFolder();
		FolderType folderType = txnData.getFolder(folderUUID);
		folderType.setUniqueId(OID.create64CharOIDGivenRoot(organizationOID));
		// set submission time
		folderType.setLastUpdateTime(formGMT_DTM());
		folderType.setTitle(createInternationalStringType(request.getParameter("folderTitle")));
		folderType.setComments(createInternationalStringType(request.getParameter("folderComments")));
		folderType.setPatientId(extractPatientId(request));
		CodedMetadataType folderCodeList = getCodedMetadataType(CodesResources.folderCodeLists,request.getParameter("folderCodeList"));
		if(folderCodeList != null){
			folderType.getCode().add(folderCodeList);
		}
		return folderUUID;
	}

	@SuppressWarnings("unchecked")
	public static String addDocumentEntry(HttpServletRequest request, String organizationOID,
			SubmitTransactionData txnData) throws Exception {
		XDSDocument clinicalDocument;
		try {
			
			String fileUploadName = request.getParameter("fileUploadName");
			if(StringUtils.isEmpty(fileUploadName)){
				throw new Exception("Should provide the Upload file Name");
			}
			DocumentDescriptor documentDescriptor = createDocumentDescriptor(request);
			
			clinicalDocument = new XDSDocumentFromFile(documentDescriptor, fileUploadName);
			
			String docEntryUUID = txnData.addDocument(clinicalDocument);
			
			DocumentEntryType documentEntryType = txnData.getDocumentEntry(docEntryUUID);
			logger.info("Add the patientId to documentEntry");
			documentEntryType.setMimeType(documentDescriptor.getMimeType());
			documentEntryType.setTitle(createInternationalStringType(request.getParameter("title")));
			documentEntryType.setParentDocument(createParentDocument(request));
			documentEntryType.setCreationTime(StringUtils.trimToNull(request.getParameter("documentCreationTime")));
			documentEntryType.setServiceStartTime(StringUtils.trimToNull(request.getParameter("serviceStartTime")));
			documentEntryType.setServiceStopTime(StringUtils.trimToNull(request.getParameter("serviceStopTime")));
			documentEntryType.setPatientId(extractPatientId(request));
			documentEntryType.setLegalAuthenticator(createXCN(request.getParameter("legalAuthenticator")));
			AuthorType authorType = createAuthor(request.getParameter("documentAuthorPerson"),
					request.getParameter("documentAuthorInstitution"),
					request.getParameter("documentAuthRole"),
					request.getParameter("documentAuthorSpecialty"));
			if(authorType != null){
				documentEntryType.getAuthors().add(authorType);
			}
			
			documentEntryType.setSourcePatientInfo(createSourcePatientInfo(request));
			
			documentEntryType.setLanguageCode(StringUtils.trimToNull(request.getParameter("language")));
			
			documentEntryType.setUniqueId(OID.createOIDGivenRoot(organizationOID, 64));
			logger.debug("Done setting documentEntry metadata for: " + documentEntryType.toString());
			
			documentEntryType.setClassCode(getCodedMetadataType(CodesResources.classCodes,request.getParameter("classCode")));
			documentEntryType.setFormatCode(getCodedMetadataType(CodesResources.formatCodes,request.getParameter("formatCode")));
			documentEntryType.setHealthCareFacilityTypeCode(getCodedMetadataType(CodesResources.healthcareFacilityTypeCodes,request.getParameter("heathcareFacilityCode")));
			documentEntryType.setPracticeSettingCode(getCodedMetadataType(CodesResources.practiceSettingCodes,request.getParameter("practiceSettingCode")));
			CodedMetadataType confidentialityCode = getCodedMetadataType(CodesResources.confidentialityCodes,request.getParameter("confidentialityCode"));
			if(confidentialityCode != null){
				documentEntryType.getConfidentialityCode().add(confidentialityCode);
			}
			documentEntryType.setTypeCode(getCodedMetadataType(CodesResources.typeCodes,request.getParameter("typeCode")));
			CodedMetadataType eventCodeList = getCodedMetadataType(CodesResources.eventCodeLists,request.getParameter("eventCodeList"));
			if(eventCodeList != null){
				documentEntryType.getEventCode().add(eventCodeList);
			}
			
			String parentFolderUUID = request.getParameter("parentFolderUUID");
			if(!StringUtils.isEmpty(parentFolderUUID)){
				txnData.addExistingFolder(parentFolderUUID);
				FolderType folderType = txnData.getFolder(parentFolderUUID);
				folderType.getAssociatedDocuments().add(docEntryUUID);
			}
			return docEntryUUID;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MetadataExtractionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SubmitTransactionCompositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private static SourcePatientInfoType createSourcePatientInfo(HttpServletRequest request) {
		SourcePatientInfoType sourcePatientInfoType = hl7v2Factory.createSourcePatientInfoType();
		sourcePatientInfoType.setPatientDateOfBirth(request.getParameter("patientDateOfBirth"));
		sourcePatientInfoType.setPatientSex(request.getParameter("patientSex"));
		sourcePatientInfoType.setPatientAddress(createXAD(request.getParameter("patientAddress")));
		return sourcePatientInfoType;
	}

	private static ParentDocumentType createParentDocument(HttpServletRequest request) {
		String parentDocumentUUID = request.getParameter("parentDocumentUUID");
		if(StringUtils.isEmpty(parentDocumentUUID)){
			return null;
		}
		ParentDocumentType parentDocumentType = metadataFactory.createParentDocumentType();
		parentDocumentType.setParentDocumentId(parentDocumentUUID);
		
		switch (request.getParameter("parentDocumentType")){
		case "XFRM":
			parentDocumentType.setParentDocumentRelationship(ParentDocumentRelationshipType.XFRM_LITERAL);
			break;
		case "RPLC":
			parentDocumentType.setParentDocumentRelationship(ParentDocumentRelationshipType.RPLC_LITERAL);
			break;
		case "APND":
			parentDocumentType.setParentDocumentRelationship(ParentDocumentRelationshipType.APND_LITERAL);
			break;
		case "XFRMRPLC":
			parentDocumentType.setParentDocumentRelationship(ParentDocumentRelationshipType.XFRMRPLC_LITERAL);
			break;
		}
		
		return parentDocumentType;
	}

	private static DocumentDescriptor createDocumentDescriptor(HttpServletRequest request) {
		String selectedDocumentDescriptor = request.getParameter("documentDescriptor");
		switch (selectedDocumentDescriptor) {
		case "pdf":
			return new DocumentDescriptor("pdf","application/pdf");
		case "xml":
			return new DocumentDescriptor("xml","text/xml");
		case "dicom":
			return new DocumentDescriptor("dicom","application/dicom");
		case "hl7":
			return new DocumentDescriptor("hl7","application/x-hl7");
		case "txt":
			return new DocumentDescriptor("txt","text/plain");
		case "mpr":
			return new DocumentDescriptor("mpr","multipart/related");
		case "tiff":
			return new DocumentDescriptor("tiff","image/tiff");
		case "jpeg":
			return new DocumentDescriptor("jpeg","image/jpeg");
		case "gif":
			return new DocumentDescriptor("gif","image/gif");
		case "png":
			return new DocumentDescriptor("png","image/png");
		default:
			return DocumentDescriptor.UNKNOWN;
		}
	}


	@SuppressWarnings("unchecked")
	private static AuthorType createAuthor(String authorPerson,String authorInstitution, String authRole, String authorSpecialty) {
		if(StringUtils.isEmpty(authorPerson))
			return null;
		AuthorType authorType = metadataFactory.createAuthorType();
		authorType.setAuthorPerson(createXCN(authorPerson));
		if(!StringUtils.isEmpty(authorInstitution)){
			authorType.getAuthorInstitution().add(createXON(authorInstitution));
		}
		if(!StringUtils.isEmpty(authRole)){
			authorType.getAuthorRole().add(authRole);
		}
		if(!StringUtils.isEmpty(authorSpecialty)){
			authorType.getAuthorSpeciality().add(authorSpecialty);
		}
		return authorType;
	}

	private static XON createXON(String parameter) {
		if(StringUtils.isEmpty(parameter))
			return null;
		return HL7V2MessageFormat.buildXONFromMessageString(parameter, MessageDelimiters.COMPONENT, MessageDelimiters.SUBCOMPONENT);
	}
	
	@SuppressWarnings("unused")
	private static XPN createXPN(String parameter) {
		if(StringUtils.isEmpty(parameter))
			return null;
		return HL7V2MessageFormat.buildXPNFromMessageString(parameter, MessageDelimiters.COMPONENT);
	}
	
	private static XAD createXAD(String parameter) {
		if(StringUtils.isEmpty(parameter))
			return null;
		return HL7V2MessageFormat.buildXADFromMessageString(parameter, MessageDelimiters.COMPONENT);
	}
	
	private static XCN createXCN(String parameter) {
		if(StringUtils.isEmpty(parameter))
			return null;
		return HL7V2MessageFormat.buildXCNFromMessageString(parameter, MessageDelimiters.COMPONENT, MessageDelimiters.SUBCOMPONENT);
	}

	private static CodedMetadataType getCodedMetadataType(Map<String, CodedMetadataTypeDto> codesResources,String key) {
		if(StringUtils.isEmpty(key)){
			return null;
		}
		
		CodedMetadataTypeDto codedMetadataTypeDto = codesResources.get(StringUtils.trimToNull(key));
	    
		return createCodedMetadataType(codedMetadataTypeDto);
	}

	private static CX extractPatientId(HttpServletRequest request) throws Exception{
		String patientIdStr = request.getParameter("patientId");
		if(StringUtils.isEmpty(patientIdStr)){
			throw new Exception("should input the patient id!");
		}
		CX patientId = HL7V2MessageFormat.buildCXFromMessageString(patientIdStr, MessageDelimiters.COMPONENT, MessageDelimiters.SUBCOMPONENT);
		
		return patientId;
	}
	

	/**
	 * Forms a HL7 v2.5 DTM time stamp for logging of the form YYYYMMDDHHMMSS
	 * using current system time in GMT time zone
	 */
	@SuppressWarnings("unused")
	private static String formGMT_DTM() {
		String timeInGMT = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		// first, set up time in current time zone (where program is running
		sdf.setTimeZone(TimeZone.getDefault());
		String tm = sdf.format(new Date());
//
//		// convert (though there is probably is some circular logic here, oh
//		// well
//		Date specifiedTime;
//		// System.out.println("Specified time is: " + tm);
//		// System.out.println("time zone is:GMT" + offset);
//		try {
//			// switch timezone
//			specifiedTime = sdf.parse(tm);
//			sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
//			timeInGMT = sdf.format(specifiedTime);
//			// System.out.println("Specified time post conversion: "+ tm);
//			// System.exit(0);
//		} catch (ParseException e) {
//			// FIXME just skip the conversion, bad time stamp, hence bad
//			// CDA!
//			// Maybe this should be more robust?? An Exception?
//		}
		return tm;
	}
	
	private static CodedMetadataType createCodedMetadataType(CodedMetadataTypeDto codedMetadataTypeDto){	
		if(codedMetadataTypeDto == null){
			return null;
		}
		CodedMetadataType codedMetadataType = metadataFactory
				.createCodedMetadataType();
		codedMetadataType.setCode(StringUtils.trimToNull(codedMetadataTypeDto.getCode()));
		codedMetadataType.setSchemeName(StringUtils.trimToNull(codedMetadataTypeDto.getSchemeName()));
		codedMetadataType.setSchemeUUID(StringUtils.trimToNull(codedMetadataTypeDto.getSchemeUUID()));
		codedMetadataType.setDisplayName(createInternationalStringType(StringUtils.trimToNull(codedMetadataTypeDto.getDisplayName())));
		
		return codedMetadataType;
	}

	@SuppressWarnings("unchecked")
	private static InternationalStringType createInternationalStringType(String parameter) {
		if(StringUtils.isEmpty(parameter)){
			return null;
		}
		InternationalStringType internationalStringType = metadataFactory.createInternationalStringType();
		LocalizedStringType localizedStringType = metadataFactory.createLocalizedStringType();
		localizedStringType.setValue(StringUtils.trimToNull(parameter));
		internationalStringType.getLocalizedString().add(localizedStringType);
		return internationalStringType;
		
	}

}
