package com.kangva.xds.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kangva.xds.patient.mapper.PIXEndpointMapper;
import com.kangva.xds.patient.model.PIXEndpoint;

@Service
public class PIXEndpointService {
	@Autowired
	private PIXEndpointMapper pixEndpointMapper;
	
	public List<PIXEndpoint> getAll() {
		return pixEndpointMapper.getAll();
	}

	public PIXEndpoint get(long id) {
		return pixEndpointMapper.get(id);
	}

}
