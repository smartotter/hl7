package com.kangva.xds.registry.mapper;

import java.util.Map;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.registry.model.DocumentEntryIndex;

public interface DocumentEntryIndexMapper {

	PageList<DocumentEntryIndex> searchDocuments(Map<String,String> parameters,PageBounds pageBounds);
}
