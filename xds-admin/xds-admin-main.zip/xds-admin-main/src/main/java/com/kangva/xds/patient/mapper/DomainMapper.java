package com.kangva.xds.patient.mapper;

import java.util.List;

import com.kangva.xds.patient.model.Domain;

public interface DomainMapper {

	Domain get(long id);
	List<Domain> getAll();
}
