package com.kangva.xds.patient.model;

public class PIXEndpoint {
	private long id;
	private String name;
	private String description;
	private String hostname;
	private int port;
	private boolean secure;
	private String keystorefilename;
	private String trustkeystorefilename;
	private String trustkeystorepassword;
	private String keystorepassword;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	
	public boolean isSecure() {
		return secure;
	}
	public void setSecure(boolean secure) {
		this.secure = secure;
	}
	public String getKeystorefilename() {
		return keystorefilename;
	}
	public void setKeystorefilename(String keystorefilename) {
		this.keystorefilename = keystorefilename;
	}
	public String getTrustkeystorefilename() {
		return trustkeystorefilename;
	}
	public void setTrustkeystorefilename(String trustkeystorefilename) {
		this.trustkeystorefilename = trustkeystorefilename;
	}
	public String getTrustkeystorepassword() {
		return trustkeystorepassword;
	}
	public void setTrustkeystorepassword(String trustkeystorepassword) {
		this.trustkeystorepassword = trustkeystorepassword;
	}
	public String getKeystorepassword() {
		return keystorepassword;
	}
	public void setKeystorepassword(String keystorepassword) {
		this.keystorepassword = keystorepassword;
	}
	
	
}
