package com.kangva.xds.admin.extract;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.kangva.xds.repository.model.DocumentRepository;

public class DocumentRepositoryExtractor {

	public static DocumentRepository extract(HttpServletRequest request) throws Exception{
		DocumentRepository documentRepository = new DocumentRepository();
		String RepositoryEndpointIdStr = request.getParameter("id");
		if(!StringUtils.isEmpty(RepositoryEndpointIdStr)){
			documentRepository.setId(Long.valueOf(RepositoryEndpointIdStr));
		}
		documentRepository.setAddress(request.getParameter("address"));
		documentRepository.setUniqueId(request.getParameter("uniqueId"));
		documentRepository.setComment(request.getParameter("comment"));
		documentRepository.setName(request.getParameter("name"));
		documentRepository.setSecure(StringUtils.isEmpty(request.getParameter("secure"))?false:Boolean.valueOf(request.getParameter("secure")));
		documentRepository.setKeyStoreFileName(request.getParameter("keyStoreFileName"));
		documentRepository.setKeyStorePassword(request.getParameter("keyStorePassword"));
		documentRepository.setTrustKeyStoreFileName(request.getParameter("trustKeyStoreFileName"));
		documentRepository.setTrustKeyStorePassword(request.getParameter("trustKeyStorePassword"));
		
		return documentRepository;
	}
}
