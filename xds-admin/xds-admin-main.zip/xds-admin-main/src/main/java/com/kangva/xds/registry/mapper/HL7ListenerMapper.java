package com.kangva.xds.registry.mapper;

import java.util.List;
import java.util.Map;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.registry.model.HL7Listener;

public interface HL7ListenerMapper {

	HL7Listener get(int id);
	int delete(int id);
	List<HL7Listener> getAll();
	void update(HL7Listener hl7Listener);
	void insert(HL7Listener hl7Listener);
	PageList<HL7Listener> search(Map<String, String> parameters, PageBounds pageBounds);
	int edit(HL7Listener hl7Listener);
}
