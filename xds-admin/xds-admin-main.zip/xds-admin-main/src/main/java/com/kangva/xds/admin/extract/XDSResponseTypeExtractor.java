package com.kangva.xds.admin.extract;

import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openhealthtools.ihe.xds.response.XDSResponseType;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XDSResponseTypeExtractor {
	public static String transform(XDSResponseType response){
		try {  
            // 定义工厂 API，使应用程序能够从 XML 文档获取生成 DOM 对象树的解析器  
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
            // 定义 API， 使其从 XML 文档获取 DOM 文档实例。使用此类，应用程序员可以从 XML 获取一个 Document  
            DocumentBuilder builder = factory.newDocumentBuilder();  
            // Document 接口表示整个 HTML 或 XML 文档。从概念上讲，它是文档树的根，并提供对文档数据的基本访问  
            Document document = builder.newDocument();  
              
            Element root = document.createElement("RegistryResponse");  
            document.appendChild(root);  
            root.setAttribute("status", "urn:oasis:names:tc:ebxml-regrep:ResponseStatusType:"+response.getStatus().getName());
            
              
            TransformerFactory tf = TransformerFactory.newInstance();  
            // 此抽象类的实例能够将源树转换为结果树  
            Transformer transformer = tf.newTransformer();  
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");  
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			StringWriter buffer = new StringWriter();
			try {
				transformer.transform(new DOMSource(root), new StreamResult(buffer));
			} catch (TransformerException e) {
				e.printStackTrace();
			}
			return buffer.toString();
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
		return null;
	}
}
