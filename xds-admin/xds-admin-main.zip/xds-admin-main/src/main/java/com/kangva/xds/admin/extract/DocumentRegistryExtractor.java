package com.kangva.xds.admin.extract;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.kangva.xds.repository.model.DocumentRegistry;

public class DocumentRegistryExtractor {

	public static DocumentRegistry extract(HttpServletRequest request) throws Exception{
		DocumentRegistry documentRegistry = new DocumentRegistry();
		String registryEndpointIdStr = request.getParameter("id");
		if(!StringUtils.isEmpty(registryEndpointIdStr)){
			documentRegistry.setId(Long.valueOf(registryEndpointIdStr));
		}
		documentRegistry.setAddress(request.getParameter("address"));
		documentRegistry.setComment(request.getParameter("comment"));
		documentRegistry.setName(request.getParameter("name"));
		documentRegistry.setSecure(StringUtils.isEmpty(request.getParameter("secure"))?false:Boolean.valueOf(request.getParameter("secure")));
		documentRegistry.setKeyStoreFileName(request.getParameter("keyStoreFileName"));
		documentRegistry.setKeyStorePassword(request.getParameter("keyStorePassword"));
		documentRegistry.setTrustKeyStoreFileName(request.getParameter("trustKeyStoreFileName"));
		documentRegistry.setTrustKeyStorePassword(request.getParameter("trustKeyStorePassword"));
		
		return documentRegistry;
	}
}
