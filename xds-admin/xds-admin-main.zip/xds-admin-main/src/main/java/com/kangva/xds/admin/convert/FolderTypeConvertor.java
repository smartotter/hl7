package com.kangva.xds.admin.convert;

import org.openhealthtools.ihe.common.hl7v2.format.HL7V2MessageFormat;
import org.openhealthtools.ihe.common.hl7v2.format.MessageDelimiters;
import org.openhealthtools.ihe.xds.metadata.FolderType;

import com.kangva.xds.admin.dto.FolderMetadataDto;

public class FolderTypeConvertor {
	
	public static FolderMetadataDto convert(FolderType folderType){
		if(folderType == null){
			return null;
		}
		FolderMetadataDto result = new FolderMetadataDto();
		result.setId(folderType.getEntryUUID());
		result.setPatientId(HL7V2MessageFormat.toMessageString(folderType.getPatientId(),MessageDelimiters.COMPONENT,MessageDelimiters.SUBCOMPONENT));
		result.setStatus(folderType.getAvailabilityStatus().getName());
		result.setLastUpdateTime(folderType.getLastUpdateTime());
		result.setUniqueId(folderType.getUniqueId());
		return result;
	}
}
