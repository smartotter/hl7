package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.openhealthtools.ihe.utils.XMLUtils;
import org.openhealthtools.ihe.xds.XDSQueryMetadataHandler;
import org.openhealthtools.ihe.xds.consumer.handlers.RegistryStoredQueryMetadataHandler;
import org.openhealthtools.ihe.xds.consumer.storedquery.StoredQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Element;

import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.dto.StoredQueryResponseDto;
import com.kangva.xds.admin.extract.StoredQueryRequestExtractor;
import com.kangva.xds.admin.service.DocumentRegistryService;
import com.kangva.xds.admin.service.RetrieveDocumentSetService;
import com.kangva.xds.admin.service.StoredQueryService;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;
import com.kangva.xds.repository.model.DocumentRegistry;

@Controller
@RequestMapping(PathConstants.PATH_CONSUMER)
public class ConsumerController {
	private static Logger logger = LoggerFactory.getLogger(ConsumerController.class);

	@Autowired
	private DocumentRegistryService documentRegistryService;
	
	@Autowired
	private StoredQueryService storedQueryService;

	@Autowired
	private RetrieveDocumentSetService retrieveDocumentSetService;
	
	private XDSQueryMetadataHandler storedQueryMetadataHandler = new RegistryStoredQueryMetadataHandler();

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String loginGet(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		List<DocumentRegistry> documentRegistryEndpoints = documentRegistryService.getAll();
		model.put("documentRegistryEndpoints", documentRegistryEndpoints);
		return ViewConstants.VIEW_CONSUMER;
	}

	@RequestMapping(value="/query",method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPostQuery(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the consumer page request!");

		String registryAddressIdStr = request.getParameter("registryAddressId");
		
		String useAsyncStr = request.getParameter("useAsync");
		boolean useAsync = false;
		
		if(!StringUtils.isEmpty(useAsyncStr)){
			useAsync = Boolean.valueOf(useAsyncStr);
		}
		
		if(StringUtils.isEmpty(registryAddressIdStr)){
			return RestResponseWrapper.error("Should select the Registry Address");
		}
		
		int registryAddressId = Integer.valueOf(registryAddressIdStr);

		StoredQuery storedQuery = null;
		try {
			storedQuery = StoredQueryRequestExtractor.extract(request);
		} catch (Exception e1) {
			e1.printStackTrace();
			return RestResponseWrapper.error(e1.getMessage());
		}
		
		StoredQueryResponseDto queryResponse = null;
		
		try{
			queryResponse = storedQueryService.query(useAsync, registryAddressId,storedQuery);
		}catch(Exception e){
			e.printStackTrace();
			return RestResponseWrapper.error("Submit error!");
		}
		
		Map<String,Object> result = new HashMap<>();
		try {
			Element ebXMLQuery = storedQueryMetadataHandler.processRequest(storedQuery, false);
			String ebXmlQueryString = new String(XMLUtils.serialize(ebXMLQuery));
			result.put("request", ebXmlQueryString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		result.put("response", queryResponse);
		return RestResponseWrapper.ok(result);
	}
	
	@RequestMapping(value="/retrieve",method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPostRetrieve(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the consumer page request!");

		String documentUniqueId = request.getParameter("documentUniqueId");
		String repositoryUniqueId = request.getParameter("repositoryUniqueId");
		String patientId = request.getParameter("patientId");
		
		if(StringUtils.isEmpty(documentUniqueId)){
			return RestResponseWrapper.error("Should provide the documentUniqueId");
		}
		if(StringUtils.isEmpty(repositoryUniqueId)){
			return RestResponseWrapper.error("Should provide the repositoryUniqueId");
		}
		
		Map<String, String> result;
		try {
			result = retrieveDocumentSetService.retrieve(repositoryUniqueId, documentUniqueId, patientId);
		} catch (Exception e) {
			e.printStackTrace();
			return RestResponseWrapper.error(e.getMessage());
		}
		
		return RestResponseWrapper.ok(result);
	}
}
