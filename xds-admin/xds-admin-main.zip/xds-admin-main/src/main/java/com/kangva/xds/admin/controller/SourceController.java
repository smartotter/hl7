package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.openhealthtools.ihe.xds.document.XDSDocument;
import org.openhealthtools.ihe.xds.response.XDSResponseType;
import org.openhealthtools.ihe.xds.source.SubmitTransactionData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.convert.DocumentEntryTypeConvertor;
import com.kangva.xds.admin.dto.DocumentEntryMetadataDto;
import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.extract.SubmitTransactionDataExtractor;
import com.kangva.xds.admin.extract.XDSResponseTypeExtractor;
import com.kangva.xds.admin.service.DocumentRegistryService;
import com.kangva.xds.admin.service.DocumentRepositoryService;
import com.kangva.xds.admin.service.ProvideAndRegisterDocumentSetService;
import com.kangva.xds.admin.service.RepositoryApplicationConfigurationService;
import com.kangva.xds.admin.util.CodesResources;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;
import com.kangva.xds.repository.model.DocumentRegistry;
import com.kangva.xds.repository.model.DocumentRepository;

@Controller
@RequestMapping(PathConstants.PATH_SOURCE)
public class SourceController {
	private static Logger logger = LoggerFactory.getLogger(SourceController.class);

	@Autowired
	private RepositoryApplicationConfigurationService repositoryApplicationConfigurationService;

	@Autowired
	private DocumentRegistryService documentRegistryService;
	@Autowired
	private DocumentRepositoryService documentRepositoryService;
	@Autowired
	private ProvideAndRegisterDocumentSetService provideAndRegisterDocumentSetService;

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String doGet(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		List<DocumentRegistry> documentRegistryEndpoints = documentRegistryService.getAll();
		model.put("documentRegistryEndpoints", documentRegistryEndpoints);
		List<DocumentRepository> documentRepositoryEndpoints = documentRepositoryService.getAll();
		model.put("documentRepositoryEndpoints", documentRepositoryEndpoints);
		model.put("documentRepositoryEndpoints", documentRepositoryEndpoints);
		model.put("classCodes",CodesResources.classCodes.values());
		model.put("confidentialityCodes",CodesResources.confidentialityCodes.values());
		model.put("contentTypeCodes",CodesResources.contentTypeCodes.values());
		model.put("eventCodeLists",CodesResources.eventCodeLists.values());
		model.put("folderCodeLists",CodesResources.folderCodeLists.values());
		model.put("formatCodes",CodesResources.formatCodes.values());
		model.put("healthcareFacilityTypeCodes",CodesResources.healthcareFacilityTypeCodes.values());
		model.put("practiceSettingCodes",CodesResources.practiceSettingCodes.values());
		model.put("typeCodes",CodesResources.typeCodes.values());
		return ViewConstants.VIEW_SOURCE;
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the error page request!");

		String repositoryAddressIdStr = request.getParameter("repositoryAddressId");
		
		String useAsyncStr = request.getParameter("useAsync");
		boolean useAsync = false;
		
		if(!StringUtils.isEmpty(useAsyncStr)){
			useAsync = Boolean.valueOf(useAsyncStr);
		}
		
		if(StringUtils.isEmpty(repositoryAddressIdStr)){
			return RestResponseWrapper.error("Should select the Repository Address");
		}
		
		int repositoryAddressId = Integer.valueOf(repositoryAddressIdStr);
		
		SubmitTransactionData submitTransactionData = null;

		HttpSession session = request.getSession();
		Object obj = session.getAttribute("submitTransactionData");
		if(obj == null){
			submitTransactionData = new SubmitTransactionData();
			session.setAttribute("submitTransactionData", submitTransactionData);
		}else{
			submitTransactionData = (SubmitTransactionData)obj;
		}
		
		try {
			SubmitTransactionDataExtractor.extract(request,repositoryApplicationConfigurationService.getSourceOrganization(),submitTransactionData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return RestResponseWrapper.error("Get the submit transaction data error!");
		}
		
		XDSResponseType submitResponse = null;
		
		try{
			submitResponse = provideAndRegisterDocumentSetService.submit(useAsync, submitTransactionData, repositoryAddressId);
		}catch(Exception e){
			e.printStackTrace();
			return RestResponseWrapper.error("Submit error!");
		}
		session.removeAttribute("submitTransactionData");
		Map<String,String> result = new HashMap<>();
		result.put("request", SubmitTransactionDataExtractor.transform(submitTransactionData));
		result.put("response", XDSResponseTypeExtractor.transform(submitResponse));
		return RestResponseWrapper.ok(result);
	}


	@RequestMapping(value="/upload", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPostUploadDocument(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the error page request!");

		HttpSession session = request.getSession();
		SubmitTransactionData submitTransactionData = null;
		
		Object obj = session.getAttribute("submitTransactionData");
		if(obj == null){
			submitTransactionData = new SubmitTransactionData();
			session.setAttribute("submitTransactionData", submitTransactionData);
		}else{
			submitTransactionData = (SubmitTransactionData)obj;
		}
		
		try {
			String documentUUID = SubmitTransactionDataExtractor.addDocumentEntry(request, repositoryApplicationConfigurationService.getSourceOrganization(), submitTransactionData);
		
			Map<String,String> result = new HashMap<>();
			result.put("documentUUID", documentUUID);
			return RestResponseWrapper.ok(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return RestResponseWrapper.error(e.getMessage());
		}
		
	}
	
	@RequestMapping(value="/upload", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper doGetUploadDocument(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the error page request!");

		HttpSession session = request.getSession();
		SubmitTransactionData submitTransactionData = null;
		
		Object obj = session.getAttribute("submitTransactionData");
		if(obj == null){
			submitTransactionData = new SubmitTransactionData();
			session.setAttribute("submitTransactionData", submitTransactionData);
		}else{
			submitTransactionData = (SubmitTransactionData)obj;
		}
		
		try {
			List<XDSDocument> docs = submitTransactionData.getDocList();
			List<DocumentEntryMetadataDto> dtos = new ArrayList<>();
			for(XDSDocument xdsDocument: docs){
				dtos.add(DocumentEntryTypeConvertor.convert(submitTransactionData.getDocumentEntry(xdsDocument.getDocumentEntryUUID())));
			}
			Map<String,Object> result = new HashMap<>();
			result.put("documents", dtos);
			return RestResponseWrapper.ok(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return RestResponseWrapper.error(e.getMessage());
		}
		
	}

	@RequestMapping(value="/delete/{documentEntryUUID}", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper deleteUploadDocument(HttpServletRequest request, HttpServletResponse response, @PathVariable String documentEntryUUID) throws IOException {
		logger.info("Get the error page request!");

		HttpSession session = request.getSession();
		SubmitTransactionData submitTransactionData = null;
		
		Object obj = session.getAttribute("submitTransactionData");
		if(obj == null){
			submitTransactionData = new SubmitTransactionData();
			session.setAttribute("submitTransactionData", submitTransactionData);
		}else{
			submitTransactionData = (SubmitTransactionData)obj;
		}
		
		submitTransactionData.deleteDocument(documentEntryUUID);

		return RestResponseWrapper.ok(null);
	}
}
