package com.kangva.xds.admin.service;

import java.io.File;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FileUtils;
import org.openhealthtools.ihe.atna.auditor.XDSSourceAuditor;
import org.openhealthtools.ihe.atna.auditor.context.AuditorModuleContext;
import org.openhealthtools.ihe.common.hl7v2.format.HL7V2MessageFormat;
import org.openhealthtools.ihe.common.hl7v2.format.MessageDelimiters;
import org.openhealthtools.ihe.xds.consumer.B_Consumer;
import org.openhealthtools.ihe.xds.consumer.response.XDSRetrieveDocumentSetResponseType;
import org.openhealthtools.ihe.xds.consumer.retrieve.DocumentRequestType;
import org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveDocumentSetRequestType;
import org.openhealthtools.ihe.xds.document.XDSDocument;
import org.openhealthtools.ihe.xds.response.XDSResponseType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kangva.xds.repository.mapper.DocumentRepositoryMapper;
import com.kangva.xds.repository.model.DocumentRepository;

@Service
public class RetrieveDocumentSetService {
	private static Logger logger = LoggerFactory
			.getLogger(RetrieveDocumentSetService.class);

	@Autowired
	private DocumentRepositoryMapper documentRepositoryMapper;

	@PostConstruct
	public void init() {

	}

	@SuppressWarnings("unchecked")
	public Map<String, String> retrieve(String repositoryUniqueId, String documentUniqueId,String patientId)
			throws Exception {
		DocumentRepository documentRepository = documentRepositoryMapper
				.findByUniqueId(repositoryUniqueId);
		if (documentRepository == null) {
			throw new Exception("Provde wrong Repository Address!");
		}

		Map<String, String> result = new HashMap<>();
		logger.info("Document Consumer retrieves document from Document Repository.");

		RetrieveDocumentSetRequestType retrieveRequest = org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveFactory.eINSTANCE
				.createRetrieveDocumentSetRequestType();
		// build the document request
		DocumentRequestType documentRequest = org.openhealthtools.ihe.xds.consumer.retrieve.RetrieveFactory.eINSTANCE
				.createDocumentRequestType();
		documentRequest.setHomeCommunityId(documentRepository
				.getHomeCommunityId());
		documentRequest.setRepositoryUniqueId(repositoryUniqueId);
		documentRequest.setDocumentUniqueId(documentUniqueId);
		retrieveRequest.getDocumentRequest().add(documentRequest);
		
		B_Consumer c = null;

		System.setProperty("javax.net.ssl.keyStore",
				documentRepository.getKeyStoreFileName());
		System.setProperty("javax.net.ssl.keyStorePassword",
				documentRepository.getKeyStorePassword());
		System.setProperty("javax.net.ssl.trustStore",
				documentRepository.getTrustKeyStoreFileName());
		System.setProperty("javax.net.ssl.trustStorePassword",
				documentRepository.getTrustKeyStorePassword());
		System.setProperty("javax.net.debug", "sslhandshake");

		// hehua
		c = new B_Consumer(new URI(documentRepository.getAddress()));


		XDSSourceAuditor.getAuditor().getConfig().setAuditorEnabled(true);
		XDSSourceAuditor.getAuditor().getConfig().setAuditRepositoryHost("localhost");
		XDSSourceAuditor.getAuditor().getConfig().setAuditRepositoryPort(1234);
		XDSSourceAuditor.getAuditor().getConfig().setAuditSourceId("mdavis");
		AuditorModuleContext.getContext().setSender(new AuditLog4jSenderImpl());
		
		
		// set repository
		c.getRepositoryMap().put(documentRepository.getUniqueId(),new URI(documentRepository.getAddress()));
		// execute retrieve
		XDSResponseType response = null;
		try {
			response = c.retrieveDocumentSet(retrieveRequest, HL7V2MessageFormat.buildCXFromMessageString(patientId, MessageDelimiters.COMPONENT, MessageDelimiters.SUBCOMPONENT));
		} catch (Exception e) {
			logger.error(e.toString());
			throw e;
		}
		logger.debug("Response status: " + response.getStatus().getName());
		if (response instanceof XDSRetrieveDocumentSetResponseType) {
			XDSRetrieveDocumentSetResponseType retrieveDocumentSetResponseType = (XDSRetrieveDocumentSetResponseType) response;
			if (retrieveDocumentSetResponseType.getAttachments() != null) {
				logger.debug("Returned "
						+ retrieveDocumentSetResponseType.getAttachments()
								.size() + " documents.");
				for (XDSDocument document : retrieveDocumentSetResponseType
						.getAttachments()) {
					File rootDir = new File(System.getProperty("java.io.tmpdir"));
					
					String uploadedFileId = UUID.randomUUID().toString();
					File absolutePath = new File(rootDir,uploadedFileId);
					
					FileUtils.copyInputStreamToFile(document.getStream(), absolutePath);
					logger.debug("First document returned: "
							+ document.toString());
					logger.debug("TO store the file to temp: "
							+ absolutePath.getAbsolutePath());
					result.put("mimeType", document.getDescriptor().getMimeType());
					result.put("fileName", uploadedFileId);
				}
			}
		}

		logger.debug("DONE MESA 12076");

		return result;
	}
}
