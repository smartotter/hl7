package com.kangva.xds.admin.mina;

import java.nio.charset.Charset;

public class MllpConfig {
	MllpConfig() {
		charset = Charset.defaultCharset();
		convertLFtoCR = true;
		startByte = '\013';
		endByte1 = '\034';
		endByte2 = '\r';
		validate = true;
	}

	public Charset getCharset() {
		return charset;
	}

	public void setCharset(Charset charset) {
		this.charset = charset;
	}

	public boolean isConvertLFtoCR() {
		return convertLFtoCR;
	}

	public void setConvertLFtoCR(boolean convertLFtoCR) {
		this.convertLFtoCR = convertLFtoCR;
	}

	public byte getStartByte() {
		return startByte;
	}

	public void setStartByte(byte startByte) {
		this.startByte = startByte;
	}

	public byte getEndByte1() {
		return endByte1;
	}

	public void setEndByte1(byte endByte1) {
		this.endByte1 = endByte1;
	}

	public byte getEndByte2() {
		return endByte2;
	}

	public void setEndByte2(byte endByte2) {
		this.endByte2 = endByte2;
	}

	public boolean isValidate() {
		return validate;
	}

	public void setValidate(boolean validate) {
		this.validate = validate;
	}

	private Charset charset;
	private boolean convertLFtoCR;
	private byte startByte;
	private byte endByte1;
	private byte endByte2;
	private boolean validate;
}
