package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.admin.dto.SubmissionSetDto;
import com.kangva.xds.admin.service.SubmissionSetService;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;

@Controller
@RequestMapping(PathConstants.PATH_REPOSITORY)
public class RepositoryController {
	private static Logger logger = LoggerFactory.getLogger(RepositoryController.class);

	@Autowired
	private SubmissionSetService submissionSetService;
	
	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */

	@RequestMapping(method = RequestMethod.GET)
	public String loginGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_REPOSITORY;
	}
	

	@RequestMapping(value = PathConstants.PATH_REPOSITORY_SUBMISSIONSET, method = RequestMethod.GET)
	public @ResponseBody DataTable<SubmissionSetDto> querySubmissionSetList(HttpServletRequest request){
		DataTableParameter dataTableParameter = DataTableParameter.extract(request);

		Map<String, String> parameters = new HashMap<>();
		parameters.put("patientGlobalId", StringUtils.trimToNull(request.getParameter("patientGlobalId")));
		parameters.put("sourceId", StringUtils.trimToNull(request.getParameter("sourceId")));
		parameters.put("submissionTime", StringUtils.trimToNull(request.getParameter("submissionTime")));
		
		DataTable<SubmissionSetDto> result = submissionSetService.searchSubmissionSets(parameters,dataTableParameter);
		result.setDraw(dataTableParameter.getDraw());
		return result;
	}
}
