package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.service.DomainService;
import com.kangva.xds.admin.service.PDQQueryService;
import com.kangva.xds.admin.service.PIXEndpointService;
import com.kangva.xds.admin.service.RepositoryApplicationConfigurationService;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;
import com.kangva.xds.patient.model.PIXEndpoint;
import com.kangva.xds.patient.model.Patient;

@Controller
@RequestMapping(PathConstants.PATH_PDQ)
public class PDQQueryController {
	private static Logger logger = LoggerFactory.getLogger(PDQQueryController.class);

	@Autowired
	private RepositoryApplicationConfigurationService repositoryApplicationConfigurationService;

	@Autowired
	private DomainService pdqService;

	@Autowired
	private PDQQueryService pdqQueryService;
	
	@Autowired
	private PIXEndpointService pixEndpointService;

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String doGet(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the patient page request!");
		model.put("domains", pdqService.getAll());
		List<PIXEndpoint> pixEndpoints = pixEndpointService.getAll();
		model.put("pixEndpoints", pixEndpoints);
		return ViewConstants.VIEW_PDQ;
	}
	
	@RequestMapping(value="/query", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPOSTPDQuery(HttpServletRequest request, HttpServletResponse response,@ModelAttribute Patient patient) throws IOException {
		logger.info("Get the patient page request!");
		String pixAddressId = request.getParameter("pixAddressId");
		String sourceDomainId = request.getParameter("sourceDomainId");
		String[] targetDomainIds = request.getParameterValues("targetDomainIds");
		return pdqQueryService.query(pixAddressId,sourceDomainId,targetDomainIds, patient);
	}

	@RequestMapping(value="/vquery", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPOSTPDVistQuery(HttpServletRequest request, HttpServletResponse response,@ModelAttribute Patient patient) throws IOException {
		logger.info("Get the patient page request!");
		String pixAddressId = request.getParameter("pixAddressId");
		String sourceDomainId = request.getParameter("sourceDomainId");
		String[] targetDomainIds = request.getParameterValues("targetDomainIds");
		return pdqQueryService.vQuery(pixAddressId,sourceDomainId,targetDomainIds, patient, request);
	}

}
