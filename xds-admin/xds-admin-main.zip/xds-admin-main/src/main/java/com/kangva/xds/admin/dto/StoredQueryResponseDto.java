package com.kangva.xds.admin.dto;

import java.util.ArrayList;
import java.util.List;

public class StoredQueryResponseDto {
	private List<DocumentEntryMetadataDto> documents = new ArrayList<>();

	private List<FolderMetadataDto> folders = new ArrayList<>();

	private List<SubmissionSetMetadataDto> submissionSets = new ArrayList<>();

	private List<AssociationMetadataDto> associations = new ArrayList<>();

	public List<DocumentEntryMetadataDto> getDocuments() {
		return documents;
	}

	public void setDocuments(List<DocumentEntryMetadataDto> documents) {
		this.documents = documents;
	}

	public List<FolderMetadataDto> getFolders() {
		return folders;
	}

	public void setFolders(List<FolderMetadataDto> folders) {
		this.folders = folders;
	}

	public List<SubmissionSetMetadataDto> getSubmissionSets() {
		return submissionSets;
	}

	public void setSubmissionSets(List<SubmissionSetMetadataDto> submissionSets) {
		this.submissionSets = submissionSets;
	}

	public List<AssociationMetadataDto> getAssociations() {
		return associations;
	}

	public void setAssociations(List<AssociationMetadataDto> associations) {
		this.associations = associations;
	}

}
