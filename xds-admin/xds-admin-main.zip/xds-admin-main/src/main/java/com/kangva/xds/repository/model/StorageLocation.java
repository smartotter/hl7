package com.kangva.xds.repository.model;

public class StorageLocation {
	private int id;
	private String context_path;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContext_path() {
		return context_path;
	}
	public void setContext_path(String context_path) {
		this.context_path = context_path;
	}
	
}
