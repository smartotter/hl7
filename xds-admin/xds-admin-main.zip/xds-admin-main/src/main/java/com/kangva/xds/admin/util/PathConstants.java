package com.kangva.xds.admin.util;

public interface PathConstants {
	/**
	 * The root path name
	 */
	String PATH_ROOT = "/"+ViewConstants.VIEW_ROOT;
	/**
	 * 
	 */
	String PATH_UPLOAD = "/upload";
	/**
	 * 
	 */
	String PATH_RETRIEVE = "/retrieve";
	/**
	 * The root path name
	 */
	String PATH_ERROR = "/"+ViewConstants.VIEW_ERROR;
	/**
	 * The Login Get and Post Path
	 */
	String PATH_INDEX = "/"+ViewConstants.VIEW_INDEX;
	
	/**
	 * The Login Get and Post Path
	 */
	String PATH_LOGIN = "/"+ViewConstants.VIEW_LOGIN;
	
	/**
	 * The Login Get and Post Path
	 */
	String PATH_SOURCE = "/"+ViewConstants.VIEW_SOURCE;
	String PATH_PATIENTI_IDENTITY_SOURCE = "/patient";
	String PATH_PIX = "/"+ViewConstants.VIEW_PIX;
	String PATH_PDQ = "/"+ViewConstants.VIEW_PDQ;
	String PATH_DISPLAY = "/"+ViewConstants.VIEW_DISPLAY;
	String PATH_RID = "/"+ViewConstants.VIEW_RID;
	String PATH_FILE = "/"+ViewConstants.VIEW_FILE;

	String PATH_CONFIGURATION = "/"+ViewConstants.VIEW_CONFIGURATION;
	String PATH_CONFIGURATION_SYSTEM = "/"+ViewConstants.VIEW_CONFIGURATION_SYSTEM;
	String PATH_CONFIGURATION_REGISTRY_ENDPOINT = "/"+ViewConstants.VIEW_REGISTRY_ENDPOINT;
	String PATH_CONFIGURATION_REPOSITORY_ENDPOINT = "/"+ViewConstants.VIEW_REPOSITORY_ENDPOINT;
	String PATH_CONFIGURATION_HL7_LISTENER = "/"+ViewConstants.VIEW_HL7_LISTENER;
	String PATH_CONFIGURATION_CT = "/"+ViewConstants.VIEW_CT;
	String PATH_CONSUMER = "/"+ViewConstants.VIEW_CONSUMER;
	String PATH_REGISTRY = "/"+ViewConstants.VIEW_REGISTRY;
	String PATH_REGISTRY_QUERY = "/"+ViewConstants.VIEW_QUERY;
	String PATH_REGISTRY_DOCUMENT = "/"+ViewConstants.VIEW_DOCUMENT;
	String PATH_REPOSITORY = "/"+ViewConstants.VIEW_REPOSITORY;
	String PATH_REPOSITORY_SUBMISSIONSET = "/"+ViewConstants.VIEW_SUBMISSIONSET;
	String PATH_HELP = "/"+ViewConstants.VIEW_HELP;

	String PATH_IHERETRIEVESUMMARYINFO = "/"+ViewConstants.VIEW_IHERETRIEVESUMMARYINFO;
	String VIEW_IHERETRIEVELISTINFO = "/"+ViewConstants.VIEW_IHERETRIEVELISTINFO;
	String VIEW_IHERETRIEVEDOCUMENT = "/"+ViewConstants.VIEW_IHERETRIEVEDOCUMENT;
}
