package com.kangva.xds.admin.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openhealthexchange.openpixpdq.ihe.audit.IheAuditTrail;
import org.openhealthexchange.openpixpdq.ihe.audit.ParticipantObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.DataTypeException;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.v25.datatype.CX;
import ca.uhn.hl7v2.model.v25.datatype.HD;
import ca.uhn.hl7v2.model.v25.datatype.XAD;
import ca.uhn.hl7v2.model.v25.datatype.XPN;
import ca.uhn.hl7v2.model.v25.message.ADT_A01;
import ca.uhn.hl7v2.model.v25.message.ADT_A39;
import ca.uhn.hl7v2.model.v25.segment.EVN;
import ca.uhn.hl7v2.model.v25.segment.MRG;
import ca.uhn.hl7v2.model.v25.segment.MSH;
import ca.uhn.hl7v2.model.v25.segment.PID;
import ca.uhn.hl7v2.model.v25.segment.PV1;
import ca.uhn.hl7v2.parser.Parser;
import ca.uhn.hl7v2.parser.PipeParser;

import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.util.AuditUtil;
import com.kangva.xds.admin.util.DateUtil;
import com.kangva.xds.patient.mapper.PIXEndpointMapper;
import com.kangva.xds.patient.mapper.PatientMapper;
import com.kangva.xds.patient.model.Domain;
import com.kangva.xds.patient.model.PIXEndpoint;
import com.kangva.xds.patient.model.Patient;
import com.misyshealthcare.connect.base.audit.ActiveParticipant;
import com.misyshealthcare.connect.base.audit.AuditCodeMappings;
import com.misyshealthcare.connect.base.audit.AuditCodeMappings.EventActionCode;

@Service
public class PatientIdentityFeedService extends HL7BaseService {
	static Logger logger = LoggerFactory
			.getLogger(PatientIdentityFeedService.class);

	private static String MESSAGE_TYPE_A01 = "A01";
	private static String MESSAGE_TYPE_A04 = "A04";
	private static String MESSAGE_TYPE_A05 = "A05";
	private static String MESSAGE_TYPE_A08 = "A08";
	private static String SENDING_APPLICATION = "LWClient";
	private static String SENDING_FACILITY = "LWClient";

	@Value("${pix.domain.namespaceid}")
	private String pixDomainNamespaceid;

	@Value("${pix.domain.universalid}")
	private String pixDomainUniversalid;

	@Value("${pix.domain.universalidtype}")
	private String pixDomainUniversalidtype;

	@Autowired
	private PatientMapper patientMapper;

	@Autowired
	private PIXEndpointMapper pixEndpointMapper;

	public RestResponseWrapper feed(long patientId, long pixEndpointId,
			String messageType) {
		PIXEndpoint pixEndpoint = pixEndpointMapper.get(pixEndpointId);

		if (pixEndpoint == null) {
			return RestResponseWrapper.error("Can not find the pix endpoint!");
		}

		if (!(StringUtils.equals(messageType, MESSAGE_TYPE_A01)
				|| StringUtils.equals(messageType, MESSAGE_TYPE_A04) || StringUtils
					.equals(messageType, MESSAGE_TYPE_A05) || StringUtils
					.equals(messageType, MESSAGE_TYPE_A08))) {
			return RestResponseWrapper.error("Wrong messageType!");
		}

		EventActionCode eventActionCode = null;Map<String, Object> requestMap = null;
		Patient patient = patientMapper.get(patientId);
		if (patient != null) {
			String sentMsg = null;
			if (StringUtils.equals(messageType, MESSAGE_TYPE_A01)) {
				logger.info("Send the A01 message");
				requestMap = constructHL7RequestMsg(patient, MESSAGE_TYPE_A01);
				eventActionCode = AuditCodeMappings.EventActionCode.Create;
			} else if (StringUtils.equals(messageType, MESSAGE_TYPE_A04)) {
				logger.info("Send the A04 message");
				requestMap = constructHL7RequestMsg(patient, MESSAGE_TYPE_A04);
				eventActionCode = AuditCodeMappings.EventActionCode.Update;
			} else if (StringUtils.equals(messageType, MESSAGE_TYPE_A05)) {
				logger.info("Send the A05 message");
				requestMap = constructHL7RequestMsg(patient, MESSAGE_TYPE_A05);
				eventActionCode = AuditCodeMappings.EventActionCode.Update;
			} else if (StringUtils.equals(messageType, MESSAGE_TYPE_A08)) {
				logger.info("Send the A08 message");
				requestMap = constructHL7RequestMsg(patient, MESSAGE_TYPE_A08);
				eventActionCode = AuditCodeMappings.EventActionCode.Update;
			}

			sentMsg = (String)requestMap.get("request");

			try {
				Map<String, Object> result = sendMsg(pixEndpoint, sentMsg);

				String responseMsg = (String)result.get("response");
				
				if(!StringUtils.isEmpty(responseMsg)){
					try{
						Parser parser = new PipeParser();
						Message message = parser.parse(responseMsg);
						logger.info("message type:"+message);
//						if(message instanceof RSP_K22){
//							RSP_K22 response = (RSP_K22)message;
//							RSP_K23_QUERY_RESPONSE queryResponse = response.getQUERY_RESPONSE();
//							if(queryResponse != null){
//								List<Patient> responsePatients = new ArrayList<>();
//								PID pid = queryResponse.getPID();
//								for(CX cx:pid.getPatientIdentifierList()){
//									responsePatients.add(extractPatient(cx, pid));
//								}
//								result.put("patients", responsePatients);
//							}
//						}
					}catch(Exception e){
						e.printStackTrace();
					}
				}
				Domain sourceDomain = new Domain();
				sourceDomain.setNamespaceId(pixDomainNamespaceid);
				sourceDomain.setUniversalId(pixDomainUniversalid);
				sourceDomain.setUniversalidType(pixDomainUniversalidtype);
				auditLog((MSH)requestMap.get("msh"), AuditUtil.convertPatient(sourceDomain,patient), eventActionCode);
				return RestResponseWrapper.ok(result);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return RestResponseWrapper.error(e.getMessage());
			}
		} else {
			return RestResponseWrapper.error("Can not find the patient!");
		}
	}

	private Map<String, Object> constructHL7RequestMsg(Patient patient, String triggerEvent) {
		Map<String, Object> result = new HashMap<>();
		
		ADT_A01 adt = new ADT_A01();
		MSH mshSegment = adt.getMSH();
		EVN evn = adt.getEVN();
		PID pid = adt.getPID();
		PV1 pv1 = adt.getPV1();
		try {
			mshSegment.getMsh1_FieldSeparator().setValue("|");
			mshSegment.getMsh2_EncodingCharacters().setValue("^~\\&");
			mshSegment.getMsh3_SendingApplication().getNamespaceID()
					.setValue(SENDING_APPLICATION);
			mshSegment.getMsh4_SendingFacility().getNamespaceID()
					.setValue(SENDING_FACILITY);
			 mshSegment.getMsh5_ReceivingApplication().getNamespaceID().setValue("LWClient");
			 mshSegment.getMsh6_ReceivingFacility().getNamespaceID().setValue("LWClient");
			mshSegment
					.getMsh7_DateTimeOfMessage()
					.getTs1_Time()
					.setValue(
							DateUtil.format(new Date(),
									DateUtil.DATETIME_SHORT_FORMAT));
			mshSegment.getMsh9_MessageType().getMessageCode().setValue("ADT");
			mshSegment.getMsh9_MessageType().getTriggerEvent()
					.setValue(triggerEvent);
			mshSegment.getMsh9_MessageType().getMessageStructure()
					.setValue("ADT_A01");
			mshSegment.getMsh10_MessageControlID().setValue(
					String.valueOf(System.currentTimeMillis()));
			mshSegment.getMsh11_ProcessingID().getPt1_ProcessingID()
					.setValue("P");
			mshSegment.getMsh12_VersionID().getVid1_VersionID()
					.setValue(HL7_VERSION);

			evn.getEvn2_RecordedDateTime()
					.getTs1_Time()
					.setValue(
							DateUtil.format(new Date(),
									DateUtil.DATE_SHORT_FORMAT));

			pid.getPid3_PatientIdentifierList(0).getCx1_IDNumber()
					.setValue(patient.getLocalId());
			HD hd = pid.getPid3_PatientIdentifierList(0)
					.getCx4_AssigningAuthority();
			hd.getHd1_NamespaceID().setValue(pixDomainNamespaceid);
			hd.getHd2_UniversalID().setValue(pixDomainUniversalid);
			hd.getHd3_UniversalIDType().setValue(pixDomainUniversalidtype);
			pid.getPid5_PatientName(0).getXpn1_FamilyName().getFn1_Surname()
					.setValue(patient.getFamilyName());
			pid.getPid5_PatientName(0).getXpn2_GivenName()
					.setValue(patient.getGivenName());
			pid.getPid5_PatientName(0).getXpn7_NameTypeCode().setValue("L");

			if (!StringUtils.isEmpty(patient.getMotherFamilyName())
					|| !StringUtils.isEmpty(patient.getMotherGivenName())) {
				pid.getPid6_MotherSMaidenName(0).getXpn1_FamilyName()
						.getFn1_Surname()
						.setValue(patient.getMotherFamilyName());
				pid.getPid6_MotherSMaidenName(0).getXpn2_GivenName()
						.setValue(patient.getMotherGivenName());
				pid.getPid6_MotherSMaidenName(0)
						.getXpn3_SecondAndFurtherGivenNamesOrInitialsThereof()
						.setValue(patient.getSecondGivenName());
				pid.getPid6_MotherSMaidenName(0).getXpn7_NameTypeCode()
						.setValue("L");
			}
			pid.getPid7_DateTimeOfBirth().getTs1_Time()
					.setValue(patient.getBirthday());
			if (!StringUtils.isBlank(patient.getSex())) {
				pid.getPid8_AdministrativeSex().setValue(patient.getSex());
			}
			XAD addr = pid.getPid11_PatientAddress(0);
			addr.getXad1_StreetAddress().getSad1_StreetOrMailingAddress()
					.setValue(patient.getAddress());
			addr.getXad3_City().setValue(patient.getCity());
			addr.getXad4_StateOrProvince().setValue(patient.getProvince());
			addr.getXad5_ZipOrPostalCode().setValue(patient.getZipCode());
			pid.getPid13_PhoneNumberHome(0).getXtn1_TelephoneNumber()
					.setValue(patient.getPhone());
			pid.getPid19_SSNNumberPatient().setValue(patient.getSsn());

			pv1.getPv12_PatientClass().setValue("I");

			pid.getPid24_MultipleBirthIndicator().setValue(patient.getMultipleBirthInd());
			pid.getPid25_BirthOrder().setValue(String.valueOf(patient.getBirthOrder()));
			
			pid.getPid33_LastUpdateDateTime().getTs1_Time().setValue(patient.getLastUpdateDate());
			pid.getPid34_LastUpdateFacility().getHd1_NamespaceID().setValue(patient.getLastUpdateFacility());
			Parser parser = new PipeParser();
			result.put("request", parser.encode(adt));
			result.put("msh", mshSegment);
			return result;
		} catch (DataTypeException e) {
			e.printStackTrace();
		} catch (HL7Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public RestResponseWrapper merge(long oldPatientId, long newPatientId, long pixEndpointId) {
		PIXEndpoint pixEndpoint = pixEndpointMapper.get(pixEndpointId);

		if (pixEndpoint == null) {
			return RestResponseWrapper.error("Can not find the pix endpoint!");
		}

		Patient oldPatient = patientMapper.get(oldPatientId);
		Patient newPatient = patientMapper.get(newPatientId);
		Map<String,Object> requestMap = null;
		if (oldPatient != null && newPatient != null) {
			requestMap = constructHL7MergeRequestMsg(oldPatient, newPatient);

			String sentMsg = (String)requestMap.get("request");

			try {
				Map<String, Object> result = sendMsg(pixEndpoint, sentMsg);

				Domain sourceDomain = new Domain();
				sourceDomain.setNamespaceId(pixDomainNamespaceid);
				sourceDomain.setUniversalId(pixDomainUniversalid);
				sourceDomain.setUniversalidType(pixDomainUniversalidtype);
				
				auditLog((MSH)requestMap.get("msh"),AuditUtil.convertPatient(sourceDomain,oldPatient),AuditCodeMappings.EventActionCode.Update);
				auditLog((MSH)requestMap.get("msh"),AuditUtil.convertPatient(sourceDomain,newPatient),AuditCodeMappings.EventActionCode.Delete);
				
				return RestResponseWrapper.ok(result);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return RestResponseWrapper.error(e.getMessage());
			}
		} else {
			return RestResponseWrapper.error("Can not find the patient!");
		}
	}

	private Map<String,Object> constructHL7MergeRequestMsg(Patient oldPatient,
			Patient newPatient) {
		Map<String,Object> result = new HashMap<>();
		
		ADT_A39 adt=new ADT_A39();
		MSH msh=adt.getMSH();
		PID pid=adt.getPATIENT().getPID();
		MRG mrg=adt.getPATIENT().getMRG();
		EVN evn=adt.getEVN();
		
		try {
			msh.getMsh1_FieldSeparator().setValue("|");
			msh.getMsh2_EncodingCharacters().setValue("^~\\&");
			msh.getMsh3_SendingApplication().getNamespaceID().setValue(SENDING_APPLICATION);
			msh.getMsh4_SendingFacility().getNamespaceID().setValue(SENDING_FACILITY);
//			msh.getMsh5_ReceivingApplication().getNamespaceID().setValue(ConfUtil.getReceiverApplication());
//			msh.getMsh6_ReceivingFacility().getNamespaceID().setValue(ConfUtil.getReceiverFacility());
			msh.getMsh7_DateTimeOfMessage().getTs1_Time().setValue(DateUtil.format(new Date(), DateUtil.DATETIME_SHORT_FORMAT));
			msh.getMsh9_MessageType().getMessageCode().setValue("ADT");
			msh.getMsh9_MessageType().getTriggerEvent().setValue("A40");
			msh.getMsh9_MessageType().getMessageStructure().setValue("ADT_A39");
			msh.getMsh10_MessageControlID().setValue(String.valueOf(System.currentTimeMillis()));
			msh.getMsh11_ProcessingID().getPt1_ProcessingID().setValue("P");
			msh.getMsh12_VersionID().getVid1_VersionID().setValue(HL7_VERSION);
			
			evn.getEvn2_RecordedDateTime().getTs1_Time().setValue(DateUtil.format(new Date(), DateUtil.DATE_SHORT_FORMAT));
			
			CX cx=pid.getPid3_PatientIdentifierList(0);
			cx.getCx1_IDNumber().setValue(oldPatient.getLocalId());
			HD hd=cx.getCx4_AssigningAuthority();

			hd.getHd1_NamespaceID().setValue(pixDomainNamespaceid);
			hd.getHd2_UniversalID().setValue(pixDomainUniversalid);
			hd.getHd3_UniversalIDType().setValue(pixDomainUniversalidtype);
			XPN xpn=pid.getPid5_PatientName(0);
			xpn.getXpn1_FamilyName().getFn1_Surname().setValue(oldPatient.getFamilyName());
			xpn.getXpn2_GivenName().setValue(oldPatient.getGivenName());
			xpn.getXpn7_NameTypeCode().setValue("L");
			
			CX cx2=mrg.getMrg1_PriorPatientIdentifierList(0);
			cx2.getCx1_IDNumber().setValue(newPatient.getLocalId());
			HD hd2=cx2.getCx4_AssigningAuthority();
			hd2.getHd1_NamespaceID().setValue(pixDomainNamespaceid);
			hd2.getHd2_UniversalID().setValue(pixDomainUniversalid);
			hd2.getHd3_UniversalIDType().setValue(pixDomainUniversalidtype);
			XPN xpn2=mrg.getMrg7_PriorPatientName(0);
			xpn2.getXpn1_FamilyName().getFn1_Surname().setValue(newPatient.getFamilyName());
			xpn2.getXpn2_GivenName().setValue(newPatient.getGivenName());
			xpn2.getXpn7_NameTypeCode().setValue("L");
			
			Parser parser = new PipeParser();
			result.put("request", parser.encode(adt));
			result.put("msh", msh);
	        return result;
		} catch (DataTypeException e) {
			e.printStackTrace();
		} catch (HL7Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}


	/**
	 * Audit Logging of PIX Feed message.
	 * 
	 * @param hl7Header the header message from the source application
	 * @param patient the patient to create, update or merged
	 * @param eventActionCode the {@link EventActionCode}
	 */
	private void auditLog(MSH hl7Header, org.openhealthexchange.openpixpdq.data.Patient patient, AuditCodeMappings.EventActionCode eventActionCode) {
		IheAuditTrail auditTrail=getIheAuditTrail();
		
		String userId = hl7Header.getMsh4_SendingFacility().getHd1_NamespaceID().getValue() + "|" +
						hl7Header.getMsh3_SendingApplication().getHd1_NamespaceID().getValue();
		String messageId = hl7Header.getMsh10_MessageControlID().getValue();
		//TODO: Get the ip address of the source application
		String sourceIp = "127.0.0.1";

		ActiveParticipant source = new ActiveParticipant(userId, messageId, sourceIp);
		
		ParticipantObject patientObj = new ParticipantObject(patient);
		patientObj.setDetail(messageId);
		
		auditTrail.logPixFeed(source, patientObj, eventActionCode);		
	}
}
