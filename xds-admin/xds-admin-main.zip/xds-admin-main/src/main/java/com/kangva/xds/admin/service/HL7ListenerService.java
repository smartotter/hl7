package com.kangva.xds.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.registry.mapper.HL7ListenerMapper;
import com.kangva.xds.registry.model.HL7Listener;

@Service
public class HL7ListenerService {
	@Autowired
	private HL7ListenerMapper hl7ListenerMapper;
	
	public List<HL7Listener> getAll(){
		return hl7ListenerMapper.getAll();
	}

	public DataTable<HL7Listener> search(Map<String, String> parameters, DataTableParameter dataTableParameter) {
		PageBounds pageBounds = dataTableParameter.toPageBounds();
		PageList<HL7Listener> pageList = hl7ListenerMapper.search(parameters,pageBounds);
		DataTable<HL7Listener> result = new DataTable<>();
		result.setData(pageList);
		int totalRecords = pageList.getPaginator().getTotalCount();
		result.setRecordsTotal(totalRecords);
		result.setRecordsFiltered(totalRecords);
		return result;
	}

	public HL7Listener get(int id) {
		return hl7ListenerMapper.get(id);
	}

	public int delete(int id) {
		return hl7ListenerMapper.delete(id);
	}

	public boolean saveOrEdit(HL7Listener hl7Listener) {
		if(hl7Listener.getId() == null){
			hl7ListenerMapper.insert(hl7Listener);
			if(hl7Listener.getId() != null){
				return true;
			}
		}else{
			int result = hl7ListenerMapper.edit(hl7Listener);
			if(result > 0){
				return true;
			}
		}
		return false;
	}
}
