package com.kangva.xds.admin.dto;

public class DocumentEntryMetadataDto {

	private String id;
	private String status;
	private String mimeType;
	private String creationTime;
	private String serviceStartTime;
	private String serviceStopTime;
	private String uniqueId;
	private String repositoryUniqueId;
	private String classCode;
	private String formatCode;
	private String healthCareFacilityTypeCode;
	private String practiceSettingCode;
	private String typeCode;
	private String patientName;
	private String patientId;
	private String patientDob;
	private String patientSex;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getServiceStartTime() {
		return serviceStartTime;
	}
	public void setServiceStartTime(String serviceStartTime) {
		this.serviceStartTime = serviceStartTime;
	}
	public String getServiceStopTime() {
		return serviceStopTime;
	}
	public void setServiceStopTime(String serviceStopTime) {
		this.serviceStopTime = serviceStopTime;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getClassCode() {
		return classCode;
	}
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}
	public String getFormatCode() {
		return formatCode;
	}
	public void setFormatCode(String formatCode) {
		this.formatCode = formatCode;
	}
	public String getHealthCareFacilityTypeCode() {
		return healthCareFacilityTypeCode;
	}
	public void setHealthCareFacilityTypeCode(String healthCareFacilityTypeCode) {
		this.healthCareFacilityTypeCode = healthCareFacilityTypeCode;
	}
	public String getPracticeSettingCode() {
		return practiceSettingCode;
	}
	public void setPracticeSettingCode(String practiceSettingCode) {
		this.practiceSettingCode = practiceSettingCode;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientDob() {
		return patientDob;
	}
	public void setPatientDob(String patientDob) {
		this.patientDob = patientDob;
	}
	public String getPatientSex() {
		return patientSex;
	}
	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}
	public String getRepositoryUniqueId() {
		return repositoryUniqueId;
	}
	public void setRepositoryUniqueId(String repositoryUniqueId) {
		this.repositoryUniqueId = repositoryUniqueId;
	}
	
	
}
