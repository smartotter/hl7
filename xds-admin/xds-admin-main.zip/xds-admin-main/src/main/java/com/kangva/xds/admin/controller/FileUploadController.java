package com.kangva.xds.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.util.PathConstants;

 
 
/**
 * 
 * <p class="detail">
 * 功能：公共Action
 * </p>
 * 
 * @ClassName: BaseAction
 * @version V1.0
 * @date 2014年9月25日
 * @author wangsheng
 */
@Controller
public class FileUploadController {
	private static final Logger LOG = LoggerFactory
			.getLogger(FileUploadController.class.getName());

    
    private String allowSuffix = "jpg,png,gif,jpeg";//允许文件格式
    private long allowSize = 2L;//允许文件大小
    private String fileName;
    private String[] fileNames;
     
    public String getAllowSuffix() {
        return allowSuffix;
    }
 
    public void setAllowSuffix(String allowSuffix) {
        this.allowSuffix = allowSuffix;
    }
 
    public long getAllowSize() {
        return allowSize*1024*1024;
    }
 
    public void setAllowSize(long allowSize) {
        this.allowSize = allowSize;
    }
 
    public String getFileName() {
        return fileName;
    }
 
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
 
    public String[] getFileNames() {
        return fileNames;
    }
 
    public void setFileNames(String[] fileNames) {
        this.fileNames = fileNames;
    }

	@RequestMapping(value=PathConstants.PATH_UPLOAD, method=RequestMethod.POST)
	public @ResponseBody RestResponseWrapper upload(MultipartHttpServletRequest request,Model model) {
		try {
			Map<String, MultipartFile> maps = request.getFileMap();

			if(maps.size() < 1){
				return RestResponseWrapper.error("Upload empty file");
			}
			
			if(maps.size() > 1){
				return RestResponseWrapper.error("Only upload one file");
			}
			
			String finalSoredFilePath = null;
			for(String key:maps.keySet()){
				MultipartFile multipartFile = maps.get(key);
				checkUploadedFile(multipartFile);
				
				File rootDir = new File(System.getProperty("java.io.tmpdir"));
				
				String uploadedFileId = UUID.randomUUID().toString();
				File absolutePath = new File(rootDir,uploadedFileId);

				try {
					multipartFile.transferTo(absolutePath);
				} catch (IllegalStateException e) {
					LOG.error("store file exception:", e);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finalSoredFilePath = absolutePath.getAbsolutePath();
				break;
			}
			
			LOG.debug("Upload successfully");
			return RestResponseWrapper.ok(finalSoredFilePath);
		} catch (Exception e) {
			return RestResponseWrapper.error(e.getMessage());
		}
	}
	
	private void checkUploadedFile(MultipartFile multipartFile){
		
	}
}