package com.kangva.xds.admin.dto;

public class SubmissionSetDto {
	private String id;

	private String home;

	private String uniqueId;

	private String patientGlobalId;
	
	private String sourceId;

	private String submissionTime;
	
	private String insertedDateTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHome() {
		return home;
	}

	public void setHome(String home) {
		this.home = home;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getPatientGlobalId() {
		return patientGlobalId;
	}

	public void setPatientGlobalId(String patientGlobalId) {
		this.patientGlobalId = patientGlobalId;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getSubmissionTime() {
		return submissionTime;
	}

	public void setSubmissionTime(String submissionTime) {
		this.submissionTime = submissionTime;
	}

	public String getInsertedDateTime() {
		return insertedDateTime;
	}

	public void setInsertedDateTime(String insertedDateTime) {
		this.insertedDateTime = insertedDateTime;
	}

	
}
