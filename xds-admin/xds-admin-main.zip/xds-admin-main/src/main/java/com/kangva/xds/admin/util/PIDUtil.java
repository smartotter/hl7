package com.kangva.xds.admin.util;

import ca.uhn.hl7v2.model.v25.datatype.CX;
import ca.uhn.hl7v2.model.v25.datatype.XAD;
import ca.uhn.hl7v2.model.v25.datatype.XPN;
import ca.uhn.hl7v2.model.v25.segment.PID;

import com.kangva.xds.admin.dto.QueryPatientDto;
import com.kangva.xds.patient.model.Domain;
import com.kangva.xds.patient.model.Patient;

public class PIDUtil {
	public static QueryPatientDto extractPatient(CX cx, PID pid) {
		QueryPatientDto newQueryPatientDto = new QueryPatientDto();
		Patient newPatient = new Patient();
		newQueryPatientDto.setPatient(newPatient);
		Domain newDomain = new Domain();
		newQueryPatientDto.setDomain(newDomain);

		if (cx.getCx4_AssigningAuthority() != null) {
			if (cx.getCx4_AssigningAuthority().getHd1_NamespaceID() != null) {
				newDomain.setNamespaceId(cx.getCx4_AssigningAuthority()
						.getHd1_NamespaceID().getValue());
			}
			if (cx.getCx4_AssigningAuthority().getHd2_UniversalID() != null) {
				newDomain.setUniversalId(cx.getCx4_AssigningAuthority()
						.getHd2_UniversalID().getValue());
			}
			if (cx.getCx4_AssigningAuthority().getHd3_UniversalIDType() != null) {
				newDomain.setUniversalidType(cx.getCx4_AssigningAuthority()
						.getHd3_UniversalIDType().getValue());
			}
		}

		newPatient.setLocalId(cx.getCx1_IDNumber().getValue());
		if (pid.getPid5_PatientName() != null
				&& pid.getPid5_PatientName().length > 0) {
			XPN patientName = pid.getPid5_PatientName()[0];
			if (patientName.getFamilyName() != null
					&& patientName.getFamilyName().getFn1_Surname() != null) {
				newPatient.setFamilyName(patientName.getFamilyName()
						.getFn1_Surname().getValue());
			}
			if (patientName.getGivenName() != null) {
				newPatient.setGivenName(patientName.getGivenName().getValue());
			}
		}

		if (pid.getPid7_DateTimeOfBirth() != null) {
			newPatient.setBirthday(pid.getPid7_DateTimeOfBirth().getTs1_Time()
					.getValue());
		}
		if (pid.getPid8_AdministrativeSex() != null) {
			newPatient.setSex(pid.getPid8_AdministrativeSex().getValue());
		}
		XAD addr = pid.getPid11_PatientAddress(0);
		if (addr != null) {
			newPatient.setAddress(addr.getXad1_StreetAddress()
					.getSad1_StreetOrMailingAddress().getValue());
		}
		if(pid.getPid19_SSNNumberPatient() != null){
			newPatient.setSsn(pid.getPid19_SSNNumberPatient().getValue());
		}
		return newQueryPatientDto;
	}
}
