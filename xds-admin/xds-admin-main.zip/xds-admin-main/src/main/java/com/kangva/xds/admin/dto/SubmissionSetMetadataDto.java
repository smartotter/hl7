package com.kangva.xds.admin.dto;


public class SubmissionSetMetadataDto {

	private String id;
	private String homeCommunityId;
	private String status;
	private String submissionTime;
	private String patientId;
	private String sourceId;
	private String contentTypeCode;
	private String contentTypeCodeScheme;
	private String uniqueId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getHomeCommunityId() {
		return homeCommunityId;
	}

	public void setHomeCommunityId(String homeCommunityId) {
		this.homeCommunityId = homeCommunityId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubmissionTime() {
		return submissionTime;
	}

	public void setSubmissionTime(String submissionTime) {
		this.submissionTime = submissionTime;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getContentTypeCode() {
		return contentTypeCode;
	}

	public void setContentTypeCode(String contentTypeCode) {
		this.contentTypeCode = contentTypeCode;
	}

	public String getContentTypeCodeScheme() {
		return contentTypeCodeScheme;
	}

	public void setContentTypeCodeScheme(String contentTypeCodeScheme) {
		this.contentTypeCodeScheme = contentTypeCodeScheme;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

}
