package com.kangva.xds.admin.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import ca.uhn.hl7v2.llp.MinLLPReader;
import ca.uhn.hl7v2.llp.MinLLPWriter;

import com.kangva.xds.patient.model.PIXEndpoint;

public class SSLSocketUtil {   
	private static Log log=LogFactory.getLog(SSLSocketUtil.class); 
	public static String sendHL7Msg(PIXEndpoint pixEndpoint, String msg) throws Exception{
		SSLContext ctx;
		String receiveMsg=null;
		SSLSocket socket = null;
		try {
			ctx = SSLContext.getInstance("SSL");
			KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");    
	        TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");    

	        KeyStore ks = KeyStore.getInstance("JKS");    
	        KeyStore tks = KeyStore.getInstance("JKS");    

	        ks.load(new FileInputStream(pixEndpoint.getKeystorefilename()), pixEndpoint.getKeystorepassword().toCharArray());    
	        tks.load(new FileInputStream(pixEndpoint.getTrustkeystorefilename()), pixEndpoint.getTrustkeystorepassword().toCharArray());    

	        kmf.init(ks, pixEndpoint.getKeystorepassword().toCharArray());    
	        tmf.init(tks);    

	        ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

	        socket = (SSLSocket) ctx.getSocketFactory().createSocket(pixEndpoint.getHostname(), pixEndpoint.getPort());
	        System.setProperty("ca.uhn.hl7v2.llp.charset", "utf-8");
			MinLLPReader reader=new MinLLPReader(socket.getInputStream());
			MinLLPWriter writer=new MinLLPWriter(socket.getOutputStream());
			log.info("sending message:\n"+msg);
			writer.writeMessage(msg,"utf-8");
			receiveMsg=reader.getMessage();
			log.info("receiving message:\n" + receiveMsg);
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		   
        return receiveMsg;
	}
}
