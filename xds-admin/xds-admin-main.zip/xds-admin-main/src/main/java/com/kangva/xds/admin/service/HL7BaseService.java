package com.kangva.xds.admin.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openhealthexchange.openpixpdq.ihe.audit.IheAuditTrail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kangva.xds.admin.util.SSLSocketUtil;
import com.kangva.xds.admin.util.SocketUtil;
import com.kangva.xds.patient.model.PIXEndpoint;
import com.misyshealthcare.connect.net.ConnectionFactory;
import com.misyshealthcare.connect.util.LibraryConfig;
import com.misyshealthcare.connect.util.LibraryConfig.ILogContext;

public class HL7BaseService {
	static Logger logger = LoggerFactory.getLogger(HL7BaseService.class);

	protected static String HL7_VERSION = "2.5";

	protected Map<String, Object> sendMsg(PIXEndpoint pixEndpoint,
			String sentMsg) throws Exception {
		String receivedMsg;
		if (pixEndpoint.isSecure()) {
			receivedMsg = SSLSocketUtil.sendHL7Msg(pixEndpoint, sentMsg);
		} else {
			receivedMsg = SocketUtil.sendHL7Msg(pixEndpoint, sentMsg);
		}

		Map<String, Object> result = new HashMap<>();
		result.put("request", sentMsg);
		result.put("response", receivedMsg);
		logger.info("Request Msg:" + sentMsg);
		logger.info("Response Msg:" + receivedMsg);
		return result;
	}

	

	public class KangvaLogContext implements ILogContext {
		public String getUserId() {
			return "Kangva";
		}
		public String getClientAddress() {
			return "request ip";
		}
		public String getUserSystem() {
			return "Kangva-registry";
		}
		public String getUserName() {
			return "jdoe";
		}
	}
	
	protected IheAuditTrail getIheAuditTrail(){

		LibraryConfig.getInstance().setLogContext(new KangvaLogContext());
		String resourcePath = this.getClass().getResource("").getPath();
		logger.info("The audit connection path:"+resourcePath);
		try {
			resourcePath = java.net.URLDecoder.decode(resourcePath,"utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		resourcePath = resourcePath+"AuditRepositoryConnections.xml";
		logger.info("load the ATNA configuration from path:"+resourcePath);
		ConnectionFactory.loadConnectionDescriptionsFromFile(resourcePath);
		
    	ArrayList repositories = new ArrayList();
		repositories.add(ConnectionFactory
				.getConnectionDescription("log4j_audittrail"));

	   IheAuditTrail auditTrail=new IheAuditTrail("localaudit",repositories);
    
	   return auditTrail;
	}
}