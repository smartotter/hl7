package com.kangva.xds.admin.convert;

import org.openhealthtools.ihe.common.ebxml._3._0.rim.AssociationType1;

import com.kangva.xds.admin.dto.AssociationMetadataDto;

public class AssociationTypeConvertor {

	public static AssociationMetadataDto convert(
			AssociationType1 associationType1) {
		if(associationType1 == null){
			return null;
		}
		AssociationMetadataDto result = new AssociationMetadataDto();
		result.setAssociationType(associationType1.getAssociationType());
		result.setSourceObject(associationType1.getSourceObject());
		result.setTargetObject(associationType1.getTargetObject());
		return result;
	}

}
