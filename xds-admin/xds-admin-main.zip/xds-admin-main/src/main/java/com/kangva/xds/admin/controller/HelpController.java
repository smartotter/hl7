package com.kangva.xds.admin.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;

@Controller
@RequestMapping(PathConstants.PATH_HELP)
public class HelpController {
	private static Logger logger = LoggerFactory.getLogger(HelpController.class);

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */

	@RequestMapping(method = RequestMethod.GET)
	public String loginGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_HELP;
	}
}
