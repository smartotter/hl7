package com.kangva.xds.admin.mina;

import java.io.File;
import java.security.KeyStore;
import javax.net.ssl.SSLContext;
import org.apache.mina.filter.ssl.KeyStoreFactory;
import org.apache.mina.filter.ssl.SslContextFactory;

/**
 * @author giftsam
 */
public class SSLContextGenerator {
	private String keyStoreFileName;
	private String trustStoreFileName;
	private String keyStorePassword;
	private String trustStorePassword;
	
	
	public SSLContext getSslContext() {
		SSLContext sslContext = null;
		try {
			File keyStoreFile = new File(keyStoreFileName);
			File trustStoreFile = new File(trustStoreFileName);

			if (keyStoreFile.exists() && trustStoreFile.exists()) {
				final KeyStoreFactory keyStoreFactory = new KeyStoreFactory();
				System.out.println("Url is: " + keyStoreFile.getAbsolutePath());
				keyStoreFactory.setDataFile(keyStoreFile);
				keyStoreFactory.setPassword(keyStorePassword);

				final KeyStoreFactory trustStoreFactory = new KeyStoreFactory();
				trustStoreFactory.setDataFile(trustStoreFile);
				trustStoreFactory.setPassword(trustStorePassword);

				final SslContextFactory sslContextFactory = new SslContextFactory();
				final KeyStore keyStore = keyStoreFactory.newInstance();
				sslContextFactory.setKeyManagerFactoryKeyStore(keyStore);

				final KeyStore trustStore = trustStoreFactory.newInstance();
				sslContextFactory.setTrustManagerFactoryKeyStore(trustStore);
				sslContextFactory
						.setKeyManagerFactoryKeyStorePassword(trustStorePassword);
				sslContext = sslContextFactory.newInstance();
				System.out.println("SSL provider is: "
						+ sslContext.getProvider());
			} else {
				System.out
						.println("Keystore or Truststore file does not exist");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return sslContext;
	}



	public String getKeyStoreFileName() {
		return keyStoreFileName;
	}



	public void setKeyStoreFileName(String keyStoreFileName) {
		this.keyStoreFileName = keyStoreFileName;
	}



	public String getTrustStoreFileName() {
		return trustStoreFileName;
	}



	public void setTrustStoreFileName(String trustStoreFileName) {
		this.trustStoreFileName = trustStoreFileName;
	}



	public String getKeyStorePassword() {
		return keyStorePassword;
	}


	public void setKeyStorePassword(String keyStorePassword) {
		this.keyStorePassword = keyStorePassword;
	}


	public String getTrustStorePassword() {
		return trustStorePassword;
	}


	public void setTrustStorePassword(String trustStorePassword) {
		this.trustStorePassword = trustStorePassword;
	}
	
	
}
