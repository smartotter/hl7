package com.kangva.xds.admin.util;

public interface ViewConstants {

	/**
	 * The root path name
	 */
	String VIEW_ROOT = "xds-admin";
	/**
	 * The root path name
	 */
	String VIEW_ERROR = "error";
	/**
	 * The Login Get and Post Path
	 */
	String VIEW_INDEX = "index";
	
	/**
	 * The Login Get and Post Path
	 */
	String VIEW_LOGIN = "login";
	
	/**
	 * The Login Get and Post Path
	 */
	String VIEW_LOGOUT = "logout";

	/**
	 * The Login Get and Post Path
	 */
	String VIEW_SOURCE = "source";
	String VIEW_PATIENTI_IDENTITY_SOURCE = "patientIdentitySource";
	String VIEW_PIX = "pix";
	String VIEW_PDQ = "pdq";
	String VIEW_DISPLAY = "display";
	String VIEW_RID = "rid";
	String VIEW_FILE = "file";
	
	String VIEW_CONFIGURATION = "config";
	String VIEW_CONFIGURATION_SYSTEM = "system";
	String VIEW_REGISTRY_ENDPOINT = "registry-endpoint";
	String VIEW_REPOSITORY_ENDPOINT = "repository-endpoint";
	String VIEW_HL7_LISTENER = "hl7-listener";
	String VIEW_CT = "ct";
	String VIEW_CONSUMER = "consumer";
	String VIEW_REGISTRY = "registry";
	String VIEW_QUERY = "query";
	String VIEW_DOCUMENT = "documents";
	String VIEW_REPOSITORY = "repository";
	String VIEW_SUBMISSIONSET = "submits";
	String VIEW_HELP = "help";
	
	
	String VIEW_IHERETRIEVESUMMARYINFO = "IHERetrieveSummaryInfo";
	String VIEW_IHERETRIEVELISTINFO = "IHERetrieveListInfo";
	String VIEW_IHERETRIEVEDOCUMENT = "IHERetrieveDocument";
}
