package com.kangva.xds.admin.convert;

import com.kangva.xds.admin.dto.DocumentEntryDto;
import com.kangva.xds.registry.model.DocumentEntryIndex;

public class DocumentEntryIndexConvertor {

	public static DocumentEntryDto convert(DocumentEntryIndex documentEntryIndex){
		if(documentEntryIndex == null){
			return null;
		}
		DocumentEntryDto newDocumentEntryDto = new DocumentEntryDto();
		newDocumentEntryDto.setId(documentEntryIndex.getId());
		newDocumentEntryDto.setStatus(documentEntryIndex.getStatus());
		newDocumentEntryDto.setMimeType(documentEntryIndex.getMimeType());
		newDocumentEntryDto.setUniqueId(documentEntryIndex.getUniqueId());
		newDocumentEntryDto.setPatientGlobalId(documentEntryIndex.getPatientGlobalId());
		newDocumentEntryDto.setInsertedDateTime(documentEntryIndex.getInsertedDateTime());
		return newDocumentEntryDto;
	}
	
}
