package com.kangva.xds.admin.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.admin.convert.SubmissionSetConvertor;
import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.admin.dto.SubmissionSetDto;
import com.kangva.xds.repository.mapper.XDSSubmissionSetMapper;
import com.kangva.xds.repository.model.XDSSubmissionSet;

@Service
public class DisplayService {

	@Autowired
	private XDSSubmissionSetMapper submissionSetMapper;

	public DataTable<SubmissionSetDto> searchSubmissionSets(Map<String, String> parameters, DataTableParameter dataTableParameter) {
		PageBounds pageBounds = dataTableParameter.toPageBounds();
		PageList<XDSSubmissionSet> pageList = submissionSetMapper.searchSubmissionSets(parameters,pageBounds);
		List<SubmissionSetDto> submissionSetDtos = new ArrayList<>();
		for (XDSSubmissionSet submissionSet : pageList) {
			submissionSetDtos.add(SubmissionSetConvertor.convert(submissionSet));
		}
		DataTable<SubmissionSetDto> result = new DataTable<>();
		result.setData(submissionSetDtos);
		int totalRecords = pageList.getPaginator().getTotalCount();
		result.setRecordsTotal(totalRecords);
		result.setRecordsFiltered(totalRecords);
		return result;
	}
	
}
