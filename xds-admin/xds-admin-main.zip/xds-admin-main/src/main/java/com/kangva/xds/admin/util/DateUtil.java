package com.kangva.xds.admin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class DateUtil {
	public static final String DATE_FORMAT="yyyy-MM-dd";
	public static final String DATE_SHORT_FORMAT="yyyyMMdd";
	public static final String DATETIME_SHORT_FORMAT="yyyyMMddHHmmss";
	public static XMLGregorianCalendar convertToXMLGregorianCalendar(Date date) {

        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        XMLGregorianCalendar gc = null;
        try {
            gc = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
        } catch (Exception e) {

             e.printStackTrace();
        }
        return gc;
    }
 
     public static Date convertToDate(XMLGregorianCalendar cal) throws Exception{
         GregorianCalendar ca = cal.toGregorianCalendar();
         return ca.getTime();
     }
     
     public static String format(Date date,String format){
    	 SimpleDateFormat sdf = new SimpleDateFormat(format);
    	 return sdf.format(date);
     }
     
     public static Date parse(String dateText,String format) throws ParseException{
    	 SimpleDateFormat sdf = new SimpleDateFormat(format);
    	 return sdf.parse(dateText);
     }
}
