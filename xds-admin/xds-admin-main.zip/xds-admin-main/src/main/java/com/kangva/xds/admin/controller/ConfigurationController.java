package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.extract.DocumentRegistryExtractor;
import com.kangva.xds.admin.extract.DocumentRepositoryExtractor;
import com.kangva.xds.admin.extract.HL7ListenerExtractor;
import com.kangva.xds.admin.service.DocumentRegistryService;
import com.kangva.xds.admin.service.DocumentRepositoryService;
import com.kangva.xds.admin.service.HL7ListenerService;
import com.kangva.xds.admin.service.NTPClient;
import com.kangva.xds.admin.service.RepositoryApplicationConfigurationService;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;
import com.kangva.xds.registry.model.HL7Listener;
import com.kangva.xds.repository.model.DocumentRegistry;
import com.kangva.xds.repository.model.DocumentRepository;

@Controller
@RequestMapping(PathConstants.PATH_CONFIGURATION)
public class ConfigurationController {
	private static Logger logger = LoggerFactory.getLogger(ConfigurationController.class);


	@Autowired
	private RepositoryApplicationConfigurationService repositoryApplicationConfigurationService;

	@Autowired
	private DocumentRegistryService documentRegistryService;
	@Autowired
	private DocumentRepositoryService documentRepositoryService;
	@Autowired
	private HL7ListenerService hl7ListenerService;

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String ooGet(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		List<DocumentRegistry> documentRegistryEndpoints = documentRegistryService.getAll();
		model.put("documentRegistryEndpoints", documentRegistryEndpoints);
		List<DocumentRepository> documentRepositoryEndpoints = documentRepositoryService.getAll();
		model.put("documentRepositoryEndpoints", documentRepositoryEndpoints);
		return ViewConstants.VIEW_CONFIGURATION;
	}
	
	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_SYSTEM + "/{key}", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper getConfigurationValue(HttpServletRequest request, @PathVariable String key) throws IOException {
		logger.info("Get the system configuration page request!");
		if(StringUtils.isEmpty(key)){
			return RestResponseWrapper.error("Should input the key");
		}
		String value = repositoryApplicationConfigurationService.findByKey(key);
		
		return RestResponseWrapper.ok(value);
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_SYSTEM + "/{key}", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper postConfigurationValue(HttpServletRequest request, @PathVariable String key) throws IOException {
		logger.info("Get the system configuration page request!");
		if(StringUtils.isEmpty(key)){
			return RestResponseWrapper.error("Should input the key");
		}
		String value = request.getParameter("value");
		int result = repositoryApplicationConfigurationService.update(key,value);
		
		if(result > 0){
			return RestResponseWrapper.ok(value);
		}else{
			return RestResponseWrapper.error("Update Error");
		}
	}
	
	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REGISTRY_ENDPOINT, method = RequestMethod.GET)
	public @ResponseBody DataTable<DocumentRegistry> queryRegistryList(HttpServletRequest request){
		DataTableParameter dataTableParameter = DataTableParameter.extract(request);
		
		Map<String, String> parameters = new HashMap<>();
		parameters.put("registryName", StringUtils.trimToNull(request.getParameter("registryName")));
		
		DataTable<DocumentRegistry> result = documentRegistryService.search(parameters,dataTableParameter);
		result.setDraw(dataTableParameter.getDraw());
		return result;
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REGISTRY_ENDPOINT + "/{registryEndpointId}", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper getRegistryEndpoint(HttpServletRequest request, @PathVariable String registryEndpointId){
		int id = Integer.valueOf(registryEndpointId);
		DocumentRegistry documentRegistry= documentRegistryService.get(id);
		if(documentRegistry != null){
			return RestResponseWrapper.ok(documentRegistry);
		}else{
			return RestResponseWrapper.error("Can not find the endpoint");
		}
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REGISTRY_ENDPOINT + "/{registryEndpointId}", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper deleteRegistryEndpoint(HttpServletRequest request, @PathVariable String registryEndpointId){
		int id = Integer.valueOf(registryEndpointId);
		int result= documentRegistryService.delete(id);
		if(result > 0){
			return RestResponseWrapper.ok(null);
		}else{
			return RestResponseWrapper.error("Can not find the endpoint");
		}
	}
	
	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REGISTRY_ENDPOINT, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper editRegistryEndpoint(HttpServletRequest request){
		logger.info("Edit the registry endpoint");
		DocumentRegistry documentRegistry;
		try {
			documentRegistry = DocumentRegistryExtractor.extract(request);
			boolean result= documentRegistryService.saveOrEdit(documentRegistry);
			if(result){
				return RestResponseWrapper.ok(null);
			}
		} catch (Exception e) {
			return RestResponseWrapper.error("Can not find the endpoint");
		}
		return RestResponseWrapper.error("Can not find the endpoint");
	}
	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REPOSITORY_ENDPOINT, method = RequestMethod.GET)
	public @ResponseBody DataTable<DocumentRepository> queryRepositoryList(HttpServletRequest request){
		DataTableParameter dataTableParameter = DataTableParameter.extract(request);
		
		Map<String, String> parameters = new HashMap<>();
		parameters.put("repositoryName", StringUtils.trimToNull(request.getParameter("repositoryName")));
		
		DataTable<DocumentRepository> result = documentRepositoryService.search(parameters,dataTableParameter);
		result.setDraw(dataTableParameter.getDraw());
		return result;
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REPOSITORY_ENDPOINT + "/{repositoryEndpointId}", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper getRepositoryEndpoint(HttpServletRequest request, @PathVariable String repositoryEndpointId){
		int id = Integer.valueOf(repositoryEndpointId);
        DocumentRepository documentRepository= documentRepositoryService.get(id);
		if(documentRepository != null){
			return RestResponseWrapper.ok(documentRepository);
		}else{
			return RestResponseWrapper.error("Can not find the endpoint");
		}
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REPOSITORY_ENDPOINT + "/{repositoryEndpointId}", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper deleteRepositoryEndpoint(HttpServletRequest request, @PathVariable String repositoryEndpointId){
		int id = Integer.valueOf(repositoryEndpointId);
		int result= documentRepositoryService.delete(id);
		if(result > 0){
			return RestResponseWrapper.ok(null);
		}else{
			return RestResponseWrapper.error("Can not find the endpoint");
		}
	}
	
	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_REPOSITORY_ENDPOINT, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper editRepositoryEndpoint(HttpServletRequest request){
		logger.info("Edit the repsoitory endpoint");
		DocumentRepository documentRepository;
		try {
			documentRepository = DocumentRepositoryExtractor.extract(request);
			boolean result= documentRepositoryService.saveOrEdit(documentRepository);
			if(result){
				return RestResponseWrapper.ok(null);
			}
		} catch (Exception e) {
			return RestResponseWrapper.error("Can not find the endpoint");
		}
		return RestResponseWrapper.error("Can not find the endpoint");
	}
	

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_HL7_LISTENER, method = RequestMethod.GET)
	public @ResponseBody DataTable<HL7Listener> queryHl7ListenerList(HttpServletRequest request){
		DataTableParameter dataTableParameter = DataTableParameter.extract(request);
		
		Map<String, String> parameters = new HashMap<>();
		parameters.put("displayName", StringUtils.trimToNull(request.getParameter("displayName")));
		
		DataTable<HL7Listener> result = hl7ListenerService.search(parameters,dataTableParameter);
		result.setDraw(dataTableParameter.getDraw());
		return result;
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_HL7_LISTENER + "/{hl7ListenerId}", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper getHl7Listener(HttpServletRequest request, @PathVariable String hl7ListenerId){
		int id = Integer.valueOf(hl7ListenerId);
		HL7Listener hl7Listener= hl7ListenerService.get(id);
		if(hl7Listener != null){
			return RestResponseWrapper.ok(hl7Listener);
		}else{
			return RestResponseWrapper.error("Can not find the endpoint");
		}
	}

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_HL7_LISTENER + "/{hl7ListenerId}", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper deleteHl7Listenert(HttpServletRequest request, @PathVariable String hl7ListenerId){
		int id = Integer.valueOf(hl7ListenerId);
		int result= hl7ListenerService.delete(id);
		if(result > 0){
			return RestResponseWrapper.ok(null);
		}else{
			return RestResponseWrapper.error("Can not find the endpoint");
		}
	}
	
	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_HL7_LISTENER, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper editHl7Listener(HttpServletRequest request){
		logger.info("Edit the repsoitory endpoint");
		HL7Listener hl7Listener;
		try {
			hl7Listener = HL7ListenerExtractor.extract(request);
			boolean result= hl7ListenerService.saveOrEdit(hl7Listener);
			if(result){
				return RestResponseWrapper.ok(null);
			}
		} catch (Exception e) {
			return RestResponseWrapper.error("Can not find the endpoint");
		}
		return RestResponseWrapper.error("Can not find the endpoint");
	}
	

	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_CT + "/{ctServer:.+}", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper getTime(HttpServletRequest request, @PathVariable String ctServer){
		logger.info("To query the time from CT server:"+ctServer);
		
		if(StringUtils.isEmpty(ctServer)){
			return RestResponseWrapper.error("Input empty CT server");
		}
		try {
			NTPClient nptc = new NTPClient();
			Date date = nptc.processResponse(ctServer); 
			if (date != null) {

				Map<String, String> result = new HashMap<>();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				result.put("serverTime", sdf.format(date));
				result.put("systemTime", sdf.format(new Date()));
				
				return RestResponseWrapper.ok(result);
			}else{
				return RestResponseWrapper.error("Can not get time from "+ ctServer);
			}
		} catch (Exception e) {
			return RestResponseWrapper.error(e.getMessage());
		}
	}


	@RequestMapping(value = PathConstants.PATH_CONFIGURATION_CT + "/{ctServer:.+}", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper setTime(HttpServletRequest request, @PathVariable String ctServer){
		logger.info("To set the time from CT server:"+ctServer);
		if(StringUtils.isEmpty(ctServer)){
			return RestResponseWrapper.error("Input empty CT server");
		}
		try {
			NTPClient nptc = new NTPClient();
			Date date = nptc.processResponse(ctServer); 
			if (date != null) {

				Map<String, String> result = new HashMap<>();
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				result.put("serverTime", sdf1.format(date));
				result.put("systemTime", sdf1.format(new Date()));
				try {
					String name = System.getProperty("os.name");
					logger.info(name);
					String cmd = null;
					SimpleDateFormat sdf = null;
					if (name.contains("Windows")) { // Window 操作系统
						sdf = new SimpleDateFormat("hh:mm:ss");
						cmd = " cmd /c time " + sdf.format(date);
						logger.info(cmd);
						Runtime.getRuntime().exec(cmd); // 修改时间
						sdf = new SimpleDateFormat("yyyy-MM-dd");
						cmd = " cmd /c date " + sdf.format(date);
						logger.info(cmd);
						Runtime.getRuntime().exec(cmd); // 修改日期
					}
					return RestResponseWrapper.ok(result);
				} catch (Exception e) {
					e.printStackTrace();
					return RestResponseWrapper.error(e.getMessage());
				}
				
			}else{
				return RestResponseWrapper.error("Can not get time from "+ ctServer);
			}
		} catch (Exception e) {
			return RestResponseWrapper.error(e.getMessage());
		}
	}
	
}
