package com.kangva.xds.patient.model;

public class Domain {
	private long id;

	private String namespaceId;
	private String universalId;
	private String universalidType;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNamespaceId() {
		return namespaceId;
	}

	public void setNamespaceId(String namespaceId) {
		this.namespaceId = namespaceId;
	}

	public String getUniversalId() {
		return universalId;
	}

	public void setUniversalId(String universalId) {
		this.universalId = universalId;
	}

	public String getUniversalidType() {
		return universalidType;
	}

	public void setUniversalidType(String universalidType) {
		this.universalidType = universalidType;
	}

}
