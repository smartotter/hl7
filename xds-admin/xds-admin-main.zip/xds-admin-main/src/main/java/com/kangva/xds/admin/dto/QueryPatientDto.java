package com.kangva.xds.admin.dto;

import com.kangva.xds.patient.model.Domain;

import com.kangva.xds.patient.model.Patient;

public class QueryPatientDto {
	private Domain domain;
	private Patient patient;

	public Domain getDomain() {
		return domain;
	}

	public void setDomain(Domain domain) {
		this.domain = domain;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

}
