package com.kangva.xds.patient.mapper;

import java.util.List;
import java.util.Map;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.patient.model.Patient;

public interface PatientMapper {

	PageList<Patient> search(Map<String, String> parameters,
			PageBounds pageBounds);

	Patient get(long id);

	int delete(long id);

	int insert(Patient patient);

	int edit(Patient patient);

	List<Patient> getAll();

	Patient findByLocalId(String localId);

}
