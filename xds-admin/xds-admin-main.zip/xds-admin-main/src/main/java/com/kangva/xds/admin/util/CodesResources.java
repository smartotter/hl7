package com.kangva.xds.admin.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kangva.xds.admin.dto.CodedMetadataTypeDto;

public class CodesResources {
	private static Logger logger = LoggerFactory.getLogger(CodesResources.class);

	public static Map<String, CodedMetadataTypeDto> contentTypeCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> classCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> confidentialityCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> formatCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> healthcareFacilityTypeCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> practiceSettingCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> eventCodeLists = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> typeCodes = new HashMap<>();
	public static Map<String, CodedMetadataTypeDto> folderCodeLists = new HashMap<>();

   static {
		String resourcePath = CodesResources.class.getResource("/").getPath();
		resourcePath = resourcePath + "/codes.xml";
		logger.info("Load the codes from file:{}", resourcePath);

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new FileInputStream(new File(resourcePath)));
			Element element = document.getDocumentElement();
			NodeList codeTypeNodes = element.getElementsByTagName("CodeType");

			for (int i = 0; i < codeTypeNodes.getLength(); i++) {
				Element codeTypeElement = (Element) codeTypeNodes.item(i);
				String codeType = codeTypeElement.getAttribute("name");
				NodeList childNodes = codeTypeElement.getChildNodes();
				String classScheme = codeTypeElement.getAttribute("classScheme");

				if (StringUtils.equals(codeType, "mimeType")) {
					continue;
				}
				for (int j = 0; j < childNodes.getLength(); j++) {
					if(childNodes.item(j) instanceof Element){
						Element codeElement = (Element) childNodes.item(j);

						String code = codeElement.getAttribute("code");
						CodedMetadataTypeDto CodedMetadataTypeDto = createCodedMetadataTypeDto(code,
								codeElement.getAttribute("codingScheme"), classScheme, codeElement.getAttribute("display"));

						switch (codeType)
						{
						case "contentTypeCode":
							contentTypeCodes.put(code, CodedMetadataTypeDto);
							break;
						case "classCode":
							classCodes.put(code, CodedMetadataTypeDto);
							break;

						case "confidentialityCode":
							confidentialityCodes.put(code, CodedMetadataTypeDto);
							break;

						case "formatCode":
							formatCodes.put(code, CodedMetadataTypeDto);
							break;

						case "healthcareFacilityTypeCode":
							healthcareFacilityTypeCodes.put(code, CodedMetadataTypeDto);
							break;

						case "practiceSettingCode":
							practiceSettingCodes.put(code, CodedMetadataTypeDto);
							break;


						case "eventCodeList":
							eventCodeLists.put(code, CodedMetadataTypeDto);
							break;

						case "typeCode":
							typeCodes.put(code, CodedMetadataTypeDto);
							break;

						case "folderCodeList":
							folderCodeLists.put(code, CodedMetadataTypeDto);
							break;
						
						}
					}
					
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	private static CodedMetadataTypeDto createCodedMetadataTypeDto(String code, String schemeName, String schemeUUID,
			String displayName) {
		if (StringUtils.isEmpty(code)) {
			return null;
		}
		CodedMetadataTypeDto codedMetadataTypeDto = new CodedMetadataTypeDto();
		codedMetadataTypeDto.setCode(StringUtils.trimToNull(code));
		codedMetadataTypeDto.setSchemeName(StringUtils.trimToNull(schemeName));
		codedMetadataTypeDto.setSchemeUUID(StringUtils.trimToNull(schemeUUID));
		codedMetadataTypeDto.setDisplayName(StringUtils.trimToNull(displayName));

		return codedMetadataTypeDto;
	}

}
