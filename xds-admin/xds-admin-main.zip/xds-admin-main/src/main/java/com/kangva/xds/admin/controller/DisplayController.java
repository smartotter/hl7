package com.kangva.xds.admin.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;

@Controller
@RequestMapping(PathConstants.PATH_DISPLAY)
public class DisplayController {
	private static Logger logger = LoggerFactory
			.getLogger(DisplayController.class);

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String doGet(HttpServletRequest request,
			HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the error page request!");
		return ViewConstants.VIEW_DISPLAY;
	}

	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPost(HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		String patientId = request.getParameter("patientId");
		String assigningAuthority = request.getParameter("assigningAuthority");
		logger.info(
				"Get the display page request! patientId:{}, assigningAuthority:{}",
				patientId, assigningAuthority);

		Map<String, String> result = new HashMap<>();
		return RestResponseWrapper.ok(result);
	}

	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVELISTINFO, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPostIHERetrieveListInfo(
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		String ridIHERetrieveListInfoAddress = request
				.getParameter("ridIHERetrieveListInfoAddress");
		String requestType = request.getParameter("requestType");
		String patientID = request.getParameter("patientID");
		String assigningAuthority = request.getParameter("assigningAuthority");
		logger.info(
				"Get the display page request! ridIHERetrieveListInfoAddress:{}, requestType:{}, assigningAuthority:{}",ridIHERetrieveListInfoAddress, requestType,
				assigningAuthority);

		if(!StringUtils.isEmpty(assigningAuthority)){
			patientID = patientID + "^^^" + assigningAuthority;
		}
		
		String requestURL = ridIHERetrieveListInfoAddress + "?requestType="+URLEncoder.encode(requestType,"utf-8")+"&patientID="+URLEncoder.encode(patientID,"utf-8");
		
		
		HttpClient httpClient = null;
		try {
			// 创建HttpClient对象
			httpClient = new HttpClient();
			// HttpClient
			GetMethod getMethod = new GetMethod(requestURL);
			httpClient.executeMethod(getMethod);
			// 发送请求获得返回结果
			// 如果成功
			if (getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				Map<String, String> result = new HashMap<>();
				result.put("request", requestURL);
				return RestResponseWrapper.ok(result);
			}else if(getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_NOT_FOUND){
				return RestResponseWrapper.error("404:Not found Info");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Map<String, String> result = new HashMap<>();
			result.put("request", requestURL);
			return RestResponseWrapper.error(e.getMessage());
		} 
		return RestResponseWrapper.error(null);
	}

	@RequestMapping(value = PathConstants.PATH_IHERETRIEVESUMMARYINFO, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPostIHERetrieveSummaryInfo(
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		String ridIHERetrieveSummaryInfoAddress = request
				.getParameter("ridIHERetrieveSummaryInfoAddress");
		String patientID = request.getParameter("patientID");
		String assigningAuthority = request.getParameter("assigningAuthority");
		String lowerDateTime = request.getParameter("lowerDateTime");
		String upperDateTime = request.getParameter("upperDateTime");
		String mostRecentResults = request.getParameter("mostRecentResults");
		logger.info(
				"Get the display page request! ridIHERetrieveSummaryInfoAddress:{}, patientID:{}, assigningAuthority:{}",ridIHERetrieveSummaryInfoAddress, patientID,
				assigningAuthority);

		if(!StringUtils.isEmpty(assigningAuthority)){
			patientID = patientID + "^^^" + assigningAuthority;
		}
		String requestURL = ridIHERetrieveSummaryInfoAddress + "?requestType=SUMMARY&patientID="+URLEncoder.encode(patientID,"utf-8");
		
		if(!StringUtils.isEmpty(upperDateTime)){
			requestURL = requestURL +"&lowerDateTime="+lowerDateTime;
		}
		if(!StringUtils.isEmpty(upperDateTime)){
			requestURL = requestURL +"&upperDateTime="+upperDateTime+"&mostRecentResults="+mostRecentResults;
		}
		if(!StringUtils.isEmpty(mostRecentResults)){
			requestURL = requestURL + "&mostRecentResults="+mostRecentResults;
		}
		
		HttpClient httpClient = null;
		try {
			// 创建HttpClient对象
			httpClient = new HttpClient();
			// HttpClient
			GetMethod getMethod = new GetMethod(requestURL);
			httpClient.executeMethod(getMethod);
			// 发送请求获得返回结果
			// 如果成功
			if (getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				Map<String, String> result = new HashMap<>();
				result.put("request", requestURL);
				return RestResponseWrapper.ok(result);
			}else if(getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_NOT_FOUND){
				return RestResponseWrapper.error("404:Not found Info");
			}
		} catch (IOException e) {
			e.printStackTrace();
			Map<String, String> result = new HashMap<>();
			result.put("request", requestURL);
			return RestResponseWrapper.error(e.getMessage());
		} 
		return RestResponseWrapper.error(null);
	}

	@RequestMapping(value = PathConstants.VIEW_IHERETRIEVEDOCUMENT, method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper doPostIHERetrieveDocument(
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		String ridIHERetrieveDocumentAddress = request
				.getParameter("ridIHERetrieveDocumentAddress");
		String documentUID = request.getParameter("documentUID");
		String preferredContentType = request
				.getParameter("preferredContentType");
		logger.info(
				"Get the display page request! ridIHERetrieveDocumentAddress:{}, documentUID:{}, preferredContentType:{}",
				ridIHERetrieveDocumentAddress, documentUID,
				preferredContentType);

		File rootDir = new File(System.getProperty("java.io.tmpdir"));

		String uploadedFileId = UUID.randomUUID().toString();
		File absolutePath = new File(rootDir, uploadedFileId);
		String params = "requestType=DOCUMENT&documentUID=" + documentUID
				+ "&preferredContentType=" + preferredContentType;
		downloadFile(absolutePath, ridIHERetrieveDocumentAddress, params);
		Map<String, String> result = new HashMap<>();
		result.put("fileName", uploadedFileId);
		return RestResponseWrapper.ok(result);
	}

	public static void downloadFile(File absolutePath, String url, String params)
			throws IOException {
		logger.debug("path:" + absolutePath.getAbsolutePath());
		logger.debug("url:" + url);
		HttpClient httpClient = null;
		try {
			// 创建HttpClient对象
			httpClient = new HttpClient();
			// HttpClient
			GetMethod getMethod = new GetMethod(url + "?" + params);
			getMethod.setRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
			httpClient.executeMethod(getMethod);
			// 发送请求获得返回结果
			// 如果成功
			if (getMethod.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				InputStream inputStream = getMethod.getResponseBodyAsStream();
				FileUtils.copyInputStreamToFile(inputStream, absolutePath);
			}	// 如果失败
			else {
				StringBuffer errorMsg = new StringBuffer();
				errorMsg.append("httpStatus:");
				errorMsg.append(getMethod.getStatusLine().getStatusCode());
				errorMsg.append(getMethod.getStatusLine().getReasonPhrase());
				errorMsg.append(", Header: ");
				Header[] headers = getMethod.getResponseHeaders();
				for (Header header : headers) {
					errorMsg.append(header.getName());
					errorMsg.append(":");
					errorMsg.append(header.getValue());
				}
				logger.error("HttpResonse Error:" + errorMsg);
			}
		} catch (IOException e) {
			logger.error("下载文件保存到本地,文件操作异常,path=" + absolutePath + ",url="
					+ url, e);
			throw e;
		} finally {

		}
	}
	
	public static void main(String[] args) throws IOException{

		File rootDir = new File(System.getProperty("java.io.tmpdir"));

		String uploadedFileId = UUID.randomUUID().toString();
		File absolutePath = new File(rootDir, uploadedFileId);
		String params = "requestType=DOCUMENT&documentUID=" + "1.2.840.113654.2.3.2003.100.103"
				+ "&preferredContentType=" + "image/jpeg";
		downloadFile(absolutePath, "http://192.168.1.11/rid/IHERetrieveDocument", params);
	}

}
