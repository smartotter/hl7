package com.kangva.xds.admin.dto;

import javax.servlet.http.HttpServletRequest;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;

public class DataTableParameter {

	private int draw;
	private int start;
	private int length;
	
	public int getDraw() {
		return draw;
	}
	public void setDraw(int draw) {
		this.draw = draw;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	
	public static DataTableParameter extract(HttpServletRequest request){
		DataTableParameter newDataTableParameter = new DataTableParameter();
		String drawStr = request.getParameter("draw");
		if(drawStr != null){
			newDataTableParameter.setDraw(Integer.valueOf(drawStr));
		}
		String startStr = request.getParameter("start");
		if(startStr != null){
			newDataTableParameter.setStart(Integer.valueOf(startStr));
		}
		String lengthStr = request.getParameter("length");
		if(lengthStr != null){
			newDataTableParameter.setLength(Integer.valueOf(lengthStr));
		}
		return newDataTableParameter;
	}
	
	public PageBounds toPageBounds(){
		return new PageBounds(start/length+1 ,length);
	}
}