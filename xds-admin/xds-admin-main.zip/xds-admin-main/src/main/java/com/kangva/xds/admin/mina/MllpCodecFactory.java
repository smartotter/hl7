package com.kangva.xds.admin.mina;

import java.nio.charset.Charset;

import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

public class MllpCodecFactory implements ProtocolCodecFactory{
	public MllpCodecFactory (){
//        super.addMessageDecoder(MllpDecoder.class);
    }

	@Override
	public ProtocolDecoder getDecoder(IoSession iosession) throws Exception {
		return new MllpDecoder(Charset.forName("utf-8"));
	}

	@Override
	public ProtocolEncoder getEncoder(IoSession iosession) throws Exception {
		return new MllpEncoder();
	}
}
