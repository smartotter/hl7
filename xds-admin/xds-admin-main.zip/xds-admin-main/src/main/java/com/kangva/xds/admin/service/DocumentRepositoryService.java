package com.kangva.xds.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.repository.mapper.DocumentRepositoryMapper;
import com.kangva.xds.repository.model.DocumentRepository;

@Service
public class DocumentRepositoryService {
	@Autowired
	private DocumentRepositoryMapper documentRepositoryMapper;
	
	public List<DocumentRepository> getAll(){
		return documentRepositoryMapper.getAll();
	}

	public DataTable<DocumentRepository> search(Map<String, String> parameters, DataTableParameter dataTableParameter) {
		PageBounds pageBounds = dataTableParameter.toPageBounds();
		PageList<DocumentRepository> pageList = documentRepositoryMapper.search(parameters,pageBounds);
		DataTable<DocumentRepository> result = new DataTable<>();
		result.setData(pageList);
		int totalRecords = pageList.getPaginator().getTotalCount();
		result.setRecordsTotal(totalRecords);
		result.setRecordsFiltered(totalRecords);
		return result;
	}

	public DocumentRepository get(int id) {
		return documentRepositoryMapper.get(id);
	}

	public int delete(int id) {
		return documentRepositoryMapper.delete(id);
	}

	public boolean saveOrEdit(DocumentRepository documentRepository) {
		if(documentRepository.getId() == null){
			documentRepositoryMapper.insert(documentRepository);
			if(documentRepository.getId() != null){
				return true;
			}
		}else{
			int result = documentRepositoryMapper.edit(documentRepository);
			if(result > 0){
				return true;
			}
		}
		return false;
	}
}
