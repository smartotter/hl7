package com.kangva.xds.repository.mapper;

import java.util.List;
import java.util.Map;

import com.github.miemiedev.mybatis.paginator.domain.PageBounds;
import com.github.miemiedev.mybatis.paginator.domain.PageList;
import com.kangva.xds.repository.model.DocumentRepository;

public interface DocumentRepositoryMapper {
	DocumentRepository get(int id);
	List<DocumentRepository> getAll();
	void update(DocumentRepository documentRepository);
	void insert(DocumentRepository documentRepository);
	PageList<DocumentRepository> search(Map<String, String> parameters, PageBounds pageBounds);
	int delete(int id);
	int edit(DocumentRepository documentRepository);
	DocumentRepository findByUniqueId(String repositoryUniqueId);
}
