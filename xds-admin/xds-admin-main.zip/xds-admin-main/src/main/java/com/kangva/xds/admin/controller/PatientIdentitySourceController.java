package com.kangva.xds.admin.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kangva.xds.admin.dto.DataTable;
import com.kangva.xds.admin.dto.DataTableParameter;
import com.kangva.xds.admin.dto.RestResponseWrapper;
import com.kangva.xds.admin.service.PIXEndpointService;
import com.kangva.xds.admin.service.PatientIdentityFeedService;
import com.kangva.xds.admin.service.PatientService;
import com.kangva.xds.admin.service.RepositoryApplicationConfigurationService;
import com.kangva.xds.admin.util.PathConstants;
import com.kangva.xds.admin.util.ViewConstants;
import com.kangva.xds.patient.model.PIXEndpoint;
import com.kangva.xds.patient.model.Patient;

@Controller
@RequestMapping(PathConstants.PATH_PATIENTI_IDENTITY_SOURCE)
public class PatientIdentitySourceController {
	private static Logger logger = LoggerFactory.getLogger(PatientIdentitySourceController.class);

	@Autowired
	private RepositoryApplicationConfigurationService repositoryApplicationConfigurationService;

	@Autowired
	private PatientService patientService;
	
	@Autowired
	private PIXEndpointService pixEndpointService;
	
	@Autowired
	private PatientIdentityFeedService patientIdentityFeedService;

	/**
	 * Renders the home page as HTML in thw web browser. The home page is
	 * different based on whether the user is signed in or not.
	 * 
	 * @throws IOException
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String doGet(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws IOException {
		logger.info("Get the patient page request!");

		List<PIXEndpoint> pixEndpoints = pixEndpointService.getAll();
		model.put("pixEndpoints", pixEndpoints);
		return ViewConstants.VIEW_PATIENTI_IDENTITY_SOURCE;
	}

	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper doGetPatient(HttpServletRequest request, HttpServletResponse response, ModelMap model,@PathVariable long id) throws IOException {
		logger.info("Get the patient page request!");
		Patient patient = patientService.get(id);
		if(patient != null){
			Map<String,Patient> result = new HashMap<>();
			result.put("patient", patient);
			return RestResponseWrapper.ok(result); 
		}else{
			return RestResponseWrapper.error("Can not found the patient");
		}
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public @ResponseBody DataTable<Patient> search(HttpServletRequest request){
		DataTableParameter dataTableParameter = DataTableParameter.extract(request);

		Map<String, String> parameters = new HashMap<>();
		parameters.put("patientGlobalId", StringUtils.trimToNull(request.getParameter("patientGlobalId")));
		parameters.put("patientLocalId", StringUtils.trimToNull(request.getParameter("patientLocalId")));
		parameters.put("patientGivenName", StringUtils.trimToNull(request.getParameter("patientGivenName")));
		parameters.put("patientFamilyName", StringUtils.trimToNull(request.getParameter("patientFamilyName")));
		
		DataTable<Patient> result = patientService.search(parameters,dataTableParameter);
		result.setDraw(dataTableParameter.getDraw());
		return result;
	}

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public @ResponseBody RestResponseWrapper getAll(HttpServletRequest request){
		List<Patient> patients= patientService.getAll();
		return RestResponseWrapper.ok(patients);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper savePatient(HttpServletRequest request, @ModelAttribute Patient patient){
		boolean result = patientService.saveOrUpdate(patient);
		if(result){
			return RestResponseWrapper.ok(null);
		}else{
			return RestResponseWrapper.error(null);
		}
	}
	
	@RequestMapping(value = "/feed", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper patientIdentityFeed(HttpServletRequest request){
		String patientId = request.getParameter("patientId");
		String pixAddressId = request.getParameter("pixAddressId");
		String messageType = request.getParameter("messageType");
		
		return patientIdentityFeedService.feed(Long.valueOf(patientId), Long.valueOf(pixAddressId),messageType);
	}

	@RequestMapping(value = "/merge", method = RequestMethod.POST)
	public @ResponseBody RestResponseWrapper patientIdentityMerge(HttpServletRequest request){
		String oldPatientId = request.getParameter("oldPatientId");
		String pixAddressId = request.getParameter("pixAddressId");
		String newPatientId = request.getParameter("newPatientId");
		
		if(StringUtils.isEmpty(oldPatientId) || StringUtils.isEmpty(newPatientId) || StringUtils.isEmpty(pixAddressId)){
			return RestResponseWrapper.error("Should provide all parameters");
		}
		return patientIdentityFeedService.merge(Long.valueOf(oldPatientId), Long.valueOf(newPatientId),Long.valueOf(pixAddressId));
	}
	
}
