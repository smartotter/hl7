package com.kangva.xds.admin.service;

import java.net.URI;

import org.openhealthtools.ihe.atna.auditor.XDSSourceAuditor;
import org.openhealthtools.ihe.atna.auditor.context.AuditorModuleContext;
import org.openhealthtools.ihe.xds.response.XDSResponseType;
import org.openhealthtools.ihe.xds.source.B_Source;
import org.openhealthtools.ihe.xds.source.SubmitTransactionData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kangva.xds.repository.mapper.DocumentRepositoryMapper;
import com.kangva.xds.repository.model.DocumentRepository;

@Service
public class ProvideAndRegisterDocumentSetService {
	private static Logger logger = LoggerFactory.getLogger(ProvideAndRegisterDocumentSetService.class);

	@Autowired
	private DocumentRepositoryMapper documentRepositoryMapper;

	public XDSResponseType submit(boolean useAsync, SubmitTransactionData submitTransactionData, int repositoryAddressId) throws Exception{
		DocumentRepository documentRepository = documentRepositoryMapper.get(repositoryAddressId);
		if (documentRepository == null) {
			throw new Exception("Provde wrong Repository Address!");
		}

		if (documentRepository.isSecure()) {
			// serviceClient.engageModule("addressing");
			System.setProperty("javax.net.ssl.keyStore", documentRepository.getKeyStoreFileName());
			System.setProperty("javax.net.ssl.keyStorePassword", documentRepository.getKeyStorePassword());
			// System.setProperty("javax.net.ssl.trustStore",
			// "conf/mayotruststore.jks");
			System.setProperty("javax.net.ssl.trustStore", documentRepository.getTrustKeyStoreFileName());
			System.setProperty("javax.net.ssl.trustStorePassword", documentRepository.getTrustKeyStorePassword());

			System.setProperty("javax.net.debug", "sslhandshake");
		}

		B_Source source = new B_Source(new URI(documentRepository.getAddress()));
		
		XDSSourceAuditor.getAuditor().getConfig().setAuditorEnabled(true);
		XDSSourceAuditor.getAuditor().getConfig().setAuditRepositoryHost("localhost");
		XDSSourceAuditor.getAuditor().getConfig().setAuditRepositoryPort(1234);
		XDSSourceAuditor.getAuditor().getConfig().setAuditSourceId("mdavis");
		AuditorModuleContext.getContext().setSender(new AuditLog4jSenderImpl());
		
		logger.debug("Submitting .");
		XDSResponseType response = source.submit(useAsync,submitTransactionData);
		
		logger.debug("Response status: " + response.getStatus().getName());
		return response;
	}
}
