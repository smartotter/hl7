/*    */ package org.openhealthtools.ihe.xds.consumer.storedquery;
/*    */ 
/*    */ import org.openhealthtools.ihe.common.hl7v2.CX;
/*    */ import org.openhealthtools.ihe.xds.metadata.AvailabilityStatusType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FindFoldersStoredQuery
/*    */   extends StoredQuery
/*    */ {
/*    */   public FindFoldersStoredQuery(CX patientID, AvailabilityStatusType[] status)
/*    */     throws MalformedStoredQueryException
/*    */   {
/* 26 */     super("urn:uuid:958f3006-baad-4929-a4de-ff1114824431");
/* 27 */     if (patientID == null) {
/* 28 */       throw new MalformedStoredQueryException("Null patient ID. Cannot proceed with query.");
/*    */     }
/* 30 */     if (patientID.getIdNumber() == null) {
/* 31 */       throw new MalformedStoredQueryException("Empty patient ID number. Cannot proceed with query.");
/*    */     }
/* 33 */     if (patientID.getAssigningAuthorityUniversalId() == null) {
/* 34 */       throw new MalformedStoredQueryException("Empty patient ID assigning authority universal id. Cannot proceed with query.");
/*    */     }
/* 36 */     if (patientID.getAssigningAuthorityUniversalIdType() == null) {
/* 37 */       throw new MalformedStoredQueryException("Empty atient ID assigning authority universal id type. Cannot proceed with query.");
/*    */     }
///* 39 */     if (!patientID.getAssigningAuthorityUniversalIdType().equals("ISO")) {
///* 40 */       throw new MalformedStoredQueryException("Patient ID assigning authority universal id type is not 'ISO'. Cannot proceed with query.");
///*    */     }
/* 42 */     if (status == null) {
/* 43 */       throw new MalformedStoredQueryException("Empty status. Cannot proceed with query.");
/*    */     }
/* 45 */     if (status[0] == null) {
/* 46 */       throw new MalformedStoredQueryException("Empty status. Cannot proceed with query.");
/*    */     }
/* 48 */     StoredQueryBuilderUtils.addPatientIdParameter(this.queryParameters, patientID, "$XDSFolderPatientId");
/* 49 */     StoredQueryBuilderUtils.addStatusParameters(this.queryParameters, status, "$XDSFolderStatus");
/*    */   }
/*    */ }

/* Location:           /Users/developer/.m2/repository/org/openhealthtools/ihe/xds/consumer/2.0.0/consumer-2.0.0.jar
 * Qualified Name:     org.openhealthtools.ihe.xds.consumer.storedquery.FindFoldersStoredQuery
 * Java Class Version: 5 (49.0)
 * JD-Core Version:    0.7.0.1
 */