/*     */ package org.openhealthtools.ihe.xds.consumer.storedquery;
/*     */ 
/*     */ import org.openhealthtools.ihe.common.hl7v2.CX;
/*     */ import org.openhealthtools.ihe.common.hl7v2.XCN;
/*     */ import org.openhealthtools.ihe.xds.consumer.query.DateTimeRange;
/*     */ import org.openhealthtools.ihe.xds.metadata.AvailabilityStatusType;
/*     */ import org.openhealthtools.ihe.xds.metadata.CodedMetadataType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FindDocumentsQuery
/*     */   extends StoredQuery
/*     */ {
/*     */   public FindDocumentsQuery(CX patientID, AvailabilityStatusType[] status)
/*     */     throws MalformedStoredQueryException
/*     */   {
/*  34 */     this(patientID, null, null, null, null, null, null, null, null, null, status, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindDocumentsQuery(CX patientID, CodedMetadataType[] classCodes, DateTimeRange[] dateTimeRanges, CodedMetadataType[] practiceSettingCodes, CodedMetadataType[] healthCareFacilityCodes, CodedMetadataType[] eventCodeList, CodedMetadataType[] confidentialityCodes, CodedMetadataType[] formatCodes, XCN authorPerson, AvailabilityStatusType[] status)
/*     */     throws MalformedStoredQueryException
/*     */   {
/*  62 */     this(patientID, classCodes, dateTimeRanges, practiceSettingCodes, healthCareFacilityCodes, eventCodeList, confidentialityCodes, formatCodes, null, authorPerson, status, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindDocumentsQuery(CX patientID, CodedMetadataType[] classCodes, DateTimeRange[] dateTimeRanges, CodedMetadataType[] practiceSettingCodes, CodedMetadataType[] healthCareFacilityCodes, CodedMetadataType[] eventCodeList, CodedMetadataType[] confidentialityCodes, CodedMetadataType[] formatCodes, CodedMetadataType[] typeCodes, XCN authorPerson, AvailabilityStatusType[] status)
/*     */     throws MalformedStoredQueryException
/*     */   {
/*  95 */     this(patientID, classCodes, dateTimeRanges, practiceSettingCodes, healthCareFacilityCodes, eventCodeList, confidentialityCodes, formatCodes, typeCodes, authorPerson, status, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindDocumentsQuery(CX patientID, CodedMetadataType[] classCodes, DateTimeRange[] dateTimeRanges, CodedMetadataType[] practiceSettingCodes, CodedMetadataType[] healthCareFacilityCodes, CodedMetadataType[] eventCodeList, CodedMetadataType[] confidentialityCodes, CodedMetadataType[] formatCodes, CodedMetadataType[] typeCodes, XCN authorPerson, AvailabilityStatusType[] status, ObjectType objectType)
/*     */     throws MalformedStoredQueryException
/*     */   {
/* 126 */     super("urn:uuid:14d4debf-8f97-4251-9a74-a90016b0af0d");
/* 127 */     if (patientID == null) {
/* 128 */       throw new MalformedStoredQueryException("Null patient ID. Cannot proceed with query.");
/*     */     }
/* 130 */     if (patientID.getIdNumber() == null) {
/* 131 */       throw new MalformedStoredQueryException("Empty patient ID number. Cannot proceed with query.");
/*     */     }
/* 133 */     if (patientID.getAssigningAuthorityUniversalId() == null) {
/* 134 */       throw new MalformedStoredQueryException("Empty patient ID assigning authority universal id. Cannot proceed with query.");
/*     */     }
/* 136 */     if (patientID.getAssigningAuthorityUniversalIdType() == null) {
/* 137 */       throw new MalformedStoredQueryException("Empty atient ID assigning authority universal id type. Cannot proceed with query.");
/*     */     }
///* 139 */     if (!patientID.getAssigningAuthorityUniversalIdType().equals("ISO")) {
///* 140 */       throw new MalformedStoredQueryException("Patient ID assigning authority universal id type is not 'ISO'. Cannot proceed with query.");
///*     */     }
/* 142 */     if (status == null) {
/* 143 */       throw new MalformedStoredQueryException("Empty status. Cannot proceed with query.");
/*     */     }
/* 145 */     if (status[0] == null) {
/* 146 */       throw new MalformedStoredQueryException("Empty status. Cannot proceed with query.");
/*     */     }
/*     */     
/*     */ 
/* 150 */     StoredQueryBuilderUtils.addPatientIdParameter(this.queryParameters, patientID, "$XDSDocumentEntryPatientId");
/*     */     
/*     */ 
/* 153 */     StoredQueryBuilderUtils.addStatusParameters(this.queryParameters, status, "$XDSDocumentEntryStatus");
/*     */     
/* 155 */     if ((classCodes != null) && 
/* 156 */       (classCodes.length > 0)) {
/* 157 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 158 */         "urn:uuid:41a5887f-8865-4c09-adf7-e362475b143a", classCodes);
/*     */     }
/*     */     
/*     */ 
/* 162 */     if ((dateTimeRanges != null) && 
/* 163 */       (dateTimeRanges.length > 0)) {
/* 164 */       for (int i = 0; i < dateTimeRanges.length; i++) {
/* 165 */         StoredQueryBuilderUtils.addDateTimeParameters(this.queryParameters, 
/* 166 */           dateTimeRanges[i]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 171 */     if ((practiceSettingCodes != null) && 
/* 172 */       (practiceSettingCodes.length > 0)) {
/* 173 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 174 */         "urn:uuid:cccf5598-8b07-4b77-a05e-ae952c785ead", practiceSettingCodes);
/*     */     }
/*     */     
/*     */ 
/* 178 */     if ((healthCareFacilityCodes != null) && 
/* 179 */       (healthCareFacilityCodes.length > 0)) {
/* 180 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 181 */         "urn:uuid:f33fb8ac-18af-42cc-ae0e-ed0b0bdb91e1", healthCareFacilityCodes);
/*     */     }
/*     */     
/*     */ 
/* 185 */     if ((eventCodeList != null) && 
/* 186 */       (eventCodeList.length > 0)) {
/* 187 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 188 */         "urn:uuid:2c6b8cb7-8b2a-4051-b291-b1ae6a575ef4", eventCodeList);
/*     */     }
/*     */     
/*     */ 
/* 192 */     if ((confidentialityCodes != null) && 
/* 193 */       (confidentialityCodes.length > 0)) {
/* 194 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 195 */         "urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f", confidentialityCodes);
/*     */     }
/*     */     
/*     */ 
/* 199 */     if ((formatCodes != null) && 
/* 200 */       (formatCodes.length > 0)) {
/* 201 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 202 */         "urn:uuid:a09d5840-386c-46f2-b5ad-9c3699a4309d", formatCodes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 207 */     if ((typeCodes != null) && 
/* 208 */       (typeCodes.length > 0)) {
/* 209 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 210 */         "urn:uuid:f0306f51-975f-434e-a61c-c59651d33983", typeCodes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 215 */     if (authorPerson != null) {
/* 216 */       StoredQueryBuilderUtils.addAuthorPersonParameter(this.queryParameters, authorPerson);
/*     */     }
/*     */     
/* 219 */     if (objectType != null) {
/* 220 */       StoredQueryBuilderUtils.addObjectTypeParameter(this.queryParameters, objectType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEventCodes(CodedMetadataType[] eventCodeList)
/*     */     throws MalformedStoredQueryException
/*     */   {
/* 234 */     if ((eventCodeList != null) && 
/* 235 */       (eventCodeList.length > 0)) {
/* 236 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 237 */         "urn:uuid:2c6b8cb7-8b2a-4051-b291-b1ae6a575ef4", eventCodeList);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConfidentialityCodes(CodedMetadataType[] confidentialityCodeList)
/*     */     throws MalformedStoredQueryException
/*     */   {
/* 252 */     if ((confidentialityCodeList != null) && 
/* 253 */       (confidentialityCodeList.length > 0)) {
/* 254 */       StoredQueryBuilderUtils.addCodedParameters(this.queryParameters, 
/* 255 */         "urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f", confidentialityCodeList);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/developer/.m2/repository/org/openhealthtools/ihe/xds/consumer/2.0.0/consumer-2.0.0.jar
 * Qualified Name:     org.openhealthtools.ihe.xds.consumer.storedquery.FindDocumentsQuery
 * Java Class Version: 5 (49.0)
 * JD-Core Version:    0.7.0.1
 */