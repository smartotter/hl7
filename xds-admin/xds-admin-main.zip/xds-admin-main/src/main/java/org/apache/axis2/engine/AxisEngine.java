/*     */ package org.apache.axis2.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axiom.om.OMNamespace;
/*     */ import org.apache.axiom.soap.RolePlayer;
/*     */ import org.apache.axiom.soap.SOAPEnvelope;
/*     */ import org.apache.axiom.soap.SOAPHeader;
/*     */ import org.apache.axiom.soap.SOAPHeaderBlock;
/*     */ import org.apache.axiom.soap.SOAPVersion;
/*     */ import org.apache.axis2.AxisFault;
/*     */ import org.apache.axis2.client.async.AxisCallback;
/*     */ import org.apache.axis2.client.async.Callback;
/*     */ import org.apache.axis2.context.ConfigurationContext;
/*     */ import org.apache.axis2.context.MessageContext;
/*     */ import org.apache.axis2.context.OperationContext;
/*     */ import org.apache.axis2.description.AxisOperation;
/*     */ import org.apache.axis2.description.TransportOutDescription;
/*     */ import org.apache.axis2.i18n.Messages;
/*     */ import org.apache.axis2.transport.TransportSender;
/*     */ import org.apache.axis2.util.CallbackReceiver;
/*     */ import org.apache.axis2.util.LoggingControl;
/*     */ import org.apache.axis2.util.MessageContextBuilder;
/*     */ import org.apache.axis2.util.Utils;
/*     */ import org.apache.axis2.util.threadpool.ThreadFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AxisEngine
/*     */ {
/*     */   public AxisEngine() {}
/*     */   
/*  65 */   private static final Log log = LogFactory.getLog(AxisEngine.class);
/*     */   
/*  67 */   private static boolean RESUMING_EXECUTION = true;
/*  68 */   private static boolean NOT_RESUMING_EXECUTION = false;
/*     */   
/*     */   private static void checkMustUnderstand(MessageContext msgContext) throws AxisFault {
/*  71 */     List<QName> unprocessed = null;
/*  72 */     SOAPEnvelope envelope = msgContext.getEnvelope();
/*  73 */     if (envelope.getHeader() == null) {
/*  74 */       return;
/*     */     }
/*     */     
/*  77 */     Iterator headerBlocks = envelope.getHeader().getHeadersToProcess((RolePlayer)msgContext.getConfigurationContext().getAxisConfiguration().getParameterValue("rolePlayer"));
/*  78 */     while (headerBlocks.hasNext()) {
/*  79 */       SOAPHeaderBlock headerBlock = (SOAPHeaderBlock)headerBlocks.next();
/*  80 */       QName headerName = headerBlock.getQName();
/*     */       
/*     */ 
/*  83 */       if ((!headerBlock.isProcessed()) && (headerBlock.getMustUnderstand()) && 
/*     */       
/*     */ 
/*     */ 
/*  87 */         (!clientHandlerUnderstandsHeader(headerBlock, msgContext)))
/*     */       {
/*     */ 
/*     */ 
/*  91 */         if ((LoggingControl.debugLoggingAllowed) && (log.isDebugEnabled())) {
/*  92 */           log.debug("MustUnderstand header not processed or registered as understood" + headerName);
/*     */         }
/*  94 */         if (isReceiverMustUnderstandProcessor(msgContext)) {
/*  95 */           if (unprocessed == null) {
/*  96 */             unprocessed = new ArrayList();
/*     */           }
/*  98 */           if (!unprocessed.contains(headerName)) {
/*  99 */             unprocessed.add(headerName);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 104 */           //QName faultQName = headerBlock.getVersion().getMustUnderstandFaultCode();
/* 105 */           //throw new AxisFault(Messages.getMessage("mustunderstandfailed", headerBlock.getNamespace().getNamespaceURI(), headerBlock.getLocalName()), faultQName);
/*     */         }
/*     */       }
/*     */     }
/* 109 */     if ((unprocessed != null) && (unprocessed.size() > 0))
/*     */     {
/*     */ 
/* 112 */       if (log.isDebugEnabled()) {
/* 113 */         log.debug("Adding Unprocessed headers to MessageContext.");
/*     */       }
/* 115 */       msgContext.setProperty("unprocessedHeaderQNames", unprocessed);
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean isReceiverMustUnderstandProcessor(MessageContext msgContext) {
/* 120 */     MessageReceiver receiver = null;
/* 121 */     if (msgContext.isServerSide()) {
/* 122 */       receiver = msgContext.getAxisOperation().getMessageReceiver();
/*     */     }
/* 124 */     return (receiver != null) && (receiver.getClass().getName().endsWith("JAXWSMessageReceiver"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageContext createFaultMessageContext(MessageContext processingContext, Throwable e)
/*     */     throws AxisFault
/*     */   {
/* 135 */     return MessageContextBuilder.createFaultMessageContext(processingContext, e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Handler.InvocationResponse receive(MessageContext msgContext)
/*     */     throws AxisFault
/*     */   {
/* 149 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 150 */       log.trace(msgContext.getLogIDString() + " receive:" + msgContext.getMessageID());
/*     */     }
/* 152 */     ConfigurationContext confContext = msgContext.getConfigurationContext();
/*     */     List<Phase> preCalculatedPhases;
/* 154 */     if ((msgContext.isFault()) || (msgContext.isProcessingFault())) {
/* 155 */       preCalculatedPhases = confContext.getAxisConfiguration().getInFaultFlowPhases();
/* 156 */       msgContext.setFLOW(3);
/*     */     } else {
/* 158 */       preCalculatedPhases = confContext.getAxisConfiguration().getInFlowPhases();
/* 159 */       msgContext.setFLOW(1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 164 */     ArrayList<Handler> executionChain = new ArrayList();
/* 165 */     executionChain.addAll(preCalculatedPhases);
/* 166 */     msgContext.setExecutionChain(executionChain);
/*     */     try {
/* 168 */       Handler.InvocationResponse pi = invoke(msgContext, NOT_RESUMING_EXECUTION);
/*     */       
/* 170 */       if (pi.equals(Handler.InvocationResponse.CONTINUE)) {
/* 171 */         checkMustUnderstand(msgContext);
/* 172 */         if (msgContext.isServerSide())
/*     */         {
/*     */ 
/* 175 */           MessageReceiver receiver = msgContext.getAxisOperation().getMessageReceiver();
/* 176 */           if (receiver == null) {
/* 177 */             throw new AxisFault(Messages.getMessage("nomessagereciever", msgContext.getAxisOperation().getName().toString()));
/*     */           }
/*     */           
/*     */ 
/* 181 */           receiver.receive(msgContext);
/*     */         }
/* 183 */         flowComplete(msgContext);
/* 184 */       } else { if (pi.equals(Handler.InvocationResponse.SUSPEND))
/* 185 */           return pi;
/* 186 */         if (pi.equals(Handler.InvocationResponse.ABORT)) {
/* 187 */           flowComplete(msgContext);
/*     */           
/*     */ 
/* 190 */           if (log.isDebugEnabled()) {
/* 191 */             log.debug("InvocationResponse is aborted.  The incoming MessageContext is removed, and the OperationContext is marked as incomplete");
/*     */           }
/*     */           
/*     */ 
/* 195 */           AxisOperation axisOp = msgContext.getAxisOperation();
/* 196 */           if (axisOp != null) {
/* 197 */             String mepURI = axisOp.getMessageExchangePattern();
/* 198 */             if ("http://www.w3.org/ns/wsdl/out-in".equals(mepURI)) {
/* 199 */               OperationContext opCtx = msgContext.getOperationContext();
/* 200 */               if (opCtx != null) {
/* 201 */                 opCtx.removeMessageContext("In");
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 206 */             log.debug("Could not clean up op ctx for " + msgContext);
/*     */           }
/* 208 */           return pi;
/*     */         }
/* 210 */         String errorMsg = "Unrecognized InvocationResponse encountered in AxisEngine.receive()";
/*     */         
/* 212 */         log.error(msgContext.getLogIDString() + " " + errorMsg);
/* 213 */         throw new AxisFault(errorMsg);
/*     */       }
/*     */     }
/*     */     catch (AxisFault e)
/*     */     {
/* 218 */       if (e.getFaultType() != 1) {
/* 219 */         log.error(e.getMessage(), e);
/*     */       }
/* 221 */       msgContext.setFailureReason(e);
/* 222 */       flowComplete(msgContext);
/* 223 */       throw e;
/*     */     }
/*     */     
/* 226 */     return Handler.InvocationResponse.CONTINUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Handler.InvocationResponse invoke(MessageContext msgContext, boolean resuming)
/*     */     throws AxisFault
/*     */   {
/* 243 */     if (msgContext.getCurrentHandlerIndex() == -1) {
/* 244 */       msgContext.setCurrentHandlerIndex(0);
/*     */     }
/*     */     
/* 247 */     Handler.InvocationResponse pi = Handler.InvocationResponse.CONTINUE;
/*     */     
/* 249 */     while (msgContext.getCurrentHandlerIndex() < msgContext.getExecutionChain().size()) {
/* 250 */       Handler currentHandler = (Handler)msgContext.getExecutionChain().get(msgContext.getCurrentHandlerIndex());
/*     */       
/*     */       try
/*     */       {
/* 254 */         if (!resuming) {
/* 255 */           msgContext.addExecutedPhase(currentHandler);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 260 */           resuming = false;
/*     */         }
/* 262 */         pi = currentHandler.invoke(msgContext);
/*     */       }
/*     */       catch (AxisFault e) {
/* 265 */         if (msgContext.getCurrentPhaseIndex() == 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 274 */           msgContext.removeFirstExecutedPhase();
/*     */         }
/* 276 */         throw e;
/*     */       }
/*     */       
/* 279 */       if ((pi.equals(Handler.InvocationResponse.SUSPEND)) || (pi.equals(Handler.InvocationResponse.ABORT))) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/* 284 */       msgContext.setCurrentHandlerIndex(msgContext.getCurrentHandlerIndex() + 1);
/*     */     }
/*     */     
/* 287 */     return pi;
/*     */   }
/*     */   
/*     */   private static void flowComplete(MessageContext msgContext) {
/* 291 */     Iterator<Handler> invokedPhaseIterator = msgContext.getExecutedPhases();
/*     */     
/* 293 */     while (invokedPhaseIterator.hasNext()) {
/* 294 */       Handler currentHandler = (Handler)invokedPhaseIterator.next();
/* 295 */       currentHandler.flowComplete(msgContext);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */     msgContext.resetExecutedPhases();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Handler.InvocationResponse resumeReceive(MessageContext msgContext)
/*     */     throws AxisFault
/*     */   {
/* 315 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 316 */       log.trace(msgContext.getLogIDString() + " resumeReceive:" + msgContext.getMessageID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */     Handler.InvocationResponse pi = invoke(msgContext, RESUMING_EXECUTION);
/*     */     
/*     */ 
/* 329 */     if (pi.equals(Handler.InvocationResponse.CONTINUE)) {
/* 330 */       checkMustUnderstand(msgContext);
/* 331 */       if (msgContext.isServerSide())
/*     */       {
/* 333 */         MessageReceiver receiver = msgContext.getAxisOperation().getMessageReceiver();
/* 334 */         if (receiver == null) {
/* 335 */           throw new AxisFault(Messages.getMessage("nomessagereciever", msgContext.getAxisOperation().getName().toString()));
/*     */         }
/*     */         
/*     */ 
/* 339 */         receiver.receive(msgContext);
/*     */       }
/* 341 */       flowComplete(msgContext);
/*     */     }
/*     */     
/* 344 */     return pi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Handler.InvocationResponse resumeSend(MessageContext msgContext)
/*     */     throws AxisFault
/*     */   {
/* 357 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 358 */       log.trace(msgContext.getLogIDString() + " resumeSend:" + msgContext.getMessageID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 368 */     Handler.InvocationResponse pi = invoke(msgContext, RESUMING_EXECUTION);
/*     */     
/* 370 */     if (pi.equals(Handler.InvocationResponse.CONTINUE))
/*     */     {
/* 372 */       TransportOutDescription transportOut = msgContext.getTransportOut();
/* 373 */       TransportSender sender = transportOut.getSender();
/* 374 */       sender.invoke(msgContext);
/* 375 */       flowComplete(msgContext);
/*     */     }
/*     */     
/* 378 */     return pi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Handler.InvocationResponse resume(MessageContext msgctx)
/*     */     throws AxisFault
/*     */   {
/* 390 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 391 */       log.trace(msgctx.getLogIDString() + " resume:" + msgctx.getMessageID());
/*     */     }
/*     */     
/* 394 */     msgctx.setPaused(false);
/* 395 */     if (msgctx.getFLOW() == 1) {
/* 396 */       return resumeReceive(msgctx);
/*     */     }
/* 398 */     return resumeSend(msgctx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void send(MessageContext msgContext)
/*     */     throws AxisFault
/*     */   {
/* 414 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 415 */       log.trace(msgContext.getLogIDString() + " send:" + msgContext.getMessageID());
/*     */     }
/*     */     
/* 418 */     OperationContext operationContext = msgContext.getOperationContext();
/* 419 */     ArrayList executionChain = operationContext.getAxisOperation().getPhasesOutFlow();
/*     */     
/* 421 */     ArrayList outPhases = new ArrayList();
/* 422 */     outPhases.addAll(executionChain);
/* 423 */     outPhases.addAll(msgContext.getConfigurationContext().getAxisConfiguration().getOutFlowPhases());
/* 424 */     msgContext.setExecutionChain(outPhases);
/* 425 */     msgContext.setFLOW(2);
/*     */     try {
/* 427 */       Handler.InvocationResponse pi = invoke(msgContext, NOT_RESUMING_EXECUTION);
/*     */       
/* 429 */       if (pi.equals(Handler.InvocationResponse.CONTINUE))
/*     */       {
/* 431 */         TransportOutDescription transportOut = msgContext.getTransportOut();
/* 432 */         if (transportOut == null) {
/* 433 */           throw new AxisFault("Transport out has not been set");
/*     */         }
/* 435 */         TransportSender sender = transportOut.getSender();
/*     */         
/*     */ 
/*     */ 
/* 439 */         if (Utils.isClientThreadNonBlockingPropertySet(msgContext)) {
/* 440 */           msgContext.getConfigurationContext().getThreadPool().execute(new TransportNonBlockingInvocationWorker(msgContext, sender));
/*     */         }
/*     */         else {
/* 443 */           sender.invoke(msgContext);
/*     */         }
/*     */         
/* 446 */         flowComplete(msgContext);
/* 447 */       } else if (!pi.equals(Handler.InvocationResponse.SUSPEND)) {
/* 448 */         if (pi.equals(Handler.InvocationResponse.ABORT)) {
/* 449 */           flowComplete(msgContext);
/*     */         } else {
/* 451 */           String errorMsg = "Unrecognized InvocationResponse encountered in AxisEngine.send()";
/*     */           
/* 453 */           log.error(msgContext.getLogIDString() + " " + errorMsg);
/* 454 */           throw new AxisFault(errorMsg);
/*     */         }
/*     */       }
/* 457 */     } catch (AxisFault e) { msgContext.setFailureReason(e);
/* 458 */       flowComplete(msgContext);
/* 459 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sendFault(MessageContext msgContext)
/*     */     throws AxisFault
/*     */   {
/* 470 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 471 */       log.trace(msgContext.getLogIDString() + " sendFault:" + msgContext.getMessageID());
/*     */     }
/* 473 */     OperationContext opContext = msgContext.getOperationContext();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 478 */     if (opContext != null) {
/* 479 */       AxisOperation axisOperation = opContext.getAxisOperation();
/* 480 */       ArrayList faultExecutionChain = axisOperation.getPhasesOutFaultFlow();
/*     */       
/*     */ 
/*     */ 
/* 484 */       ArrayList outFaultPhases = new ArrayList();
/* 485 */       outFaultPhases.addAll((ArrayList)faultExecutionChain.clone());
/* 486 */       msgContext.setExecutionChain((ArrayList)outFaultPhases.clone());
/* 487 */       msgContext.setFLOW(4);
/*     */       try {
/* 489 */         Handler.InvocationResponse pi = invoke(msgContext, NOT_RESUMING_EXECUTION);
/*     */         
/* 491 */         if (pi.equals(Handler.InvocationResponse.SUSPEND)) {
/* 492 */           log.warn(msgContext.getLogIDString() + " The resumption of this flow may function incorrectly, as the OutFaultFlow will not be used");
/*     */           
/* 494 */           return; }
/* 495 */         if (pi.equals(Handler.InvocationResponse.ABORT)) {
/* 496 */           flowComplete(msgContext);
/* 497 */           return; }
/* 498 */         if (!pi.equals(Handler.InvocationResponse.CONTINUE)) {
/* 499 */           String errorMsg = "Unrecognized InvocationResponse encountered in AxisEngine.sendFault()";
/*     */           
/* 501 */           log.error(msgContext.getLogIDString() + " " + errorMsg);
/* 502 */           throw new AxisFault(errorMsg);
/*     */         }
/*     */       }
/*     */       catch (AxisFault e) {
/* 506 */         msgContext.setFailureReason(e);
/* 507 */         flowComplete(msgContext);
/* 508 */         throw e;
/*     */       }
/*     */     }
/*     */     
/* 512 */     ArrayList<Handler> executionChain = new ArrayList(msgContext.getConfigurationContext().getAxisConfiguration().getOutFaultFlowPhases());
/*     */     
/* 514 */     msgContext.setExecutionChain(executionChain);
/* 515 */     msgContext.setFLOW(4);
/* 516 */     Handler.InvocationResponse pi = invoke(msgContext, NOT_RESUMING_EXECUTION);
/*     */     
/* 518 */     if (pi.equals(Handler.InvocationResponse.CONTINUE))
/*     */     {
/* 520 */       TransportOutDescription transportOut = msgContext.getTransportOut();
/* 521 */       if (transportOut == null) {
/* 522 */         throw new AxisFault("Transport out has not been set");
/*     */       }
/* 524 */       TransportSender sender = transportOut.getSender();
/*     */       
/* 526 */       sender.invoke(msgContext);
/* 527 */       flowComplete(msgContext);
/* 528 */     } else if (!pi.equals(Handler.InvocationResponse.SUSPEND)) {
/* 529 */       if (pi.equals(Handler.InvocationResponse.ABORT)) {
/* 530 */         flowComplete(msgContext);
/*     */       } else {
/* 532 */         String errorMsg = "Unrecognized InvocationResponse encountered in AxisEngine.sendFault()";
/*     */         
/* 534 */         log.error(msgContext.getLogIDString() + " " + errorMsg);
/* 535 */         throw new AxisFault(errorMsg);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void resumeSendFault(MessageContext msgContext)
/*     */     throws AxisFault
/*     */   {
/* 545 */     if ((LoggingControl.debugLoggingAllowed) && (log.isTraceEnabled())) {
/* 546 */       log.trace(msgContext.getLogIDString() + " resumeSendFault:" + msgContext.getMessageID());
/*     */     }
/* 548 */     OperationContext opContext = msgContext.getOperationContext();
/*     */     
/* 550 */     if (opContext != null) {
/*     */       try
/*     */       {
/* 553 */         Handler.InvocationResponse pi = invoke(msgContext, RESUMING_EXECUTION);
/*     */         
/* 555 */         if (pi.equals(Handler.InvocationResponse.SUSPEND)) {
/* 556 */           log.warn(msgContext.getLogIDString() + " The resumption of this flow may function incorrectly, as the OutFaultFlow will not be used");
/*     */           
/* 558 */           return; }
/* 559 */         if (pi.equals(Handler.InvocationResponse.ABORT)) {
/* 560 */           flowComplete(msgContext);
/* 561 */           return; }
/* 562 */         if (!pi.equals(Handler.InvocationResponse.CONTINUE)) {
/* 563 */           String errorMsg = "Unrecognized InvocationResponse encountered in AxisEngine.sendFault()";
/*     */           
/* 565 */           log.error(msgContext.getLogIDString() + " " + errorMsg);
/* 566 */           throw new AxisFault(errorMsg);
/*     */         }
/*     */       } catch (AxisFault e) {
/* 569 */         msgContext.setFailureReason(e);
/* 570 */         flowComplete(msgContext);
/* 571 */         throw e;
/*     */       }
/*     */     }
/*     */     
/* 575 */     ArrayList<Handler> executionChain = new ArrayList(msgContext.getConfigurationContext().getAxisConfiguration().getOutFaultFlowPhases());
/*     */     
/* 577 */     msgContext.setExecutionChain(executionChain);
/* 578 */     msgContext.setFLOW(4);
/* 579 */     Handler.InvocationResponse pi = invoke(msgContext, NOT_RESUMING_EXECUTION);
/*     */     
/* 581 */     if (pi.equals(Handler.InvocationResponse.CONTINUE))
/*     */     {
/* 583 */       TransportOutDescription transportOut = msgContext.getTransportOut();
/* 584 */       if (transportOut == null) {
/* 585 */         throw new AxisFault("Transport out has not been set");
/*     */       }
/* 587 */       TransportSender sender = transportOut.getSender();
/*     */       
/* 589 */       sender.invoke(msgContext);
/* 590 */       flowComplete(msgContext);
/* 591 */     } else if (!pi.equals(Handler.InvocationResponse.SUSPEND)) {
/* 592 */       if (pi.equals(Handler.InvocationResponse.ABORT)) {
/* 593 */         flowComplete(msgContext);
/*     */       } else {
/* 595 */         String errorMsg = "Unrecognized InvocationResponse encountered in AxisEngine.sendFault()";
/*     */         
/* 597 */         log.error(msgContext.getLogIDString() + " " + errorMsg);
/* 598 */         throw new AxisFault(errorMsg);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class TransportNonBlockingInvocationWorker
/*     */     implements Runnable
/*     */   {
/*     */     private MessageContext msgctx;
/*     */     
/*     */ 
/*     */ 
/*     */     private TransportSender sender;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public TransportNonBlockingInvocationWorker(MessageContext msgctx, TransportSender sender)
/*     */     {
/* 621 */       this.msgctx = msgctx;
/* 622 */       this.sender = sender;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       try {
/* 627 */         this.sender.invoke(this.msgctx);
/*     */       } catch (Exception e) {
/* 629 */         AxisEngine.log.info(this.msgctx.getLogIDString() + " " + e.getMessage());
/* 630 */         if (this.msgctx.getProperty("disableTransmissionErrorCallback") == null)
/*     */         {
/* 632 */           AxisOperation axisOperation = this.msgctx.getAxisOperation();
/* 633 */           if (axisOperation != null) {
/* 634 */             MessageReceiver msgReceiver = axisOperation.getMessageReceiver();
/* 635 */             if ((msgReceiver != null) && ((msgReceiver instanceof CallbackReceiver))) {
/* 636 */               Object callback = ((CallbackReceiver)msgReceiver).lookupCallback(this.msgctx.getMessageID());
/*     */               
/* 638 */               if (callback == null) { return;
/*     */               }
/* 640 */               if ((callback instanceof Callback))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 645 */                 ((Callback)callback).onError(e);
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/*     */ 
/* 651 */                 ((AxisCallback)callback).onError(e);
/* 652 */                 ((AxisCallback)callback).onComplete();
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean clientHandlerUnderstandsHeader(SOAPHeaderBlock headerBlock, MessageContext messageContext)
/*     */   {
/* 672 */     boolean headerUnderstood = false;
/*     */     
/*     */ 
/* 675 */     QName headerQName = headerBlock.getQName();
/* 676 */     Set understoodHeaders = getUnderstoodClientHeaders(messageContext);
/* 677 */     if ((understoodHeaders != null) && (understoodHeaders.size() > 0)) {
/* 678 */       headerUnderstood = understoodHeaders.contains(headerQName);
/*     */     }
/* 680 */     return headerUnderstood;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Set getUnderstoodClientHeaders(MessageContext msgContext)
/*     */   {
/* 694 */     Set returnQN = null;
/*     */     
/*     */ 
/* 697 */     OperationContext opCtx = msgContext.getOperationContext();
/* 698 */     MessageContext outboundMC = null;
/*     */     try {
/* 700 */       outboundMC = opCtx.getMessageContext("Out");
/*     */     }
/*     */     catch (AxisFault af) {}
/*     */     
/*     */ 
/* 705 */     if (outboundMC != null) {
/* 706 */       returnQN = (Set)outboundMC.getProperty("client.UnderstoodHeaders");
/*     */     }
/*     */     
/* 709 */     return returnQN;
/*     */   }
/*     */ }

/* Location:           /Users/developer/.m2/repository/org/apache/axis2/axis2/1.6.2/axis2-1.6.2.jar
 * Qualified Name:     org.apache.axis2.engine.AxisEngine
 * Java Class Version: 5 (49.0)
 * JD-Core Version:    0.7.0.1
 */